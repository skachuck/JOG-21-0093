 #ifdef CH_LANG_CC
/*
*      _______              __
*     / ___/ /  ___  __ _  / /  ___
*    / /__/ _ \/ _ \/  V \/ _ \/ _ \
*    \___/_//_/\___/_/_/_/_.__/\___/
*    Please refer to Copyright.txt, in Chombo's root directory.
*/
#endif

//===========================================================================
// modifyMask.cpp -- reads in an hdf5 (mask) file and a list of mask values. 
// Returns a new file in which cells where the original mask was one of the 
// mask values have a new value of 1, and all other cells are zero. 
// (i.e. a new mask)
//===========================================================================

#include <iostream>
#include "AMRIO.H"
#include "NamespaceHeader.H"

bool verbose = true;

int main(int argc, char* argv[]) {

#ifdef CH_MPI
  MPI_Init(&argc, &argv);
#endif

  { // Begin nested scope
#ifdef CH_MPI
    MPI_Barrier(Chombo_MPI::comm);
#endif
    int rank, number_procs;
#ifdef CH_MPI
    MPI_Comm_rank(Chombo_MPI::comm, &rank);
    MPI_Comm_size(Chombo_MPI::comm, &number_procs);
#else
    rank=0;
    number_procs=1;
#endif

    if(argc < 4) 
      { 
	std::cerr << " usage: " << argv[0] << " <input_file> <output_file> maskVal1, [maskVal2, [maskVal3]...]" << std::endl; 
	exit(0); 
      }

    char* in_file = argv[1];
    char* out_file = argv[2];

 
    Vector<Real> maskVals(argc-3);
    for (int i=0; i<maskVals.size(); i++)
      maskVals[i] = atof(argv[i+3]);

    if (verbose)
      {
        pout ();
        pout() << "reading mask file..." << endl;
      }
    Vector<LevelData<FArrayBox>* > data;
    Vector<DisjointBoxLayout> grids;
    Vector<string> names;
    Vector<int> ratio;
    Real crseDx = 0.0, dt = 0.0, time = 0.0;
    Box crseBox;
    int numLevels;
    int status = ReadAMRHierarchyHDF5
      (in_file,grids,data,names,crseBox,crseDx,dt,time,
       ratio,numLevels);
    if (status != 0)
      {
        MayDay::Error("failed to read AMR hierarchy");
      }
    
    if (verbose)
      {
        pout() << "... done." << endl;
      }

    Vector<LevelData<FArrayBox>* > newMask(data.size());
    Real epsilon = 0.01;
    // loop over levels, allocate new mask, and set new mask values.
    for (int lev=0; lev<data.size(); lev++)
      {
	newMask[lev] = new LevelData<FArrayBox>(data[lev]->getBoxes(),
						1, data[lev]->ghostVect());
	
        LevelData<FArrayBox>& newMaskLev = *newMask[lev];
	LevelData<FArrayBox>& dataLev = *data[lev];
        DataIterator dit = dataLev.dataIterator();
        for (dit.begin(); dit.ok(); ++dit)
          {
	    // initialize to zero
	    FArrayBox& thisNewMask = newMaskLev[dit];
	    thisNewMask.setVal(0.0);
	    const FArrayBox& thisData = dataLev[dit];
	    // now loop over mask values 
	    for (int i=0; i<maskVals.size(); i++)
	      {
		Real thisVal = maskVals[i];
		Real loVal = thisVal-epsilon;
		Real hiVal = thisVal+epsilon;
		Box thisBox = thisData.box();
		thisBox &= thisNewMask.box();
		BoxIterator bit(thisBox);
		for (bit.begin(); bit.ok(); ++bit)
		  {
		    IntVect iv = bit();
		    if ((thisData(iv,0) > loVal) && (thisData(iv,0) < hiVal))
		      {
			thisNewMask(iv,0) = 1.0;
		      } // end if we're keeping this value
		  } // end loop over cells in this box
	      } // end loop over mask vals
          } // end loop over boxes
      } // end loop over levels

    WriteAMRHierarchyHDF5(out_file, grids, newMask, names, 
                          crseBox, crseDx, dt, time, ratio, numLevels);
    
    // clean up memory
    for (int lev=0; lev<data.size(); lev++)
      {
        if (data[lev] != NULL)
          {
            delete data[lev];
            data[lev] = NULL;
          }
        if (newMask[lev] != NULL)
          {
            delete newMask[lev];
            newMask[lev] = NULL;
          }


      }
    
  }  // end nested scope
  CH_TIMER_REPORT();
  
#ifdef CH_MPI
  MPI_Finalize();
#endif
  return 0;
}
#include "NamespaceFooter.H"
