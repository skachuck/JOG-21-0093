#ifdef CH_LANG_CC
/*
 *      _______              __
 *     / ___/ /  ___  __ _  / /  ___
 *    / /__/ _ \/ _ \/  V \/ _ \/ _ \
 *    \___/_//_/\___/_/_/_/_.__/\___/
 *    Please refer to Copyright.txt, in Chombo's root directory.
 */
#endif

// this code reads in BISICLES-produced AMR plotfiles as specified 
// by an inputs file, and computes various quantities of interest over 
// the AMR hierarchy, including
// -- total grounded ice volume/mass
// -- total ice volume/mass over flotation

#include <iostream>
#include <strstream>
using namespace std;

#include "AMRIO.H"
#include "ParmParse.H"
#include "BoxLayout.H"
#include "BoxIterator.H"


#include "computeSum.H"

void init(string&         a_infileRoot,
          string&         a_outfileRoot,
          int&            a_intFieldSize,
          int&            a_numStart,
          int&            a_numFinish,
          int&            a_numInit,
          int&            a_step,
          bool&           a_doPlots,
          bool&           a_isTimeDep,
          Real&           a_rhoIce,
          Real&           a_rhoSeawater,
          Real&           a_seaLevel,
          bool&           a_refToInitial,
          bool&           a_verbose);


void constructPlotFileName(ostrstream&   a_fileName,
                           const string& a_fileRoot,
                           const int     a_intFieldWidth,
                           const int     a_step);

// One more function for MPI
void dumpmemoryatexit();

int main(int argc, char* argv[])
{
#ifdef CH_MPI
  MPI_Init(&argc, &argv);
  // setChomboMPIErrorHandler();
  MPI_Barrier(Chombo_MPI::comm);  // Barrier #1
#endif

  // ------------------------------------------------
  // parse command line and input file
  // ------------------------------------------------
  // infile must be first
  if (argc < 2)
  {
    cerr << "  need inputs file" << endl;
    abort();
  }

  char* in_file = argv[1];
  ParmParse pp(argc-2, argv+2, NULL, in_file);

#ifdef CH_MPI
  MPI_Barrier(Chombo_MPI::comm);
#endif

  pout().setf(ios::scientific);
  pout().precision(4);

  // set defaults
  bool doPlots = true;
  bool isTimeDep = false;
  bool verbose = false;

  string infileRoot, outfileRoot;

  Vector<string> errorVars;

  int numFinish, numStart, step;
  int numInit;
  int intFieldSize = 6;

  // set reasonable defaults
  Real rhoIce= 918.0;
  Real rhoSeawater = 1028.0;
  Real seaLevel = 0.0;
  Real refTotalVal = 0.0;
  Real refGroundedVal = 0.0;
  Real refFlotationVal = 0.0;
  Real refIceArea = 0.0;
  Real refGroundedArea = 0.0;
  Real refFloatingArea = 0.0;
  bool refToInitial = true;

  init(infileRoot, outfileRoot, intFieldSize,
       numStart, numFinish, numInit, step,
       doPlots, isTimeDep, rhoIce, rhoSeawater, 
       seaLevel, refToInitial, verbose);


  int nStep;

  if (!isTimeDep)
  {
    step = 1;
    numFinish = numStart;
  }

  for (nStep = numStart; nStep <= numFinish; nStep += step)
  {
    if (verbose)
    {
      pout() << "starting step " << nStep << endl;
    }

    ostrstream inFile;
    ostrstream outFile;

    inFile.fill('0');
    outFile.fill('0');


    if (isTimeDep)
    {
      constructPlotFileName(inFile, infileRoot, intFieldSize, nStep);
      constructPlotFileName(outFile, outfileRoot, intFieldSize, nStep);
    }
    else
    {
      // if not time dependent, file roots are really filenames
      inFile << infileRoot << ends;
      outFile << outfileRoot << ends;
    }

    pout() << "input Filename = " << inFile.str() << endl;
    if (doPlots)
    {
      pout() << "output Filename = " << outFile.str() << endl;
    }

    // declare memory
    Vector<LevelData<FArrayBox>* > inData;
    Vector<string> inVars; // exact solution variable names
    Vector<DisjointBoxLayout> inGrids;
    Box inDomain;
    Real inDx, inDt, inTime;
    Vector<int> inRefRatio;
    int inNumLevels;
    IntVect ghostVect = IntVect::Unit;
    string inFileName(inFile.str());

    // read file
    if (verbose)
    {
      pout() << "read data..." << endl;
    }

    ReadAMRHierarchyHDF5(inFileName,
                         inGrids,
                         inData,
                         inVars,
                         inDomain,
                         inDx,
                         inDt,
                         inTime,
                         inRefRatio,
                         inNumLevels);

    if (verbose)
    {
      pout () << "done reading data" << endl;
    }

    // now compute sums -- 
    Vector<LevelData<FArrayBox>* > totalIce(inData.size(), NULL);
    Vector<LevelData<FArrayBox>* > groundedIce(inData.size(), NULL);
    Vector<LevelData<FArrayBox>* > thkOverFlotation(inData.size(), NULL);
    Vector<LevelData<FArrayBox>* > iceArea(inData.size(), NULL);
    Vector<LevelData<FArrayBox>* > groundedArea(inData.size(), NULL);
    Vector<LevelData<FArrayBox>* > floatingArea(inData.size(), NULL);
    
    int thicknessComp = -1;
    int uSurfComp = -1;
    int lSurfComp = -1;
    int topographyComp = -1;; 

    // look up variables 
    bool foundVar = false;
    int numVars = inVars.size();

    for (int i=0; i< inVars.size(); i++)
      {
        if (inVars[i] == "thickness")
          {
            thicknessComp = i;
            foundVar = true;
          }
      }
    CH_assert(foundVar);

#define THICKNESSFIX  1
#ifdef THICKNESSFIX    

    // get upper and lower surfaces as a workaround
    // for the corrupted-thickness bug
    foundVar = false;
    for (int i=0; i< inVars.size(); i++)
      {
        if (inVars[i] == "Z_surface")
          {
            uSurfComp = i;
            foundVar = true;
          }
      }
    CH_assert(foundVar);

    foundVar = false;
    for (int i=0; i< inVars.size(); i++)
      {
        if (inVars[i] == "Z_bottom")
          {
            lSurfComp = i;
            foundVar = true;
          }
      }
    CH_assert(foundVar);

    // now clobber read-in thickness and replace with 
    // uSurf - lSurf, which should be correct
    for (int lev=0; lev<inData.size(); lev++)
      {
        LevelData<FArrayBox>& dataLev = *inData[lev];
        const DisjointBoxLayout grids = dataLev.getBoxes();    
        DataIterator dit = grids.dataIterator();
        for (dit.begin(); dit.ok(); ++dit)
          {
            // first, copy uSurf into thk component
            dataLev[dit].copy(dataLev[dit],uSurfComp,thicknessComp,1);
            // now, subtract off lSurf to get correct thickness
            dataLev[dit].minus(dataLev[dit],lSurfComp,thicknessComp, 1);
          } // end loop over grids
      } // end loop over levels to correct thickness

#endif
    
       
    foundVar = false;
    for (int i=0; i< inVars.size(); i++)
      {
        if (inVars[i] == "Z_base")
          {
            topographyComp = i;
            foundVar = true;
          }
      }

    CH_assert(foundVar);

    for (int lev=0; lev<inData.size(); lev++)
      {
        LevelData<FArrayBox>& dataLev = *inData[lev];
        const DisjointBoxLayout grids = dataLev.getBoxes();

        IntVect ghostVect = IntVect::Zero;
        totalIce[lev] = new LevelData<FArrayBox>(grids, 1, ghostVect);
        groundedIce[lev] = new LevelData<FArrayBox>(grids, 1, ghostVect);
        thkOverFlotation[lev] = new LevelData<FArrayBox>(grids, 1, ghostVect);  
        iceArea[lev] = new LevelData<FArrayBox>(grids, 1, ghostVect);
        groundedArea[lev] = new LevelData<FArrayBox>(grids, 1, ghostVect);
        floatingArea[lev] = new LevelData<FArrayBox>(grids, 1, ghostVect);

        DataIterator dit=grids.dataIterator();
        for (dit.begin(); dit.ok(); ++dit)
          {
            FArrayBox& thisTotalIce = (*totalIce[lev])[dit];
            FArrayBox& thisGroundedIce = (*groundedIce[lev])[dit];
            FArrayBox& thisThkOverFlotation = (*thkOverFlotation[lev])[dit];
            FArrayBox& thisIceArea = (*iceArea[lev])[dit];
            FArrayBox& thisGroundedArea = (*groundedArea[lev])[dit];
            FArrayBox& thisFloatingArea = (*floatingArea[lev])[dit];
            FArrayBox& thisDataFab = (*inData[lev])[dit];

            thisTotalIce.setVal(0.0);
            thisGroundedIce.setVal(0.0);
            thisThkOverFlotation.setVal(0.0);
            thisIceArea.setVal(0.0);
            thisGroundedArea.setVal(0.0);
            thisFloatingArea.setVal(0.0);

            BoxIterator bit(grids[dit]);
            for (bit.begin(); bit.ok(); ++bit)
              {
                IntVect iv = bit();
                Real thisH = thisDataFab(iv,thicknessComp);
                Real thisTopo = thisDataFab(iv,topographyComp);
                Real ratio = 1.0 - (rhoIce/rhoSeawater);
                Real groundedHeight = thisH + thisTopo;
                Real floatingHeight = seaLevel + ratio*thisH;
                Real flotationThickness = 0.0;
                if (thisTopo < seaLevel) 
                  {
                    flotationThickness = (rhoSeawater/rhoIce)*(seaLevel-thisTopo);
                  }

                // is there ice?
                if (thisH > 0.0)
                  {
                    thisIceArea(iv,0) = 1.0;
                    thisTotalIce(iv,0) = thisH;

                    // is ice grounded?
                    if (thisH > flotationThickness)
                      {
                        thisGroundedIce(iv,0) = thisH;
                        thisThkOverFlotation(iv,0) = thisH - flotationThickness;
                        thisGroundedArea(iv,0) = 1.0;
                        thisFloatingArea(iv,0) = 0.0;
                      }
                    else 
                      { 
                        thisGroundedIce(iv,0) = 0.0;
                        thisThkOverFlotation(iv,0) = 0.0;
                        thisGroundedArea(iv,0) = 0.0;
                        thisFloatingArea(iv,0) = 1.0;
                      } // end if grounded/not grounde
                  } // end if there is ice 
              } // end loop over cells
          } // end loop over grids
      } // end loop over levels
  

    // conversion factors: 
    // conversion from kg->GT
    Real kg2GT = 1.0e-12;

    // conversion from GT->mmSLR
    Real GT2SLR = 1.0/360.0;
    //    Real GT2SLR = 1.0;

    // conversion from m^2->km^2
    Real mSqr2kmSqr = 1.0/1000.0/1000.0;



    // now compute sums
    Real sumGroundedIce, sumThkOverFlotation;
    Real sumGroundedArea, sumFloatingArea;
    Real sumIceArea, sumTotalIce;
    sumTotalIce = computeSum(totalIce, 
                             inRefRatio,
                             inDx);

    sumGroundedIce = computeSum(groundedIce, 
                                inRefRatio,
                                inDx);

    sumThkOverFlotation = computeSum(thkOverFlotation,
                                     inRefRatio,
                                     inDx);

    sumIceArea = computeSum(iceArea, 
                            inRefRatio,
                            inDx);


    sumGroundedArea = computeSum(groundedArea, 
                                inRefRatio,
                                inDx);

    sumFloatingArea = computeSum(floatingArea, 
                                 inRefRatio,
                                 inDx);
    
    if (refToInitial && nStep == numStart)
      {
        refTotalVal = sumTotalIce;
        refGroundedVal = sumGroundedIce;
        refFlotationVal = sumThkOverFlotation;        
        refIceArea = sumIceArea;
        refGroundedArea = sumGroundedArea;
        refFloatingArea = sumFloatingArea;
        
        // report reference values
        pout() << "step " << nStep << ", time = " << inTime
               << ", Reference Sum grounded = " << refGroundedVal << " m^3, "
               << refGroundedVal*rhoIce*kg2GT*GT2SLR << " mm SLR " << endl;
        
        
        pout() << "step " << nStep << ", time = " << inTime
               << ", Reference Sum over flotation = " << refFlotationVal
               << " m^3, "
               << refFlotationVal*rhoIce*kg2GT*GT2SLR << " mm SLR " << endl;
        
        
        pout() << "step " << nStep << ", time = " << inTime
               << ", Reference Sum Ice Area = " << refIceArea
               << " m^2, "
               << refIceArea*mSqr2kmSqr << " km^2 " << endl;


        pout() << "step " << nStep << ", time = " << inTime
               << ", Reference Sum groundedArea = " << refGroundedArea
               << " m^2, "
               << refGroundedArea*mSqr2kmSqr << " km^2 " << endl;
        
        
        pout() << "step " << nStep << ", time = " << inTime
               << ", Reference Sum floatingArea = " << refFloatingArea
               << " m^2, "
               << refFloatingArea*mSqr2kmSqr << " km^2 " << endl;
        
      }

    // subtract off reference values
    sumTotalIce -= refTotalVal;
    sumGroundedIce -= refGroundedVal;
    sumThkOverFlotation -= refFlotationVal;
    sumIceArea -= refIceArea;
    sumFloatingArea -= refFloatingArea;
    sumGroundedArea -= refGroundedArea;

    // now report sums
    pout() << "step " << nStep << ", time = " << inTime
           << ", Sum total ice = " << sumTotalIce << " m^3, "
           << sumTotalIce*rhoIce*kg2GT*GT2SLR << " mm SLR " << endl;

    pout() << "step " << nStep << ", time = " << inTime
           << ", Sum grounded = " << sumGroundedIce << " m^3, "
           << sumGroundedIce*rhoIce*kg2GT*GT2SLR << " mm SLR " << endl;


    pout() << "step " << nStep << ", time = " << inTime
           << ", Sum over flotation = " << sumThkOverFlotation << " m^3, "
           << sumThkOverFlotation*rhoIce*kg2GT*GT2SLR << " mm SLR " << endl;


    pout() << "step " << nStep << ", time = " << inTime
           << ", Sum ice Area = " << sumIceArea << " m^2, "
           << sumIceArea*mSqr2kmSqr << " km^2 " << endl;



    pout() << "step " << nStep << ", time = " << inTime
           << ", Sum groundedArea = " << sumGroundedArea << " m^2, "
           << sumGroundedArea*mSqr2kmSqr << " km^2 " << endl;


    pout() << "step " << nStep << ", time = " << inTime
           << ", Sum floatingArea = " << sumFloatingArea << " m^2, "
           << sumFloatingArea*mSqr2kmSqr << " km^2 " << endl;

    if (doPlots)
      {
        if (verbose)
          {
            pout() << "begin writing hdf5 file..." << endl;
          }
        
        Vector<LevelData<FArrayBox>* > outData(inData.size(), NULL);
        for (int lev=0; lev<inData.size(); lev++)
          {
            const DisjointBoxLayout grids = inGrids[lev];
            
            IntVect ghostVect = IntVect::Zero;
            outData[lev] = new LevelData<FArrayBox>(grids, 5, ghostVect);
            
            Interval zeroComps(0,0);
            groundedIce[lev]->copyTo(zeroComps, *outData[lev],
                                     zeroComps);
            
            Interval oneComps(1,1);
            thkOverFlotation[lev]->copyTo(zeroComps, *outData[lev],
                                          oneComps);

            Interval twoComps(2,2);
            groundedArea[lev]->copyTo(zeroComps, *outData[lev],
                                      twoComps);

            Interval threeComps(3,3);
            floatingArea[lev]->copyTo(zeroComps, *outData[lev],
                                      threeComps);

            Interval fourComps(4,4);
            iceArea[lev]->copyTo(zeroComps, *outData[lev],
                                 fourComps);


          } // end loop over levels
        
        Vector<string> outVars(5); 
        outVars[0] = "groundedThickness";
        outVars[1] = "thicknessOverFlotation";
        outVars[2] = "groundedArea";
        outVars[3] = "floatingArea";
        outVars[4] = "iceArea";

        WriteAMRHierarchyHDF5(outFile.str(),
                              inGrids,
                              outData,
                              outVars,
                              inDomain,
                              inDx,
                              inDt,
                              inTime,
                              inRefRatio,
                              inNumLevels);

        if (verbose)
          {
            pout() << "done writing hdf5 file" << endl;
          }
        
        // clean up
        for (int lev=0; lev<outData.size(); lev++)
          {
            if (outData[lev] != NULL)
              {
                delete outData[lev];
                outData[lev] = NULL;
              }
          }
      } //  end if do plots

    // clean up memory
    for (int level = 0; level < inData.size(); level++)
    {
      if (inData[level] != NULL)
      {
        delete inData[level];
        inData[level] = NULL;
      }
    }

    for (int lev=0; lev<groundedIce.size(); lev++)
      {
        if (totalIce[lev] != NULL)
          {
            delete totalIce[lev];
            totalIce[lev] = NULL;
          }

        if (groundedIce[lev] != NULL)
          {
            delete groundedIce[lev];
            groundedIce[lev] = NULL;
          }
        
        if (thkOverFlotation[lev] != NULL)
          {
            delete thkOverFlotation[lev];
            thkOverFlotation[lev] = NULL;
          }
                
        if (iceArea[lev] != NULL)
          {
            delete iceArea[lev];
            iceArea[lev] = NULL;
          }
        
        if (groundedArea[lev] != NULL)
          {
            delete groundedArea[lev];
            groundedArea[lev] = NULL;
          }

        if (floatingArea[lev] != NULL)
          {
            delete thkOverFlotation[lev];
            thkOverFlotation[lev] = NULL;
          }
      } 
    
  } // end loop over timesteps

#ifdef CH_MPI
  dumpmemoryatexit();
  MPI_Finalize();
#endif
} // end main

void init(string&         a_infileRoot,
          string&         a_outfileRoot,
          int&            a_intFieldSize,
          int&            a_numStart,
          int&            a_numFinish,
          int&            a_numInit,
          int&            a_step,
          bool&           a_doPlots,
          bool&           a_isTimeDep,
          Real&           a_rhoIce,
          Real&           a_rhoSeawater,
          Real&           a_seaLevel,
          bool&           a_refToInitial,
          bool&           a_verbose)
{
  ParmParse pp("integrals");

  int temp = a_doPlots;
  pp.query("doPlots", temp);
  a_doPlots = (temp == 1);

  temp = a_verbose;
  pp.query("verbose", temp);
  a_verbose = (temp == 1);

  temp = a_isTimeDep;
  pp.query("isTimeDep", temp);
  a_isTimeDep = (temp == 1);

  pp.get("infileRoot", a_infileRoot);
  if (a_doPlots)
  {
    pp.get("outfileRoot", a_outfileRoot);
  }

  a_numStart = 0;
  pp.query("numStart", a_numStart);
  pout() << "numStart " << a_numStart << endl;

  if (a_isTimeDep)
  {
    pp.get("numFinish", a_numFinish);
    a_step = 1;
    pp.query("step", a_step);
    pout() << "numFinish " << a_numFinish <<
      " step " << a_step << endl;

    pp.query("intFieldWidth", a_intFieldSize);
  }

  pp.query("rhoIce", a_rhoIce);
  pp.query("rhoSeawater", a_rhoSeawater);
  pp.query("seaLevel", a_seaLevel);

  pp.query("refToInitial", a_refToInitial);

}

void constructPlotFileName(ostrstream&   a_fileName,
                           const string& a_fileRoot,
                           const int     a_intFieldWidth,
                           const int     a_step)
{
  // this is kinda klugy, but what are ya gonna do?
  a_fileName << a_fileRoot
             << setw(a_intFieldWidth) << a_step
             << "."
             << setw(1) << CH_SPACEDIM
             << "d.hdf5" << ends;
}


