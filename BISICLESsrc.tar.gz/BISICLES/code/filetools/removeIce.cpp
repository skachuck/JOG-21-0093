 #ifdef CH_LANG_CC
/*
*      _______              __
*     / ___/ /  ___  __ _  / /  ___
*    / /__/ _ \/ _ \/  V \/ _ \/ _ \
*    \___/_//_/\___/_/_/_/_.__/\___/
*    Please refer to Copyright.txt, in Chombo's root directory.
*/
#endif

//===========================================================================
// removeIce.cpp
// read an AMR hierarchy, along with parameters of a curve (center and radius)
// remove ice from finest-level cells which intersect the curve, and write 
// the result to a Chombo hdf5 file
//===========================================================================
#include <iostream>
#include "AMRIO.H"
#include "LoadBalance.H"
#include "NamespaceHeader.H"

using std::sqrt;

bool verbose = true;

int main(int argc, char* argv[]) {

#ifdef CH_MPI
  MPI_Init(&argc, &argv);
#endif

  { // Begin nested scope
#ifdef CH_MPI
    MPI_Barrier(Chombo_MPI::comm);
#endif
    int rank, number_procs;
#ifdef CH_MPI
    MPI_Comm_rank(Chombo_MPI::comm, &rank);
    MPI_Comm_size(Chombo_MPI::comm, &number_procs);
#else
    rank=0;
    number_procs=1;
#endif

    if(argc < 6) 
      { 
	std::cerr << " usage: " << argv[0] << " <input_file> <output_file> x_ctr, y_ctr, radius" << std::endl; 
	exit(0); 
      }

    char* in_file = argv[1];
    char* out_file = argv[2];

    Real x_ctr = atof(argv[3]);
    Real y_ctr = atof(argv[4]);
    Real rad = atof(argv[5]);
    Real radSqr = rad*rad;

    RealVect ctr(D_DECL(x_ctr, y_ctr, 0) );
    
    if (verbose) 
      {
        pout() << "Ice Removal Arc: ctr = " << ctr
               << ", rad = " << rad << endl;
      }


    if (verbose) 
      {
        pout() << "reading " << in_file << "..." << endl;
      }

    Vector<std::string> names;
    Vector<LevelData<FArrayBox>* > data;
    Vector<DisjointBoxLayout> grids;
    Vector<int> ratio;
    Real crseDx = 0.0, dt = 0.0, time = 0.0;
    Box crseBox;
    int numLevels;
    int status = ReadAMRHierarchyHDF5
      (in_file,grids,data,names,crseBox,crseDx,dt,time,
       ratio,numLevels);
    if (status != 0)
      {
	MayDay::Error("failed to read AMR hierarchy");
      }
    
    int thicknessComp = -1;
    int zSurfComp = -1;
    int zBaseComp = -1;
    int zTopoComp = -1;
    for (int n=0; n<names.size(); n++)
      {
        if (names[n] == "thickness")
          {
            thicknessComp = n;
          }
        if (names[n] == "Z_surface")
          {
            zSurfComp = n;
          }
        if (names[n] == "Z_bottom")
          {
            zBaseComp = n;
          }
        if (names[n] == "Z_base")
          {
            zTopoComp = n;
          }
      }
    if (thicknessComp < 0)
      {
        MayDay::Error("failed to find thickness in plotfile");
      }

    if (zSurfComp < 0)
      {
        MayDay::Error("failed to find Z_surface in plotfile");
      }

    if (zBaseComp < 0)
      {
        MayDay::Error("failed to find Z_bottom in plotfile");
      }

    if (zTopoComp < 0)
      {
        MayDay::Error("failed to find z_base in plotfile");
      }



    if (verbose)
      {
        pout() << "... done." << endl;
        pout() << endl;
        pout() << "Removing ice on curve..." << endl;
      }

    Real dxLev = crseDx;
    for (int lev=0; lev<numLevels; lev++)
      {
        LevelData<FArrayBox>& thisDataLev = *data[lev];
        
        DataIterator dit = grids[lev].dataIterator();
        for (dit.begin(); dit.ok(); ++dit)
          {
            FArrayBox& thisData = thisDataLev[dit];
            Box thisBox = grids[lev][dit];

            // simplest way to do this -- loop over all x, 
            // compute y intersection point(s) with curve, and then set
            // thickness to zero if there is an intersection in this box

            // then do the same thing, but looping over y instead of xssssss
            
            // eqn for a circle: (x-x0)^2 + (y-y0)^2 = r^2
            // y = y0 +/- sqrt(r^2 - (x-x0)^2) 

            // x loop
            {
              int xlo = thisBox.loVect()[0];
              int xhi = thisBox.hiVect()[0];
              for (int i=xlo; i<=xhi; i++)
                {
                  Real x = (i+0.5)*dxLev;
                  x -= ctr[0];
                  
                  Real discr = radSqr - x*x;
                  if (discr > 0)
                    {
                      Real sqrtDiscr = sqrt(discr);
                      Real mult=-1;
                      for (int polarity = 0;polarity < 2; polarity++)
                        {
                          Real y = ctr[1] + mult*sqrtDiscr;
                        
                          int j = y / dxLev;
                          
                          IntVect iv(D_DECL(i,j,0));
                          
                          if (thisBox.contains(iv))
                            {
                              thisData(iv,thicknessComp) = 0.0;
                              // now modify zSurf, zBase if necessary
                              if (thisData(iv,zBaseComp) != thisData(iv,zTopoComp)) 
                                {
                                  // ice is floating -- set zBase to zero
                                  thisData(iv,zBaseComp) = 0.0;
                                }
                              // now set zSurf to zBase
                              thisData(iv,zSurfComp) = thisData(iv,zBaseComp);
                              
                            } // end if this box contains a point
                          // now check minus root
                          mult *=-1;
                          
                        } // end loop over plusMinus
                      
                    } // end if discr > 0
                } // end loop over i in this box
            } // end x loop

            // y loop
            {
              int ylo = thisBox.loVect()[1];
              int yhi = thisBox.hiVect()[1];
              for (int j=ylo; j<=yhi; j++)
                {
                  Real y = (j+0.5)*dxLev;
                  y -= ctr[1];
                  
                  Real discr = radSqr - y*y;
                  if (discr > 0)
                    {
                      Real sqrtDiscr = sqrt(discr);

                      Real mult=-1;
                      for (int polarity = 0;polarity < 2; polarity++)
                        {
                          Real x = ctr[0] + mult*sqrtDiscr;
                      
                          int i = x / dxLev;
                      
                          IntVect iv(D_DECL(i,j,0));
                      
                          if (thisBox.contains(iv))
                            {
                              thisData(iv, thicknessComp) = 0.0;

                              // now modify zSurf, zBase if necessary
                              if (thisData(iv,zBaseComp) != thisData(iv,zTopoComp)) 
                                {
                                  // ice is floating -- set zBase to zero
                                  thisData(iv,zBaseComp) = 0.0;
                                }
                              // now set zSurf to zBase
                              thisData(iv,zSurfComp) = thisData(iv,zBaseComp);

                            }
                          mult *= -1;
                          
                        } // end loop over plusMinus
                      
                    } // end if discr > 0
                } // end loop over j in this box
            } // end y loop

          } // end loop over boxes on this level

        if (lev < ratio.size())
          {
            dxLev /= ratio[lev];
          }
      } // end loop over levels

    if (verbose)
      {
        pout() << "... done." << endl;
        //pout() << "average down to get output data" << endl;
      }

    // for now, don't bother averaging down
    
    if (verbose)
      {
        pout() << "writing file..." << endl;
      }
    WriteAMRHierarchyHDF5(out_file, grids, data, names, 
			  crseBox, crseDx, dt, time, ratio,numLevels);
    
    
    if (verbose)
      {
        pout() << "... done." << endl;
      }
  
    for (int lev=0; lev<data.size(); lev++)
      {
        if (data[lev] != NULL)
          {
            delete data[lev];
            data[lev] = NULL;
          }
      }
  }  // end nested scope
  CH_TIMER_REPORT();

#ifdef CH_MPI
  MPI_Finalize();
#endif
  return 0;
}

#include "NamespaceFooter.H"
