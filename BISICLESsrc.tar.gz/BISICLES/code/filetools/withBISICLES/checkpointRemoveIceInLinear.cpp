#ifdef CH_LANG_CC
/*
 *      _______              __
 *     / ___/ /  ___  __ _  / /  ___
 *    / /__/ _ \/ _ \/  V \/ _ \/ _ \
*    \___/_//_/\___/_/_/_/_.__/\___/
 *    Please refer to Copyright.txt, in Chombo's root directory.
 */
#endif

//===========================================================================
// checkpointRemoveIce.cpp
// read a BISICLES checkpoint file, along with parameters of a curve
// (center and radius)
// remove ice from finest-level cells which intersect the curve, and write 
// the results back to a modified BISICLES checkpoint file.
//===========================================================================
#include <iostream>
#include "AMRIO.H"
#include "AmrIce.H"
#include "BasicThicknessIBC.H"
#include "MuCoefficient.H"
#include "LoadBalance.H"
#include "ParmParse.H"
#include <fstream>
#include "L1L2ConstitutiveRelation.H"
#include "NamespaceHeader.H"

using std::sqrt;
using std::ifstream;
using namespace std;
bool verbose = true;

IceThicknessIBC* getIBCPtr() {
	// for now, just make this a basicThicknessIBC
	IceThicknessIBC* ibcPtr;
	ibcPtr = new BasicThicknessIBC();
	return ibcPtr;
}

IceTemperatureIBC* getTempIBCPtr() {
	// for now, just use constant -- should be over-ridden by checkpoint anyway
	IceTemperatureIBC* ibcPtr;
	Real T = 258.0;
	ConstantIceTemperatureIBC* ptr = new ConstantIceTemperatureIBC(T);
	ibcPtr = static_cast<IceTemperatureIBC*> (ptr);
	return ibcPtr;
}

ConstitutiveRelation* getConstRel(AmrIce& a_amrObject) {
	std::string constRelType;

	ParmParse pp2("main");

	ConstitutiveRelation* constRelPtr = NULL;

	pp2.get("constitutiveRelation", constRelType);
	GlensFlowRelation* gfrPtr = NULL;
	if (constRelType == "constMu") {
		constMuRelation* newPtr = new constMuRelation;
		ParmParse crPP("constMu");
		Real muVal;
		crPP.get("mu", muVal);
		newPtr->setConstVal(muVal);
		constRelPtr = static_cast<ConstitutiveRelation*> (newPtr);
	} else if (constRelType == "GlensLaw") {
		constRelPtr = new GlensFlowRelation;
		gfrPtr = dynamic_cast<GlensFlowRelation*> (constRelPtr);
	} else if (constRelType == "L1L2") {
		L1L2ConstitutiveRelation* l1l2Ptr = new L1L2ConstitutiveRelation;
		l1l2Ptr->parseParameters();
		gfrPtr = l1l2Ptr->getGlensFlowRelationPtr();
		constRelPtr = l1l2Ptr;
	} else {
		MayDay::Error("bad Constitutive relation type");
	}
	std::string rateFactorType = "constRate";
	pp2.query("rateFactor", rateFactorType);
	if (rateFactorType == "constRate") {
		ParmParse crPP("constRate");
		Real A = 9.2e-18;
		crPP.query("A", A);
		ConstantRateFactor rateFactor(A);

		a_amrObject.setRateFactor(&rateFactor);
	} else if (rateFactorType == "arrheniusRate") {
		ArrheniusRateFactor rateFactor;
		ParmParse arPP("ArrheniusRate");
		a_amrObject.setRateFactor(&rateFactor);
	} else if (rateFactorType == "patersonRate") {
		PatersonRateFactor rateFactor;
		ParmParse arPP("PatersonRate");
		a_amrObject.setRateFactor(&rateFactor);
	}
	return constRelPtr;
}

enum DIR {
	DIR_H = 1, // horizontal direction, along the X-axis
	DIR_V = 2,// vertical direction, along the Y-axis
	DIR_H_L = 3, // left
	DIR_H_R = 4, // right
	DIR_V_U = 5, // up
	DIR_V_D = 6
// down
};

enum SHAPETYPE {
	CONNECTED = 1, // next point is the end point of previous one
	STAIR = 2
// next point is one above/left/right/up cell of the previous point
};

struct DrawInstruction {
	DIR dir;
	int numCells;
	DIR nextDrawDir;
};
struct Line {
	DIR dir;
	IntVect start;
	IntVect end;
	int numCells;
};

IntVect rightShiftV = BASISV(0); // => (1, 0 )
IntVect leftShiftV = -1 * BASISV(0); // => (-1, 0 )
IntVect downShiftV = -1 * BASISV(1); // => (0, -1 )
IntVect upShiftV = BASISV(1); // => (0, 1 )


DIR getDir(int dir) {
	DIR destDir = DIR_H_L;
	switch (dir) {
	case 3:
		destDir = DIR_H_L;
		break;
	case 4:
		destDir = DIR_H_R;
		break;
	case 5:
		destDir = DIR_V_U;
		break;
	case 6:
		destDir = DIR_V_D;
		break;
	default:
		pout() << "direction [ " << dir
				<< " ] in the input file is not supported "
				<< " fall back to DIR_H_L" << endl;
	}
	return destDir;
}

bool checkIntersection(const Box &thisBox, const Line & line) {
	IntVect loP = thisBox.smallEnd();
	IntVect hiP = thisBox.bigEnd();

	if (line.dir == DIR_H) {
		// start[0] always is <= end[0]
		return ((loP[1] <= line.start[1] && line.start[1] <= hiP[1])
				&& !(loP[0] > line.end[0] || hiP[0] < line.start[0]));
	} else if (line.dir == DIR_V) {
		//start[1] always is <= end[1]
		return ((loP[0] <= line.start[0] && line.start[0] <= hiP[0])
				&& !(loP[1] > line.end[1] || hiP[1] < line.start[1])); // patch has intersection w/ line
	}
	return false;
}

vector<Line> genShapeOutline(RealVect ctrPoint, Real dxLev,
		vector<DrawInstruction> instructions, int lev, Vector<int> & ratio,
		SHAPETYPE shapeType) {
	IntVect start;
	start[0] = ctrPoint[0] / dxLev;
	start[1] = ctrPoint[1] / dxLev; //convertToPatchCordinate(ctrPoint, dxLev);
	vector<Line> lines;
	for (int l = 0; l < instructions.size(); l++) {
		Line line;
		IntVect end = start;
		DrawInstruction inst = instructions[l];
		int numCells = inst.numCells;
		for (int r = 0; r < lev; r++) { // refining numCells as well on fine level
			numCells = numCells * ratio[r];
		}
		switch (inst.dir) {
		case DIR_H_L: // reverse start & end => end > start
			end = start + (numCells - 1) * leftShiftV;
			line.dir = DIR_H;
			break;
		case DIR_H_R:
			end = start + (numCells - 1) * rightShiftV; // including start point
			line.dir = DIR_H;
			break;
		case DIR_V_U:
			end = start + (numCells - 1) * upShiftV; // including start point
			line.dir = DIR_V;
			break;
		case DIR_V_D: // reverse start & end  => end > start
			end = start + (numCells - 1) * downShiftV;
			line.dir = DIR_V;
			break;
		default:
			pout() << "not supported dir " << inst.dir << endl;
		}
		line.numCells = numCells;
		line.start = start;
		line.end = end;
		lines.push_back(line);

		if (shapeType == STAIR) {
			switch (inst.nextDrawDir) {
			case DIR_H_L:
				end += leftShiftV;
				break;
			case DIR_H_R:
				end += rightShiftV;
				break;
			case DIR_V_U:
				end += upShiftV;
				break;
			case DIR_V_D:
				end += downShiftV;
				break;
			default:
				pout() << "not supported dir for nextDrawDir "
						<< inst.nextDrawDir << endl;
			}
		}

		start = end;

	}

	return lines;
}

/*
 * see if the line formed by start point and end point intersects with the patch
 */

void cutWithLines(Real & crseDx, int & numLevels,
		Vector<LevelData<FArrayBox> *> & data, RealVect ctrPoint,
		vector<DrawInstruction> instructions, int thicknessComp,
		Vector<int> & ratio, SHAPETYPE shapeType) {
	if (verbose) {
		pout() << "number levels: " << numLevels;
		pout() << " ratios: ";
		for (int i = 0; i < ratio.size(); i++) {
			pout() << ratio[i] << ",";
		}
		pout() << endl;
	}
	std::vector<int> counts(numLevels, 0);
	Real dxLev = crseDx;
	for (int lev = 0; lev < numLevels; lev++) {

		vector<Line> lines = genShapeOutline(ctrPoint, dxLev, instructions,
				lev, ratio, shapeType);
		for (int l = 0; l < lines.size(); l++) {
			Line line = lines[l];
			Line validLine;
			validLine.dir = line.dir;
			validLine.numCells = line.numCells;
			validLine.start = line.start;
			validLine.end = line.end;
			if ((line.start[0] > line.end[0]) || line.start[1] > line.end[1]) {
				validLine.start = line.end;
				validLine.end = line.start;
			}

			LevelData<FArrayBox> & thisDataLev = *data[lev];
			const DisjointBoxLayout grids = thisDataLev.getBoxes();
			DataIterator dit = grids.dataIterator();
			for (dit.begin(); dit.ok(); ++dit) {
				FArrayBox & thisData = thisDataLev[dit];
				Box thisBox = grids[dit];

				if (checkIntersection(thisBox, validLine)) {
					IntVect loP = thisBox.smallEnd();
					IntVect hiP = thisBox.bigEnd();
					IntVect size = thisBox.size();
					pout() << "Line [" << l << "] intersects with patch {"
							<< loP << "," << hiP << "}" << endl;
					IntVect lineStart = validLine.start;
					IntVect lineEnd = validLine.end;
					IntVect currentPtr = loP;
					int column = size[0]; // column = 48 - 23 + 1 = 26
					int row = size[1]; // row = 64 - 31 + 1 = 34
					if (!thisBox.isEmpty()) { // go through the patch, check whether the points are on the line
						for (int r = 0; r < row; r++) {
							for (int c = 0; c < column; c++) {
								if (lineStart[0] <= currentPtr[0]
										&& currentPtr[0] <= lineEnd[0]
										&& lineStart[1] <= currentPtr[1]
										&& currentPtr[1] <= lineEnd[1]
										&& thisData(currentPtr, thicknessComp)
												> 0.0) {
									thisData(currentPtr, thicknessComp) = 0.0;
									// now modify zSurf, zBase if necessary
									/*if (thisData(currentPtr, zBaseComp) != thisData(currentPtr,
									 zTopoComp)) {
									 // ice is floating -- set zBase to zero
									 thisData(currentPtr, zBaseComp) = 0.0;
									 }
									 // now set zSurf to zBase
									 thisData(currentPtr, zSurfComp) = thisData(currentPtr, zBaseComp);*/
									counts[lev]++;
								}

								currentPtr = currentPtr + rightShiftV; // move to right

							}
							currentPtr.setVal(0, loP[0]);//reset to original value at first dimension direction
							currentPtr = currentPtr + upShiftV; // move up
						}
					}
				}

			} // end loop over boxes on this level

		}

		if (lev < ratio.size()) {
			dxLev /= ratio[lev];
		}
	} // end loop over levels

	if (verbose) {

		pout() << " modifying  cells " << endl;
		for (int i = 0; i < numLevels; i++) {
			pout() << "level[" << i << "] has modified " << counts[i]
					<< " cells" << endl;
		}
		pout() << "... done." << endl;
	}
}

// -----------------------------------------------------------
//   main program
// -----------------------------------------------------------

int main(int argc, char* argv[]) {

#ifdef CH_MPI
	MPI_Init(&argc, &argv);
#endif

	// Begin nested scope
#ifdef CH_MPI
	MPI_Barrier(Chombo_MPI::comm);
#endif
	int rank, number_procs;
#ifdef CH_MPI
	MPI_Comm_rank(Chombo_MPI::comm, &rank);
	MPI_Comm_size(Chombo_MPI::comm, &number_procs);
#else
	rank = 0;
	number_procs = 1;
#endif

	if (argc < 2) {
		std::cerr << " usage: " << argv[0] << " <input_file> " << std::endl;
		exit(0);
	}

	char* input_file = argv[1];
	ParmParse pp(argc - 2, argv + 2, NULL, input_file);
	ParmParse pp2("main");

	// do we want to write out plotfiles of before and after ice thickness?
	//bool writeThicknessPlots = false;
//	pp2.query("write_thickness_plots", writeThicknessPlots); //since this option is not working, i just ignore it

	// now set up AmrObject defined from checkpoint file

	// for this to work, there needs to be a restart file and
	// check_overwrite should be set to "true"

	ParmParse ppAmr("amr");
	if (!ppAmr.contains("restart_file")) {
		MayDay::Error("amr.restart_file must be present in inputs file");
	}

	// allocate AmrIce object


	if (verbose) {
		pout() << "allocating AmrIce object..." << endl;
	}

	AmrIce amrObject;

	// ---------------------------------------------
	// set constitutive relation & rate factor
	// ---------------------------------------------

	ConstitutiveRelation* constRelPtr = getConstRel(amrObject);

	amrObject.setConstitutiveRelation(constRelPtr);

	// need to set *something* for the ibcPtr
	IceThicknessIBC* thicknessIBC = getIBCPtr();

	amrObject.setThicknessBC(thicknessIBC);

	IceTemperatureIBC* temperatureIBC = getTempIBCPtr();
	amrObject.setTemperatureBC(temperatureIBC);

	// ---------------------------------------------
	// set mu coefficient
	// ---------------------------------------------
	std::string muCoefType = "unit";
	if (muCoefType == "unit") {
		MuCoefficient* ptr =
				static_cast<MuCoefficient*> (new UnitMuCoefficient());
		amrObject.setMuCoefficient(ptr);
		delete ptr;
	}

	// ---------------------------------------------
	// set basal friction coefficient and relation
	// ---------------------------------------------

	ParmParse geomPP("geometry");

	BasalFriction* basalFrictionPtr = NULL;

	std::string beta_type = "constantBeta";

	// read in type of beta^2 distribution

	if (beta_type == "constantBeta") {
		Real betaVal = 1000;
		//geomPP.get("betaValue", betaVal);
		basalFrictionPtr = static_cast<BasalFriction*> (new constantFriction(
				betaVal));
	}
	amrObject.setBasalFriction(basalFrictionPtr);

	amrObject.initialize();

	if (verbose) {
		pout() << "... done." << endl;
		pout() << endl;
	}

	const Vector<RefCountedPtr<LevelSigmaCS> >& amrGeom =
			amrObject.amrGeometry();

	Vector<LevelData<FArrayBox>*> thicknessVect(amrGeom.size(), NULL);
	Vector<LevelData<FArrayBox>*> plotData(amrGeom.size(), NULL);

	for (int lev = 0; lev < thicknessVect.size(); lev++) {
		// cast away const-ness here:
		thicknessVect[lev]
				= const_cast<LevelData<FArrayBox>*> (&amrGeom[lev]->getH());
	}

	int numLevels = thicknessVect.size();
	Real crseDx = amrGeom[0]->dx()[0];
	int thicknessComp = 0;
	Vector<int> ratios = amrObject.refRatios();
	//Real dxLev = crseDx;

	//ParmParse root(argc - 2, argv + 2, NULL, cut_file);
	ParmParse root("main_cuts");
	int numCuts;
	root.query("num_cuts", numCuts);
	char cutName[250];

	for (int c = 0; c < numCuts; c++) {
		sprintf(cutName, "cut_%d", c);
		ParmParse pp(cutName);

		int numdraws;
		pp.query("num_draw", numdraws);
		int shapeTypeIpt;
		pp.query("shape_type", shapeTypeIpt);
		SHAPETYPE shapeType = CONNECTED;
		if (shapeTypeIpt == 1) {
			shapeType = CONNECTED;
		} else if (shapeTypeIpt == 2) {
			shapeType = STAIR;
		} else {
			pout() << "not supported line generated type " << shapeTypeIpt
					<< " it would fall back to CONNECTED type" << endl;
		}
		Vector<Real> ctrPoint(SpaceDim);
		pp.getarr("ctr_point", ctrPoint, 0, SpaceDim);
		RealVect ctrPt(D_DECL(ctrPoint[0], ctrPoint[1], 0));
		int i = 0;
		vector<DrawInstruction> insts;
		while (i < numdraws) {
			char name[250];
			DrawInstruction inst;
			sprintf(name, "draw_%d", i);
			if (shapeType == CONNECTED) {
				Vector<Real> draw(2);
				pp.getarr(name, draw, 0, 2);
				int dir = draw[0];
				inst.dir = getDir(dir);
				inst.numCells = draw[1];
			} else if (shapeType == STAIR) { // this is not used
				Vector<Real> draw(3);
				pp.getarr(name, draw, 0, 3);
				int dir = draw[0];
				inst.dir = getDir(dir);
				inst.numCells = draw[1];
				int nextdir = draw[2];
				inst.nextDrawDir = getDir(nextdir);
			}

			insts.push_back(inst);
			i++;
		}

		cutWithLines(crseDx, numLevels, thicknessVect, ctrPt, insts,
				thicknessComp, ratios, shapeType);
	}

	if (verbose) {
		pout() << "... done." << endl;
		//pout() << "average down to get output data" << endl;
	}

	// for now, don't bother averaging down


	// update geometries
	LevelSigmaCS* crsePtr = NULL;
	int crseRatio = 2;
	for (int lev = 0; lev < numLevels; lev++) {
		const LevelSigmaCS* thisCS_const = amrGeom[lev];
		LevelSigmaCS* thisCS = const_cast<LevelSigmaCS*> (thisCS_const);
		thisCS->recomputeGeometry(crsePtr, crseRatio);
		crsePtr = thisCS;
		if (lev < ratios.size()) {
			crseRatio = ratios[lev];
		}
	}

	// now write checkpoint with new data
	if (verbose) {
		pout() << "writing new checkpoint file..." << endl;
	}
	amrObject.writeCheckpointFile();

	if (verbose) {
		pout() << "... done." << endl;
	}

	CH_TIMER_REPORT();

#ifdef CH_MPI
	MPI_Finalize();
#endif
	return 0;
}

#include "NamespaceFooter.H"
