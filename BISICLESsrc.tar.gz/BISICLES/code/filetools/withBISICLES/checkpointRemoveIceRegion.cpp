 #ifdef CH_LANG_CC
/*
*      _______              __
*     / ___/ /  ___  __ _  / /  ___
*    / /__/ _ \/ _ \/  V \/ _ \/ _ \
*    \___/_//_/\___/_/_/_/_.__/\___/
*    Please refer to Copyright.txt, in Chombo's root directory.
*/
#endif

//===========================================================================
// checkpointRemoveIce.cpp
// read a BISICLES checkpoint file, along with parameters of a rectangular 
// region (low and high locations xlo ylo xhi yhi
// remove ice from all cells which fall inside this region,  and write 
// the results back to a modified BISICLES checkpoint file.
//===========================================================================
#include <iostream>
#include "AMRIO.H"
#include "AmrIce.H"
#include "BasicThicknessIBC.H"
#include "MuCoefficient.H"
#include "LoadBalance.H"
#include "ParmParse.H"
#include <fstream>
#include "L1L2ConstitutiveRelation.H"
#include "NamespaceHeader.H"

using std::sqrt;
using std::ifstream;
using namespace std;

bool verbose = true;

IceThicknessIBC* getIBCPtr()
{
  // for now, just make this a basicThicknessIBC
  IceThicknessIBC* ibcPtr;
  ibcPtr = new BasicThicknessIBC();
  return ibcPtr;
}

IceTemperatureIBC* getTempIBCPtr()
{
  // for now, just use constant -- should be over-ridden by checkpoint anyway
  IceTemperatureIBC* ibcPtr;
  Real T = 258.0;
  ConstantIceTemperatureIBC* ptr = new ConstantIceTemperatureIBC(T);
  ibcPtr  = static_cast<IceTemperatureIBC*>(ptr);
  return ibcPtr;
}

ConstitutiveRelation* getConstRel(AmrIce& a_amrObject)
{
  std::string constRelType;

  ParmParse pp2("main");
  
  ConstitutiveRelation* constRelPtr = NULL;

  pp2.get("constitutiveRelation", constRelType);
  GlensFlowRelation* gfrPtr = NULL;
  if (constRelType == "constMu")
    {
      constMuRelation* newPtr = new constMuRelation;
      ParmParse crPP("constMu");
      Real muVal;
      crPP.get("mu", muVal);
      newPtr->setConstVal(muVal);
      constRelPtr = static_cast<ConstitutiveRelation*>(newPtr);
    }
  else if (constRelType == "GlensLaw")
    {
      constRelPtr = new GlensFlowRelation;
      gfrPtr = dynamic_cast<GlensFlowRelation*>(constRelPtr);
    }
  else if (constRelType == "L1L2")
    {
      L1L2ConstitutiveRelation* l1l2Ptr = new L1L2ConstitutiveRelation;
      l1l2Ptr->parseParameters();
      gfrPtr = l1l2Ptr->getGlensFlowRelationPtr();
      constRelPtr = l1l2Ptr;
    }
  else 
    {
      MayDay::Error("bad Constitutive relation type");
    }
  std::string rateFactorType = "constRate";
  pp2.query("rateFactor", rateFactorType);
  if (rateFactorType == "constRate")
    {
      ParmParse crPP("constRate");
      Real A = 9.2e-18;
      crPP.query("A", A);
      ConstantRateFactor rateFactor(A);
      
      a_amrObject.setRateFactor(&rateFactor);
    }
  else if (rateFactorType == "arrheniusRate")
    {
      ArrheniusRateFactor rateFactor;
      ParmParse arPP("ArrheniusRate");
      a_amrObject.setRateFactor(&rateFactor);
    }
  else if (rateFactorType == "patersonRate")
    {
      PatersonRateFactor rateFactor;
      ParmParse arPP("PatersonRate");
      a_amrObject.setRateFactor(&rateFactor);
    }
  return constRelPtr;
}
  
// -----------------------------------------------------------
//   main program
// -----------------------------------------------------------

int main(int argc, char* argv[]) {

#ifdef CH_MPI
  MPI_Init(&argc, &argv);
#endif

  { // Begin nested scope
#ifdef CH_MPI
    MPI_Barrier(Chombo_MPI::comm);
#endif
    int rank, number_procs;
#ifdef CH_MPI
    MPI_Comm_rank(Chombo_MPI::comm, &rank);
    MPI_Comm_size(Chombo_MPI::comm, &number_procs);
#else
    rank=0;
    number_procs=1;
#endif

    if(argc < 2) 
      { 
	std::cerr << " usage: " << argv[0] << " <input_file> " << std::endl; 
	exit(0); 
      }

    char* input_file = argv[1];
    ParmParse pp(argc-2,argv+2,NULL, input_file);
    ParmParse pp2("main");

    
    // do we want to write out plotfiles of before and after ice thickness?
    bool writeThicknessPlots = false;
    pp2.query("write_thickness_plots", writeThicknessPlots);

    
    // now set up AmrObject defined from checkpoint file
    
    // for this to work, there needs to be a restart file and
    // check_overwrite should be set to "true"

    ParmParse ppAmr("amr");
    if (!ppAmr.contains("restart_file"))
      {
        MayDay::Error("amr.restart_file must be present in inputs file");
      }

    // allocate AmrIce object


    if (verbose) 
      {
        pout() << "allocating AmrIce object..." << endl;
      }


    AmrIce amrObject;

    // ---------------------------------------------
    // set constitutive relation & rate factor
    // ---------------------------------------------

    ConstitutiveRelation* constRelPtr = getConstRel(amrObject);

    amrObject.setConstitutiveRelation(constRelPtr);

    // need to set *something* for the ibcPtr
    IceThicknessIBC* thicknessIBC = getIBCPtr();

    amrObject.setThicknessBC(thicknessIBC);

    IceTemperatureIBC* temperatureIBC = getTempIBCPtr();
    amrObject.setTemperatureBC(temperatureIBC);


    // ---------------------------------------------
    // set mu coefficient
    // ---------------------------------------------
    std::string muCoefType = "unit";
    if (muCoefType == "unit")
      {
	MuCoefficient* ptr = static_cast<MuCoefficient*>(new UnitMuCoefficient());
	amrObject.setMuCoefficient(ptr);
	delete ptr;
      }


    // ---------------------------------------------
    // set basal friction coefficient and relation
    // ---------------------------------------------

    ParmParse geomPP("geometry");
    
    BasalFriction* basalFrictionPtr = NULL;

    std::string beta_type = "constantBeta";

    // read in type of beta^2 distribution
    
    if (beta_type == "constantBeta")
      {
        Real betaVal = 1000;
        //geomPP.get("betaValue", betaVal);
        basalFrictionPtr = static_cast<BasalFriction*>(new constantFriction(betaVal));
      }
    amrObject.setBasalFriction(basalFrictionPtr);

    amrObject.initialize();

    if (verbose)
      {
        pout() << "... done." << endl;
        pout() << endl;
      }

    std::string region_file;
    pp2.get("removal_region_file", region_file);


    if (verbose)
      {
        pout() << "reading " << region_file << "..." << endl;
      }

    // format of ice-removal region file: 
    // number of (rectangular removal regions
    // then, for each region
    // xlo ylo xhi yhi

    int num_regions = 0;
    Vector<RealVect> loVects;
    Vector<RealVect> hiVects;

    
    ifstream is(region_file.c_str(), ios::in);
    
    if (is.fail())
      {
        MayDay::Error("cannot open cut specification file");
      }
    
    is >> num_regions;
    while (is.get() != '\n');
    CH_assert(num_regions >= 0);

    loVects.resize(num_regions);
    hiVects.resize(num_regions);

    for (int n=0; n<num_regions; n++)
      {
        // set cut parameters
        D_TERM( is >> loVects[n][0];, 
                is >> loVects[n][1];, 
                is >> loVects[n][2];)
        D_TERM( is >> hiVects[n][0];, 
                is >> hiVects[n][1];, 
                is >> hiVects[n][2];)
        
        while (is.get() != '\n');

        if (verbose) 
          {
            pout() << "Ice Removal region " << n << ": lo = "
                   << loVects[n]
                   << " hi = " << hiVects[n] << endl;
          }
      } // end loop over n_linear
    
    if (verbose)
      {
        pout() << "... done." << endl;
        pout() << endl;
        pout() << "Removing ice on " << num_regions << " regions. " 
               << endl;
      }


    
    const Vector<RefCountedPtr<LevelSigmaCS>  >& amrGeom = amrObject.amrGeometry();

    Vector<LevelData<FArrayBox>* > thicknessVect(amrGeom.size(), NULL);

    int finest_level = -1;
    for (int lev=0; lev<thicknessVect.size(); lev++)
      {
        // cast away const-ness here:
        if (!amrGeom[lev].isNull())
          {
            thicknessVect[lev] = const_cast<LevelData<FArrayBox>* >(&amrGeom[lev]->getH());
            finest_level++;
          }
      }

    int numLevels = finest_level +1;
    Vector<LevelData<FArrayBox>* > plotData(numLevels, NULL);


    Real crseDx = amrGeom[0]->dx()[0];
    int thicknessComp = 0;
    Vector<int> ratios = amrObject.refRatios();
    
    Real dxLev = crseDx;
    for (int lev=0; lev<numLevels; lev++)
      {
        LevelData<FArrayBox>& thisDataLev = *thicknessVect[lev];
        const DisjointBoxLayout grids = thisDataLev.getBoxes();

        // allocate storage for plot data if needed
        if (writeThicknessPlots)
          {
            plotData[lev] = new LevelData<FArrayBox>(grids, 3, IntVect::Zero);
            Interval thicknessInterval(0,0);
            thisDataLev.copyTo(thicknessInterval, *plotData[lev], 
                               thicknessInterval);
            // component 2 will be (old - new)
            Interval diffInterval(2,2);
            thisDataLev.copyTo(thicknessInterval, *plotData[lev], 
                               diffInterval);            
            
          }

        DataIterator dit = grids.dataIterator();
        int boxno = 0;
        for (dit.begin(); dit.ok(); ++dit)
          {
            FArrayBox& thisData = thisDataLev[dit];
            Box thisBox = grids[dit];
            //pout() << "boxno = " << boxno << endl;

            // then do the same thing, but looping over y instead of x
            for (int n=0; n<num_regions; n++)
              {
                int ilo = thisBox.loVect()[0];
                int ihi = thisBox.hiVect()[0];
                int jlo = thisBox.loVect()[1];
                int jhi = thisBox.hiVect()[1];

                Real xlo = ilo * dxLev;
                Real ylo = jlo * dxLev;
                Real xhi = (ihi+1)*dxLev;
                Real yhi = (jhi+1)*dxLev;

                RealVect boxLo(D_DECL(xlo,ylo,zlo));
                RealVect boxHi(D_DECL(xhi,yhi,zhi));
                
                boxLo.max(loVects[n]);
                boxHi.min(hiVects[n]);

                // is there an intersection?
                if (boxLo <= boxHi)
                  {
                    BoxIterator bit(thisBox);
                    for (bit.begin(); bit.ok(); ++bit)
                      {
                        IntVect iv = bit();
                        RealVect thisLo(iv);

                        // this cell extents
                        thisLo *= dxLev;
                        RealVect thisHi(iv);
                        thisHi += RealVect::Unit;
                        thisHi *= dxLev;
                        
                        // intersect with region
                        thisLo.max(boxLo);
                        thisHi.min(boxHi);

                        if (thisLo <= thisHi)
                          {
                            thisData(iv,thicknessComp) = 0.0;
                          } // end if iv is in removal region
                      } // end loop over cells in this box
                  } // end if this box intersects removal region
              } // end loop over removal regions


            boxno++;
          } // end loop over boxes on this level
        
        if (writeThicknessPlots)
          {
            Interval thicknessInterval(0,0);
            Interval destInterval(1,1);
            thisDataLev.copyTo(thicknessInterval, *plotData[lev], 
                               destInterval);
            Interval diffInterval(2,2);
            
            DataIterator dit = grids.dataIterator();
            for (dit.begin(); dit.ok(); ++dit)
              {
                FArrayBox& thisData = (*plotData[lev])[dit];
                thisData.minus(thisData,1,2,1);
              }

          }

        if (lev < finest_level)
          {
            dxLev /= ratios[lev];
          }
      } // end loop over levels

    if (verbose)
      {
        pout() << "... done." << endl;
        //pout() << "average down to get output data" << endl;
      }

    // for now, don't bother averaging down
    

    // update geometries
    LevelSigmaCS* crsePtr = NULL;
    int crseRatio = 2;
    for (int lev=0; lev<numLevels; lev++)
      {
        const LevelSigmaCS* thisCS_const = amrGeom[lev];
        LevelSigmaCS* thisCS = const_cast<LevelSigmaCS*>(thisCS_const);
        thisCS->recomputeGeometry(crsePtr, crseRatio);
        crsePtr = thisCS;
        if (lev < finest_level)
          {
            crseRatio = ratios[lev];
          }
      }
    
    
    if (writeThicknessPlots)
      {
        // turn this off because it can tickle unset data fields
        // (like surface flux)
        //amrObject.writePlotFile();

        string fname = "thickness.2d.hdf5";
        Vector<string> vectNames(3);
        vectNames[0] = "old_thickness";
        vectNames[1] = "new_thickness";
        vectNames[2] = "thickness_diff";
        const Vector<DisjointBoxLayout>& amrGrids = amrObject.amrGrids();
        WriteAMRHierarchyHDF5(fname,
                              amrGrids,
                              plotData,
                              vectNames,
                              amrGrids[0].physDomain().domainBox(),
                              crseDx,
                              amrObject.dt(),
                              amrObject.time(),
                              ratios,
                              plotData.size());
      }

    // now write checkpoint with new data
    if (verbose)
      {
        pout() << "writing new checkpoint file..." << endl;
      }
    amrObject.writeCheckpointFile();
    
        
    if (verbose)
      {
        pout() << "... done." << endl;
      }
  }  // end nested scope
  CH_TIMER_REPORT();
  
#ifdef CH_MPI
  MPI_Finalize();
#endif
  return 0;
}

#include "NamespaceFooter.H"
