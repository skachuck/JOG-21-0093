#!/bin/csh -f

if ($#argv < 2) then
  echo "Usage:  glxGraph.sh  <infile> <outfile>  "
  exit 1
endif

glxLoc.awk < $1 >! temp1.out
cat $2 temp1.out > temp2.out
/bin/mv temp2.out $2
