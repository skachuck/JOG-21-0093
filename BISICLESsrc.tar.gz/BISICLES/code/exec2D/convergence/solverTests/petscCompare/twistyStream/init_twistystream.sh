#!/bin/sh
EXECFILE1=../../../../driver2d.Linux.64.mpiCC.mpif90.OPT.MPI.PETSC.ex 
EXECFILE2=../../../../driver2d.Linux.64.mpiCC.gfortran.OPT.MPI.ex 
COMPAREEXEC=compare2d
INFILE1_TEMPLATE=inputs.petsc.template
INFILE1_BASE=inputs.petsc
INFILE2_TEMPLATE=inputs.petscCompare.template
INFILE2_BASE=inputs.petscCompare
SCRIPTDIR=../../../../scripts
TEMPFILE=temp.out
NPROC=1

#function to set tagging values
gettagval()
{
   case $RES in
     0032) TAGVAL="4.0";;
     0064) TAGVAL="1.0";; 
     0128) TAGVAL="0.25";; 
     0256) TAGVAL="0.0625";; 
     0512) TAGVAL="0.015625";; 
     1024) TAGVAL="0.00390625";; 
     2048) TAGVAL="0.0009765625";; 
     *) echo "Unanticipated RES val for Tagging values";;
   esac
}

#function to set tagging values
gettagval3lev()
{
   case $RES in
     0032) TAGVAL="1.0";; 
     0064) TAGVAL="0.25";; 
     0128) TAGVAL="0.0625";; 
     0256) TAGVAL="0.015625";; 
     0512) TAGVAL="0.00390625";; 
     *) echo "Unanticipated RES val for Tagging values";;
   esac
}


CRSERES="0032"
FINESTRES=2048
RUNFILE1=doRuns.petsc
RUNFILE2=doRuns.MG-JFNK
if [ -f $RUNFILE ]; then
  echo "deleting $RUNFILE1, $RUNFILE2"
  rm $RUNFILE1
  rm $RUNFILE2
fi
echo "generating single-level inputs"
for RES in 0032 0064 0128 0256 0512 1024 2048  
do
    gettagval
    MAXLEV=0
    YRES=$RES
    echo $RES 
    of1=$INFILE1_BASE.$RES
    of2=$INFILE2_BASE.$RES
    sed  -e s/@RES/$RES/ -e s/@YRES/$RES/ -e s/@MAXLEV/$MAXLEV/ -e s/@TAGVAL/$TAGVAL/  $INFILE1_TEMPLATE > $of1
    sed  -e s/@RES/$RES/ -e s/@YRES/$RES/ -e s/@MAXLEV/$MAXLEV/ -e s/@TAGVAL/$TAGVAL/ $INFILE2_TEMPLATE > $of2

    outfile1="run.petsc-gamg.$RES"
    innerConvergename1="solverConverge/resid.petsc-gamg.$RES"
    outerConvergename1="solverConverge/resid.petsc-gamg.$RES.outer"
    poutname1="pout.petsc-gamg.$RES"
    runcommand1="mpirun -np $NPROC $EXECFILE1 $of1 > $outfile1"
    echo "echo \"doing $RES run\" " >> $RUNFILE1
    echo $runcommand1 >> $RUNFILE1
    echo "mv pout.0 $poutname1" >> $RUNFILE1
    echo "$SCRIPTDIR/innerPetsc.awk < $outfile1 > $TEMPFILE " >> $RUNFILE1
    echo "$SCRIPTDIR/a.out $TEMPFILE  $innerConvergename1" >> $RUNFILE1
    echo "$SCRIPTDIR/petsc.awk < $outfile1 > $outerConvergename1" >> $RUNFILE1

    outfile2="run.MG-JFNK.$RES"
    innerConvergename2="solverConverge/resid.MG-JFNK.$RES"
    outerConvergename2="solverConverge/resid.MG-JFNK.$RES.outer"
    runcommand2="mpirun -np $NPROC $EXECFILE2 $of2 > $outfile2"
    echo "echo \"doing $RES run\" " >> $RUNFILE2
    poutname2="pout.MG-JFNK.$RES"
    echo $runcommand2 >> $RUNFILE2
    echo "mv pout.0 $poutname2 " >> $RUNFILE2
    echo "$SCRIPTDIR/innerJFNK.awk < $poutname2 > $TEMPFILE " >> $RUNFILE2
    echo "$SCRIPTDIR/a.out $TEMPFILE  $innerConvergename2" >> $RUNFILE2
    echo "$SCRIPTDIR/jfnk.awk < $poutname2 > $outerConvergename2" >> $RUNFILE2

chmod +x $RUNFILE1
chmod +x $RUNFILE2


CRSERES=$RES
done 


#now do 2-level inputs
CRSERES="0032"
FINESTRES=1024
RUNFILE1=doRuns.2Ref.petsc
RUNFILE2=doRuns.2Ref.MG-JFNK
INFILE1_TEMPLATE=inputs.petsc.template
INFILE1_BASE=inputs.petsc.2Ref
INFILE2_BASE=inputs.petscCompare.2Ref
if [ -f $RUNFILE ]; then
  echo "deleting $RUNFILE1, $RUNFILE2"
  rm $RUNFILE1
  rm $RUNFILE2
fi
echo "generating single-level inputs"
for RES in 0032 0064 0128 0256 0512 1024 
do
    gettagval
    MAXLEV=1
    YRES=$RES
    echo $RES 
    of1=$INFILE1_BASE.$RES
    of2=$INFILE2_BASE.$RES
    sed  -e s/@RES/$RES/ -e s/@YRES/$RES/ -e s/@MAXLEV/$MAXLEV/ -e s/@TAGVAL/$TAGVAL/  $INFILE1_TEMPLATE > $of1
    sed  -e s/@RES/$RES/ -e s/@YRES/$RES/ -e s/@MAXLEV/$MAXLEV/ -e s/@TAGVAL/$TAGVAL/ $INFILE2_TEMPLATE > $of2

    outfile1="run.petsc-gamg.2Ref.$RES"
    innerConvergename1="solverConverge/resid.petsc-gamg.2Ref.$RES"
    outerConvergename1="solverConverge/resid.petsc-gamg.2Ref.$RES.outer"
    poutname1="pout.petsc-gamg.2Ref.$RES"
    runcommand1="mpirun -np $NPROC $EXECFILE1 $of1 > $outfile1"
    echo "echo \"doing 2-level $RES run\" " >> $RUNFILE1
    echo $runcommand1 >> $RUNFILE1
    echo "mv pout.0 $poutname1" >> $RUNFILE1
    echo "$SCRIPTDIR/innerPetsc.awk < $outfile1 > $TEMPFILE " >> $RUNFILE1
    echo "$SCRIPTDIR/a.out $TEMPFILE  $innerConvergename1" >> $RUNFILE1
    echo "$SCRIPTDIR/petsc.awk < $outfile1 > $outerConvergename1" >> $RUNFILE1

    outfile2="run.MG-JFNK.2Ref.$RES"
    innerConvergename2="solverConverge/resid.MG-JFNK.2Ref.$RES"
    outerConvergename2="solverConverge/resid.MG-JFNK.2Ref.$RES.outer"
    runcommand2="mpirun -np $NPROC $EXECFILE2 $of2 > $outfile2"
    echo "echo \"doing 2-level $RES run\" " >> $RUNFILE2
    poutname2="pout.MG-JFNK.2Ref.$RES"
    echo $runcommand2 >> $RUNFILE2
    echo "mv pout.0 $poutname2 " >> $RUNFILE2
    echo "$SCRIPTDIR/innerJFNK.awk < $poutname2 > $TEMPFILE " >> $RUNFILE2
    echo "$SCRIPTDIR/a.out $TEMPFILE  $innerConvergename2" >> $RUNFILE2
    echo "$SCRIPTDIR/jfnk.awk < $poutname2 > $outerConvergename2" >> $RUNFILE2

chmod +x $RUNFILE1
chmod +x $RUNFILE2


CRSERES=$RES
done 


exit 0


