#ifdef CH_LANG_CC
/*
*      _______              __
*     / ___/ /  ___  __ _  / /  ___
*    / /__/ _ \/ _ \/  V \/ _ \/ _ \
*    \___/_//_/\___/_/_/_/_.__/\___/
*    Please refer to Copyright.txt, in Chombo's root directory.
*/
#endif

#include "LoadBalance.H"
#include "FortranInterfaceIBC.H"
#include "ParmParse.H"
#include "FillFromReference.H"
#include "ExtrapGhostCells.H"
#include "ExtrapBCF_F.H"
#include "ReflectGhostCells.H"
#include "BCFunc.H"
#include "FIBCF_F.H"
#include "IceConstants.H"
#include "CornerCopier.H"
#include "BasicThicknessIBC.H"


#include "NamespaceHeader.H"

void zeroBCValue_FIBC(Real* pos,
		     int* dir,
		     Side::LoHiSide* side,
		     Real* a_values)
{
  a_values[0]=0.0;
  a_values[1]=0.0;
}



void IceNeumBC(FArrayBox&      a_state,
               const Box&      a_valid,
               Real            a_dx,
               bool            a_homogeneous,
               BCValueHolder   a_value)
{
  for (int idir = 0; idir < SpaceDim; idir++)
    {
      for (SideIterator sit; sit.ok(); ++sit)
        {
          IceNeumBC(a_state, a_valid, a_dx, a_homogeneous, a_value, idir,sit());
        }
    }
}


void IceNeumBC(FArrayBox&      a_state,
               const Box&      a_valid,
               Real            a_dx,
               bool            a_homogeneous,
               const BCValueHolder&   a_valueA,
               int             a_dir,
               Side::LoHiSide  a_side)
{
  Interval stateInterval = a_state.interval();
  IceNeumBC(a_state, a_valid, a_dx, a_homogeneous,
            a_valueA, a_dir,a_side, stateInterval);
}

static void getDomainFacePositionIce(RealVect&             a_retval,
                                     const IntVect&        a_validIV,
                                     const Real&           a_dx,
                                     const int&            a_dir,
                                     const Side::LoHiSide& a_side)
{
  Real* dataPtr = a_retval.dataPtr();

  D_TERM( dataPtr[0] = a_dx*(a_validIV[0] + 0.5);,\
          dataPtr[1] = a_dx*(a_validIV[1] + 0.5);,\
          dataPtr[2] = a_dx*(a_validIV[2] + 0.5);)

  int isign = sign(a_side);
  dataPtr[a_dir] += 0.5*Real(isign)*a_dx;
}

static inline Real linearInterpIce(const Real& a_inhomogVal,
                                   const Real& a_nearVal)
{

  // ignore value at x=1
  Real retval = 2*a_inhomogVal-a_nearVal;
  return retval;
}

static inline Real quadraticInterpIce(const Real& a_inhomogVal,
                                      const Real& a_nearVal,
                                      const Real& a_farVal)
{
  Real retval = (8.0/3.0)*a_inhomogVal + (1.0/3.0)*(a_farVal) -2*(a_nearVal);
  return retval;
}

void IceNeumBC(FArrayBox&      a_state,
               const Box&      a_valid,
               Real            a_dx,
               bool            a_homogeneous,
               const BCValueHolder&   a_valueA,
               int             a_dir,
               Side::LoHiSide  a_side,
               Interval&        a_interval)
{
  BCValueHolder& a_value = (BCValueHolder&)a_valueA;
  int isign = sign(a_side);
  RealVect facePos;
  
  Box toRegion = adjCellBox(a_valid, a_dir, a_side, 1);
  // grow to include corner cells
  toRegion.grow(1);
  toRegion.grow(a_dir,-1);
  toRegion &= a_state.box();
  
  Box fromRegion = toRegion;
  fromRegion.shift(a_dir, -isign);
  
  a_state.copy(a_state, fromRegion, 0, toRegion, 0, a_state.nComp());
  
  if (!a_homogeneous)
    {
      Real* value = new Real[a_state.nComp()];
      
      for (BoxIterator bit(toRegion); bit.ok(); ++bit)
        {
          const IntVect& ivTo = bit();
          IntVect ivClose = ivTo - isign*BASISV(a_dir);
          
          getDomainFacePositionIce(facePos, ivClose, a_dx, a_dir, a_side);
          
          a_value(facePos.dataPtr(), &a_dir, &a_side, value);
          for (int icomp = a_interval.begin(); icomp <= a_interval.end(); icomp++)
            {
              a_state(ivTo, icomp) += Real(isign)*a_dx*value[icomp];
            }
        }
      
      delete[] value;
    }
}



void IceDiriBC(FArrayBox&      a_state,
               const Box&      a_valid,
               Real            a_dx,
               bool            a_homogeneous,
               BCValueHolder   a_value,
               int             a_order)
{
  for (int idir = 0; idir < SpaceDim; idir++)
    {
      for (SideIterator sit; sit.ok(); ++sit)
        {
          
          IceDiriBC(a_state, a_valid, a_dx, a_homogeneous, a_value, idir, sit(), a_order);
        }
    }
}


void IceDiriBC(FArrayBox&      a_state,
               const Box&      a_valid,
               Real            a_dx,
               bool            a_homogeneous,
               BCValueHolder   a_value,
               int             a_dir,
               Side::LoHiSide  a_side,
               int             a_order)
{
  Interval stateInterval = a_state.interval();
  IceDiriBC(a_state,a_valid, a_dx, a_homogeneous,
            a_value,a_dir, a_side, stateInterval, a_order);
}


void IceDiriBC(FArrayBox&      a_state,
               const Box&      a_valid,
               Real            a_dx,
               bool            a_homogeneous,
               BCValueHolder   a_value,
               int             a_dir,
               Side::LoHiSide  a_side,
               Interval&        a_interval,
               int             a_order)
{
  int isign = sign(a_side);
  RealVect facePos;
  
  Box toRegion = adjCellBox(a_valid, a_dir, a_side, 1);
  // grow toRegion to include corner cells
  toRegion.grow(1);
  toRegion.grow(a_dir, -1);
  toRegion &= a_state.box();
  
  Real* value = new Real[a_state.nComp()];
  
  for (BoxIterator bit(toRegion); bit.ok(); ++bit)
    {
      const IntVect& ivTo = bit();

      IntVect ivClose = ivTo -   isign*BASISV(a_dir);
      IntVect ivFar   = ivTo - 2*isign*BASISV(a_dir);

      if (!a_homogeneous)
        {
          getDomainFacePositionIce(facePos, ivClose, a_dx, a_dir, a_side);
          a_value(facePos.dataPtr(), &a_dir, &a_side, value);
        }

      for (int icomp = a_interval.begin(); icomp <= a_interval.end(); icomp++)
        {
          Real nearVal = a_state(ivClose, icomp);
          Real farVal  = a_state(ivFar,   icomp);

          Real inhomogVal = 0.0;

          if (!a_homogeneous)
            {
              inhomogVal = value[icomp];
            }

          Real ghostVal;

          if (a_order == 1)
            {
              ghostVal = linearInterpIce(inhomogVal, nearVal);
    
        }
          else if (a_order == 2)
            {
              ghostVal = quadraticInterpIce(inhomogVal, nearVal, farVal);
            }
          else
            {
              MayDay::Error("bogus order argument");
            }

          a_state(ivTo, icomp) = ghostVal;
        }
    }

  delete[] value;
}


void combinedBC_FIBC(FArrayBox& a_state,
                     const Box& a_valid,
                     const ProblemDomain& a_domain,
                     Real a_dx,
                     bool a_homogeneous)
{
  // this is likely the least-clever way to implement this
  //  (really want this to be a BCHolder), 

  ParmParse ppBC("bc");
  
  // get boundary conditions 
  Vector<int> loBCvect(SpaceDim), hiBCvect(SpaceDim);
  ppBC.getarr("lo_bc", loBCvect, 0, SpaceDim);
  ppBC.getarr("hi_bc", hiBCvect, 0, SpaceDim);

  Box state_box(a_state.box());

  if(!a_domain.domainBox().contains(a_state.box()))
    {
      for(int dir=0; dir<CH_SPACEDIM; ++dir)
        {
          // don't do anything if periodic
          if (!a_domain.isPeriodic(dir))
            {
              Box ghostBoxLo = adjCellBox(a_valid, dir, Side::Lo, 1);
              Box ghostBoxHi = adjCellBox(a_valid, dir, Side::Hi, 1);
              if(!a_domain.domainBox().contains(ghostBoxLo))
                {
                  if (loBCvect[dir] == FIBC_Dirichlet)
                    {
                      //Real bcVal = 0.0;
                      IceDiriBC(a_state,
                                a_valid,
                                a_dx,
                                a_homogeneous,
                                zeroBCValue_FIBC,
                                dir,
                                Side::Lo);
                    }
                  else if (loBCvect[dir] == FIBC_Neumann)
                    {                  
                      //Real bcVal = 0.0;
                      Interval NeumInterval(0,SpaceDim-1);
                      IceNeumBC(a_state,
                                a_valid,
                                a_dx,
                                a_homogeneous,
                                zeroBCValue_FIBC,
                                dir,
                                Side::Lo,
                                NeumInterval);
                    }
                  else if (loBCvect[dir] == FIBC_iceDivide)
                    {
                      ghostBoxLo &= a_state.box();
                      a_state.setVal(0.0,  ghostBoxLo, 0, a_state.nComp());
                    }
                  else if (loBCvect[dir] == FIBC_iceStreamXBC)
                    {
                      ghostBoxLo &= a_state.box();
                      a_state.setVal(0.0,  ghostBoxLo, 0, a_state.nComp());
                    }                
                  else
                    {
                      MayDay::Error("combinedBC_FIBC: bad lo bc type!");
                    }
                }
              
              if(!a_domain.domainBox().contains(ghostBoxHi))
                {
                  if (hiBCvect[dir] == FIBC_Dirichlet)
                    {
                      //Real bcVal = 0.0;
                      IceDiriBC(a_state,
                                a_valid,
                                a_dx,
                                a_homogeneous,
                                zeroBCValue_FIBC,
                                dir,
                                Side::Hi);
                    }
                  else if (hiBCvect[dir] == FIBC_Neumann)
                    {                  
                      //Real bcVal = 0.0;
                      Interval NeumInterval(0,SpaceDim-1);
                      IceNeumBC(a_state,
                                a_valid,
                                a_dx,
                                a_homogeneous,
                                zeroBCValue_FIBC,
                                dir,
                                Side::Hi,
                                NeumInterval);
                    }
                  else if (hiBCvect[dir] == FIBC_iceDivide)
                    {
                      ghostBoxHi &= a_state.box();
                      a_state.setVal(0.0,  ghostBoxHi, 0, a_state.nComp());
                    }
                  else if (hiBCvect[dir] == FIBC_iceStreamXBC)
                    {
                      ghostBoxHi &= a_state.box();
                      a_state.setVal(0.0,  ghostBoxHi, 0, a_state.nComp());
                    }                
                  else
                    {
                      MayDay::Error("combinedBC_FIBC: bad hi bc type!");
                    }
                }

            } // end if is not periodic in ith direction
        }
    }
}

void iceNeumannBC_FIBC(FArrayBox& a_state,
		       const Box& a_valid,
		       const ProblemDomain& a_domain,
		       Real a_dx,
		       bool a_homogeneous)
{
  if(!a_domain.domainBox().contains(a_state.box()))
    {
      Box valid = a_valid;
      for(int dir=0; dir<CH_SPACEDIM; ++dir)
        {
          // don't do anything if periodic
          if (!a_domain.isPeriodic(dir))
            {
              Box ghostBoxLo = adjCellBox(valid, dir, Side::Lo, 1);
              Box ghostBoxHi = adjCellBox(valid, dir, Side::Hi, 1);
              if(!a_domain.domainBox().contains(ghostBoxLo))
                {
                  //Real bcVal = 0.0;
		  Interval NeumInterval(0,SpaceDim-1);
                  NeumBC(a_state,
                         valid,
                         a_dx,
                         a_homogeneous,
                         zeroBCValue_FIBC,
                         dir,
                         Side::Lo,
			 NeumInterval);
                }

              if(!a_domain.domainBox().contains(ghostBoxHi))
                {
		  Interval NeumInterval(0,SpaceDim-1);
                  NeumBC(a_state,
                         valid,
                         a_dx,
                         a_homogeneous,
                         zeroBCValue_FIBC,
                         dir,
                         Side::Hi, 
			 NeumInterval);
                }

            } // end if is not periodic in ith direction
        }
    }
}


void iceDirichletBC_FIBC(FArrayBox& a_state,
			 const Box& a_valid,
			 const ProblemDomain& a_domain,
			 Real a_dx,
			 bool a_homogeneous)
{
  if(!a_domain.domainBox().contains(a_state.box()))
    {
      Box valid = a_valid;
      for(int dir=0; dir<CH_SPACEDIM; ++dir)
        {
          // don't do anything if periodic
          if (!a_domain.isPeriodic(dir))
            {
              Box ghostBoxLo = adjCellBox(valid, dir, Side::Lo, 1);
              Box ghostBoxHi = adjCellBox(valid, dir, Side::Hi, 1);
              if(!a_domain.domainBox().contains(ghostBoxLo))
                {
                  //Real bcVal = 0.0;
                  IceDiriBC(a_state,
                            valid,
                            a_dx,
                            a_homogeneous,
                            zeroBCValue_FIBC,
                            dir,
                            Side::Lo);
                }
              
              if(!a_domain.domainBox().contains(ghostBoxHi))
                {
                  //Real bcVal = 0.0;
                  IceDiriBC(a_state,
                            valid,
                            a_dx,
                            a_homogeneous,
                            zeroBCValue_FIBC,
                            dir,
                            Side::Hi);
                }
              
            } // end if is not periodic in ith direction
        }
    }
}

//set all components of u to zero in ghost regions
void iceDivideBC_FIBC(FArrayBox& a_state,
		      const Box& a_valid,
		      const ProblemDomain& a_domain,
		      Real a_dx,
		      bool a_homogeneous)
{
if(!a_domain.domainBox().contains(a_state.box()))
    {
      Box valid = a_valid;
      for(int dir=0; dir<CH_SPACEDIM; ++dir)
        {
          // don't do anything if periodic
          if (!a_domain.isPeriodic(dir))
            {
              Box ghostBoxLo = adjCellBox(valid, dir, Side::Lo, 1);
              
              if(!a_domain.domainBox().contains(ghostBoxLo))
                {
		  ghostBoxLo &= a_state.box();
		  a_state.setVal(0.0,  ghostBoxLo, 0, a_state.nComp());
		  
                }
	      Box ghostBoxHi = adjCellBox(valid, dir, Side::Hi, 1);
              if(!a_domain.domainBox().contains(ghostBoxHi))
                {
		  ghostBoxHi &= a_state.box();
		  a_state.setVal(0.0,  ghostBoxHi, 0, a_state.nComp());
                }

            } // end if is not periodic in ith direction
        }
    }

}


//ice stream parallel to x : homogeneous Neumann conditions
//along the y faces, and homogeneous Dirichlet conditions
//along the x faces. 
void iceStreamXBC_FIBC(FArrayBox& a_state,
		      const Box& a_valid,
		      const ProblemDomain& a_domain,
		      Real a_dx,
		      bool a_homogeneous)
{

  if(!a_domain.domainBox().contains(a_state.box()))
    {
      Box valid = a_valid;
      
      int xDir = 0;
      if (!a_domain.isPeriodic(xDir))
	{
	  Box ghostBoxLo = adjCellBox(valid, xDir, Side::Lo, 1);
	  
	  if(!a_domain.domainBox().contains(ghostBoxLo))
	    {
	      ghostBoxLo &= a_state.box();
	      a_state.setVal(0.0,  ghostBoxLo, 0, a_state.nComp());
	      
	    }
	  Box ghostBoxHi = adjCellBox(valid, xDir, Side::Hi, 1);
	  if(!a_domain.domainBox().contains(ghostBoxHi))
	    {
	      ghostBoxHi &= a_state.box();
	      a_state.setVal(0.0,  ghostBoxHi, 0, a_state.nComp());
	    }
	}

      if (SpaceDim > 1)
	{
	  int yDir = 1;
	  Box ghostBoxLo = adjCellBox(valid, yDir, Side::Lo, 1);
	  Box ghostBoxHi = adjCellBox(valid, yDir, Side::Hi, 1);
	  if(!a_domain.domainBox().contains(ghostBoxLo))
	    {
	      //Real bcVal = 0.0;
	      Interval NeumInterval(0,SpaceDim-1);
	      IceNeumBC(a_state,
                        valid,
                        a_dx,
                        a_homogeneous,
                        zeroBCValue_FIBC,
                        yDir,
                        Side::Lo,
                        NeumInterval);
	    }
	  
	  if(!a_domain.domainBox().contains(ghostBoxHi))
	    {
	      Interval NeumInterval(0,SpaceDim-1);
	      IceNeumBC(a_state,
                        valid,
                        a_dx,
                        a_homogeneous,
                        zeroBCValue_FIBC,
                        yDir,
                        Side::Hi, 
                        NeumInterval);
	    }
	  
	}
    }
}




// Indicate that define() hasn't been called
// set default thickness at domain edge to be zero
FortranInterfaceIBC::FortranInterfaceIBC() : m_boundaryThickness(0.0)
{
  m_numVar = 0;
  m_isBCsetUp = false;
  m_isDefined = false;
  m_gridsSet = false;
  // set default to be true
  m_verbose = true;
  // default is an empty vector here 
  // (don't set thickness to zero anywhere)
  m_thicknessClearRegions = Vector<Box>();
  
  // default is not to set to default values (exposes regions where fill is broken)
  m_setDefaultValues = false;

  // default is to interpolate thickness
  m_interpolate_upper_surface = false;
}

FortranInterfaceIBC::~FortranInterfaceIBC()
{
  if (m_verbose)
    {
      pout() << "in FortranInterfaceIBC destructor" << endl;
    }
}


/// Define the object
/**
   Set the problem domain index space and the grid spacing for this
   initial and boundary condition object. Just calls base-class define
*/
void
FortranInterfaceIBC::define(const ProblemDomain& a_domain,
			    const Real&          a_dx)
{
  PhysIBC::define(a_domain, a_dx);
  m_isDefined = true;
}

// static function which defines cell centred a_fab, directly with cell centered data
// a_data_ptr if !a_nodal, or by averaging nodal data a_data_ptr.
void FortranInterfaceIBC::setFAB(Real* a_data_ptr,
				 const int* a_dimInfo,
                                 const int* a_boxlo, const int* a_boxhi, 
				 const Real* a_dew, const Real* a_dns,
				 const IntVect& a_offset,
				 const IntVect& a_nGhost,
				 FArrayBox & a_fab,
                                 FArrayBox & a_ccFab,
				 const bool a_nodal,
                                 const bool a_verbose)
{
  if (a_verbose)
    {
      pout() << "in FortranInterfaceIBC::setFAB" << endl;
      pout() << " -- doing box calculus" << endl;
    }

  IntVect loVect(D_DECL(a_boxlo[0],a_boxlo[1], a_boxlo[2]-1));
  IntVect hiVect(D_DECL(a_boxhi[0],a_boxhi[1], a_boxhi[2]-1));
  if (a_verbose)
    {
      pout () << "loVect = " << loVect << endl;
      pout () << "hiVect = " << hiVect << endl;
    }

  Box fabBox;
  if (loVect <= hiVect)
    {
      // set indextype here, rather than converting later
      IndexType ixtype;
      if (a_nodal == true) 
        {
          ixtype.setall();            
        }
      fabBox.define(loVect, hiVect, ixtype);
      if (a_verbose)
        {
          pout() << "fabBox = " << fabBox << endl;
        }
      //fabBox.shift(-a_nGhost);
      fabBox.shift(-a_offset);
      if (a_verbose)
        {
          pout() << "...shifted fabBox = " << fabBox << endl;
        }
      //    }
      
      if (a_nodal)
        {
          a_fab.define(fabBox,1,a_data_ptr);          
          Box cellBox(fabBox);
          cellBox.enclosedCells();
          a_ccFab.define(cellBox, 1);
          if (a_verbose)
            {
              pout() << "and cellBox = " << cellBox << endl;
            }
          //nodeBox.shift(-a_nGhost);
          FArrayBox nodeFAB;

          FORT_NODETOCELL(CHF_CONST_FRA1(a_fab,0),
                          CHF_FRA1(a_ccFab,0),
                          CHF_BOX(cellBox));
        }
      else 
        {
          // both of these are aliased to point to the input data
          a_fab.define(fabBox, 1, a_data_ptr);
          a_ccFab.define(fabBox, 1, a_data_ptr);
        }
    }
}


/// version of setFAB for (horizontal) velocity data 
void FortranInterfaceIBC::setVelFAB(Real* a_uVelPtr,
                                    Real* a_vVelPtr,
                                    const int* a_dimInfo,
                                    const int* a_boxlo, const int* a_boxhi, 
                                    const Real* a_dew, const Real* a_dns,
                                    const IntVect& a_offset,
                                    const IntVect& a_nGhost,
                                    FArrayBox & a_uFab,
                                    FArrayBox & a_vFab,
                                    FArrayBox & a_uccFab,
                                    FArrayBox & a_vccFab,
                                    const bool a_nodal,
                                    const bool a_fillData)
{
  if (m_verbose)
    {
      pout() << "in FortranInterfaceIB:setVelFAB" << endl;
      pout() << " -- doing box calculus" << endl;
    }

  IntVect loVect(D_DECL(a_boxlo[0],a_boxlo[1], a_boxlo[2]-1));
  IntVect hiVect(D_DECL(a_boxhi[0],a_boxhi[1], a_boxhi[2]-1));

  // vertical layering for velocity makes this a bit odd --
  // need to rotate everything
  int nLayers = a_dimInfo[1];

  IntVect CISMloVect(D_DECL(0,a_boxlo[0], a_boxlo[1]));
  IntVect CISMhiVect(D_DECL(nLayers-1,a_boxhi[0], a_boxhi[1]));
  int velNcomp = a_boxhi[1]-a_boxlo[1]+1;
  
  if (m_verbose)
    {
      pout () << "loVect = " << loVect << endl;
      pout () << "hiVect = " << hiVect << endl;

      pout() << "CISM Vel loVect = " << CISMloVect << endl;
      pout() << "CISM Vel hiVect = " << CISMhiVect << endl;
    }

  Box fabBox, CISMvelBox;
  if (loVect <= hiVect)
    {
      IndexType boxtype;
      if (a_nodal)  boxtype.setall();
      fabBox.define(loVect, hiVect, boxtype);
      
      CISMvelBox.define(CISMloVect,CISMhiVect, boxtype);
      if (m_verbose)
        {
          pout() << "done defining box" << endl;
        }

      //fabBox.shift(-a_nGhost);
      fabBox.shift(-a_offset);
      //CISMvelBox.shift(1,-a_nGhost[0]);
      CISMvelBox.shift(1,-a_offset[0]);
      if (m_verbose)
        {
          pout() << "fabBox = " << fabBox << endl;
          pout () << "CISMvelBox = " << CISMvelBox << endl;
        }

      if (m_verbose)
        {
          pout() << "... done! " << endl;
        }
    }

  // if we haven't already set the grids, do it now
  if (!gridsSet())
    {
      if (m_verbose) 
        {
          pout() << " -- entering setGrids" << endl;
        }
      Box gridBox(fabBox);
#if 0
      if (a_nodal)
        {
          gridBox.enclosedCells();
        }
      gridBox.grow(-a_nGhost);
#endif
      setGrids(m_grids, gridBox, m_domain, a_nGhost, a_nodal,m_verbose);
      m_gridsSet = true;
      if (m_verbose)
        {
          pout() << " -- out of setGrids" << endl;
        }
    }
  if (a_nodal)
    {
      // this is going to be a bit screwy -- this FAB will have the 
      // right amount of storage

      Box cellBox(CISMvelBox);
      // back to cell-centered
      cellBox.enclosedCells();      
      a_uccFab.define(CISMvelBox, velNcomp);
      a_vccFab.define(CISMvelBox, velNcomp);


      // 
      int nodeVelNcomp = velNcomp +1;
      //nodeBox.shift(-a_nGhost);
      FArrayBox nodeFAB;
      a_uFab.define(CISMvelBox,nodeVelNcomp,a_uVelPtr);
      a_vFab.define(CISMvelBox, nodeVelNcomp,a_vVelPtr);
      if (a_fillData)
        {
          int yGhost = a_nGhost[1];
          int yoffset = a_offset[1];
          FORT_NODETOCELLCISMVEL(CHF_CONST_FRA(a_uFab),
                                 CHF_FRA(a_uccFab),
                                 CHF_CONST_INT(yGhost),
                                 CHF_CONST_INT(yoffset),
                                 CHF_BOX(fabBox));
          
          FORT_NODETOCELLCISMVEL(CHF_CONST_FRA(a_vFab),
                                 CHF_FRA(a_vccFab),
                                 CHF_CONST_INT(yGhost),
                                 CHF_CONST_INT(yoffset),
                                 CHF_BOX(fabBox));
        }
    }
  else 
    {
      // both of these are aliased to point to the input data
      a_uFab.define(CISMvelBox, velNcomp, a_uVelPtr);
      a_vFab.define(CISMvelBox, velNcomp, a_vVelPtr);
      a_uccFab.define(CISMvelBox, velNcomp, a_uVelPtr);
      a_vccFab.define(CISMvelBox, velNcomp, a_vVelPtr);
    }
}


void
FortranInterfaceIBC::setThickness(Real* a_data_ptr,
				  const int* a_dimInfo,
                                  const int* a_boxlo, const int* a_boxhi, 
                                  const Real* a_dew, const Real* a_dns,
				  const IntVect& a_offset,
                                  const IntVect& a_nGhost,
				  const bool a_nodal)
{

  string dataName("thickness");
  setInputData(dataName, a_data_ptr,
               a_dimInfo, a_boxlo, a_boxhi, 
               a_dew, a_dns, a_offset, a_nGhost, a_nodal);
                                  
}

void
FortranInterfaceIBC::setTopography(Real* a_data_ptr,
				   const int* a_dimInfo,
                                   const int* a_boxlo, const int* a_boxhi, 
				   const Real* a_dew, const Real* a_dns,
				   const IntVect& a_offset,
                                   const IntVect& a_nGhost, 
				   const bool a_nodal)
{

  string dataName("topography");
  setInputData(dataName, a_data_ptr,
               a_dimInfo, a_boxlo, a_boxhi, 
               a_dew, a_dns, a_offset, a_nGhost, a_nodal);  

}


void
FortranInterfaceIBC::setSurface(Real* a_data_ptr,
                                const int* a_dimInfo,
                                const int* a_boxlo, const int* a_boxhi, 
                                const Real* a_dew, const Real* a_dns,
                                const IntVect& a_offset,
                                const IntVect& a_nGhost, 
                                const bool a_nodal)
{

  string dataName("usurf");
  setInputData(dataName, a_data_ptr,
               a_dimInfo, a_boxlo, a_boxhi, 
               a_dew, a_dns, a_offset, a_nGhost, a_nodal);  


}


void
FortranInterfaceIBC::setLowerSurface(Real* a_data_ptr,
                                     const int* a_dimInfo,
                                     const int* a_boxlo, const int* a_boxhi, 
                                     const Real* a_dew, const Real* a_dns,
                                     const IntVect& a_offset,
                                     const IntVect& a_nGhost, 
                                     const bool a_nodal)
{
  
  string dataName("lsurf");
  setInputData(dataName, a_data_ptr,
               a_dimInfo, a_boxlo, a_boxhi, 
               a_dew, a_dns, a_offset, a_nGhost, a_nodal);  

}

void
FortranInterfaceIBC::setLowerCellCenterZ(Real* a_data_ptr,
                                         const int* a_dimInfo,
                                         const int* a_boxlo, const int* a_boxhi, 
                                         const Real* a_dew, const Real* a_dns,
                                         const IntVect& a_offset,
                                         const IntVect& a_nGhost, 
                                         const bool a_nodal)
{
  
  string dataName("lowerCellZ");
  setInputData(dataName, a_data_ptr,
               a_dimInfo, a_boxlo, a_boxhi, 
               a_dew, a_dns, a_offset, a_nGhost, a_nodal);  

}


void
FortranInterfaceIBC::setLowerCellTemp(Real* a_data_ptr,
                                      const int* a_dimInfo,
                                      const int* a_boxlo, const int* a_boxhi, 
                                      const Real* a_dew, const Real* a_dns,
                                      const IntVect& a_offset,
                                      const IntVect& a_nGhost, 
                                      const bool a_nodal)
{

  string dataName("lowerCellTemp");
  setInputData(dataName, a_data_ptr,
               a_dimInfo, a_boxlo, a_boxhi, 
               a_dew, a_dns, a_offset, a_nGhost, a_nodal);  
}


  /// sets storage for floating mask. 
  /** Currently only needed in order to return BISICLES-computed floating-ice
      mask to CISM */
void
FortranInterfaceIBC::setFloatingMask(Real* a_data_ptr,
                                     const int* a_dimInfo,
                                     const int* a_boxlo, const int* a_boxhi, 
                                     const Real* a_dew, const Real* a_dns,
                                     const IntVect& a_offset,
                                     const IntVect& a_nGhost, 
                                     const bool a_nodal)
{
  
  string dataName("floatingMask");
  setInputData(dataName, a_data_ptr,
               a_dimInfo, a_boxlo, a_boxhi, 
               a_dew, a_dns, a_offset, a_nGhost, a_nodal);  

}



  /// sets storage for ice mask. 
  /** Currently only needed in order to return BISICLES-computed ice-ice
      mask to CISM */
void
FortranInterfaceIBC::setIceMask(Real* a_data_ptr,
                                const int* a_dimInfo,
                                const int* a_boxlo, const int* a_boxhi, 
                                const Real* a_dew, const Real* a_dns,
                                const IntVect& a_offset,
                                const IntVect& a_nGhost, 
                                const bool a_nodal)
{
  
  string dataName("iceMask");
  setInputData(dataName, a_data_ptr,
               a_dimInfo, a_boxlo, a_boxhi, 
               a_dew, a_dns, a_offset, a_nGhost, a_nodal);  

}

void
FortranInterfaceIBC::setInputData(string& a_data_name,
                                  Real* a_data_ptr,
                                  const int* a_dimInfo,
                                  const int* a_boxlo, const int* a_boxhi, 
                                  const Real* a_dew, const Real* a_dns,
                                  /// amount to offset indices (due to C-Fortran numbering, for example)
                                  const IntVect& a_offset,
                                  const IntVect& a_nGhost,
                                  const bool a_nodal)
{
  int dataComp=-1;
  bool newData = true;
  // first check to see if we've already defined this data value
  for (int i=0; i<m_vectInputDataNames.size(); i++)
    {
      if (a_data_name == m_vectInputDataNames[i])
        {
          dataComp = i;
          newData = false;
        }
    }

  RealVect dxVect(D_DECL(*a_dew, *a_dns, 1));

  if (newData)
    {
      dataComp = m_numVar;
      m_vectInputDataNames.push_back(a_data_name);
      m_vectInputDataGhost.push_back(a_nGhost);
      m_vectIsNodal.push_back(a_nodal);
      m_vectInputDataDx.push_back(dxVect);
      RefCountedPtr<FArrayBox> inputDataPtr(new FArrayBox);
      RefCountedPtr<FArrayBox> ccInputDataPtr(new FArrayBox);
      m_vectInputData.push_back(inputDataPtr);
      m_vectCCInputData.push_back(ccInputDataPtr);
      ++m_numVar;
    }
  else
    {
      m_vectInputDataNames[dataComp] = a_data_name;
      m_vectInputDataGhost[dataComp] = a_nGhost;
      m_vectIsNodal[dataComp] = a_nodal;
      m_vectInputDataDx[dataComp] = dxVect;
    }
  // dimInfo is (SPACEDIM, nx, ny)

  // assumption is that data_ptr is indexed using fortran 
  // ordering from (1:dimInfo[1])1,dimInfo[2])
  // we want to use c ordering

  setFAB(a_data_ptr, a_dimInfo,a_boxlo, a_boxhi, a_dew,a_dns,
         a_offset, a_nGhost,*m_vectInputData[dataComp], 
         *m_vectCCInputData[dataComp],
         a_nodal, m_verbose);

  // if we haven't already set the grids, do it now
  if (!gridsSet())
    {
      if (m_verbose) 
        {
          pout() << " -- entering setGrids" << endl;
        }
      Box gridBox(m_vectCCInputData[dataComp]->box());
      //gridBox.grow(-a_nGhost);
      setGrids(m_grids, gridBox, m_domain, a_nGhost, a_nodal, m_verbose);
      m_gridsSet = true;
      if (m_verbose)
        {
          pout() << " -- out of setGrids" << endl;
        }
    }



  // now define LevelData and copy from FAB->LevelData 
  // (at some point will likely change this to be an aliased 
  // constructor for the LevelData, but this should be fine for now....

  // if nodal, we'd like at least one ghost cell for the LDF
  // (since we'll eventually have to average back to nodes)
  
  IntVect LDFghost = m_vectInputDataGhost[dataComp];
  if (a_nodal && (LDFghost[0] == 0) )
    {
      LDFghost += IntVect::Unit;
    }
  RefCountedPtr<LevelData<FArrayBox> > localLDFPtr(new LevelData<FArrayBox>(m_grids, 1, LDFghost));
  if (newData)
    {
      m_vectInputDataLDF.push_back(localLDFPtr);
    }
  else
    {
      m_vectInputDataLDF[dataComp] = localLDFPtr;
    }

  // fundamental assumption that there is no more than one box per processor/
  DataIterator dit = m_grids.dataIterator();
  for (dit.begin(); dit.ok(); ++dit)
    {
      //FArrayBox& thisLDFfab = (*localLDFPtr)[dit];
      Box copyBox = (*localLDFPtr)[dit].box();
      copyBox &= m_vectCCInputData[dataComp]->box();
      (*m_vectInputDataLDF[dataComp])[dit].copy(*m_vectCCInputData[dataComp], 
                                            copyBox);
    }

}




/// regions where we artificially set thickness to zero
/** this is done in setThickness, for lack of a better place, so 
    this needs to be set before setThickness is called. 
    a_clearRegions defines logically-rectangular regions where 
    the thickness is artificially set to zero. These regions are 
    defined relative to the original input data (i.e. before any shifting 
    due to ghost cells)
*/
void
FortranInterfaceIBC::setThicknessClearRegions(const Vector<Box>& a_clearRegions)
{
  m_thicknessClearRegions = a_clearRegions;
}


/// Factory method - this object is its own factory
/**
   Return a pointer to a new PhysIBC object with m_isDefined = false (i.e.,
   its define() must be called before it is used).
*/
IceThicknessIBC* 
FortranInterfaceIBC::new_thicknessIBC()
{
  if (m_verbose)
    {
      pout() << "in FortranInterfaceIBC::new_thicknessIBC" << endl;
    }

  FortranInterfaceIBC* retval = new FortranInterfaceIBC();

  retval->m_grids = m_grids;
  retval->m_gridsSet = m_gridsSet;
  retval->m_numVar = m_numVar;

  /// copy vector storage of data -- note that we copy refCountedPtrs
  retval->m_vectInputDataNames = m_vectInputDataNames;
  retval->m_vectInputData = m_vectInputData;
  retval->m_vectIsNodal = m_vectIsNodal;
  retval->m_vectCCInputData = m_vectCCInputData;
  retval->m_vectInputDataDx = m_vectInputDataDx;
  retval->m_vectInputDataGhost = m_vectInputDataGhost;
  retval->m_vectInputDataLDF = m_vectInputDataLDF;
  
  retval->m_verbose = m_verbose;

  return static_cast<IceThicknessIBC*>(retval);

}

/// Set up initial conditions
/**
 */
void
FortranInterfaceIBC::initialize(LevelData<FArrayBox>& a_U)
{
  /// shouldn't be here...
  MayDay::Error("FortranInterfaceIBC::initialize not implemented");
}




/// Set boundary fluxes
/**
 */
void 
FortranInterfaceIBC::primBC(FArrayBox&            a_WGdnv,
                          const FArrayBox&      a_Wextrap,
                          const FArrayBox&      a_W,
                          const int&            a_dir,
                          const Side::LoHiSide& a_side,
                          const Real&           a_time)
{
  // do nothing in periodic case
  if (!m_domain.isPeriodic(a_dir))
    {    
      int lohisign;
      Box tmp = a_WGdnv.box();
      // Determine which side and thus shifting directions
      lohisign = sign(a_side);
      tmp.shiftHalf(a_dir,lohisign);
      // (DFM - 5/28/10) this little dance with the ghostBox is a bit 
      // of a kluge to handle the case where a_WGdnv has more than one layer   
      // of ghosting, in which case just testing agains tmp isn't 
      // sufficient to determine whether you're up against the domain edge
      Box ghostBox = (a_side == Side::Lo)?
	adjCellLo(m_domain.domainBox(),a_dir, 1):
	adjCellHi(m_domain.domainBox(),a_dir, 1);
      ghostBox &= tmp;
       // Is there a domain boundary next to this grid
      if (!ghostBox.isEmpty() && !m_domain.contains(tmp))
        {
          tmp &= m_domain;
	  Box boundaryBox = (a_side == Side::Lo)?
	    bdryLo(tmp,a_dir):bdryHi(tmp,a_dir);
	  BoxIterator bit(boundaryBox);
	  for (bit.begin(); bit.ok(); ++bit){
	    const IntVect& i = bit();
	    a_WGdnv(i,0) = std::max(0.0,a_Wextrap(i,0));
	    //a_WGdnv(i,0) = 0.0;
	  }
	}
    }
  
}

/// Set boundary slopes
/**
   The boundary slopes in a_dW are already set to one sided difference
   approximations.  If this function doesn't change them they will be
   used for the slopes at the boundaries.
*/

void 
FortranInterfaceIBC::setBdrySlopes(FArrayBox&       a_dW,
                                 const FArrayBox& a_W,
                                 const int&       a_dir,
                                 const Real&      a_time)
{
  // one-sided differences sounds fine with me, so do nothing...
}

/// Adjust boundary fluxes to account for artificial viscosity
/**
 */
void 
FortranInterfaceIBC::artViscBC(FArrayBox&       a_F,
                             const FArrayBox& a_U,
                             const FArrayBox& a_divVel,
                             const int&       a_dir,
                             const Real&      a_time)
{
  // don't anticipate being here -- if we wind up here, need to
  // give it some thought
  MayDay::Error("FortranInterfaceIBC::artViscBC not implemented");
}


/// return boundary condition for Ice velocity solve
/** eventually would like this to be a BCHolder
 */
RefCountedPtr<CompGridVTOBC>
FortranInterfaceIBC::velocitySolveBC()
{
  
  if (!m_isBCsetUp)
    {
      setupBCs();
    }
  
  return m_velBCs;
}


/// set non-periodic ghost cells for surface height z_s. 
void
FortranInterfaceIBC::setSurfaceHeightBCs(LevelData<FArrayBox>& a_zSurface,
                                         LevelSigmaCS& a_coords,
                                         const ProblemDomain& a_domain,
                                         const RealVect& a_dx,
                                         Real a_time, Real a_dt)
{
  if (m_extrapBoundary)
    {
      ExtrapGhostCells(a_zSurface, a_domain);
    } 
  else
    {
      //slc : i think reflection is a better default : works for isolated
      //      islands (Antarctica, Greenland) and divides, 
      //      where grad(s) = grad(H) = grad(topo) = 0 (Pine Island).
      //      (and in that case, this ought to be unnecessary)
      for (int dir = 0; dir < SpaceDim; ++dir)
	{
	  ReflectGhostCells(a_zSurface, a_domain, dir, Side::Lo);
	  ReflectGhostCells(a_zSurface, a_domain, dir, Side::Hi);
	}
    }
}

/// set non-periodic ghost cells for thickness & topography
void
FortranInterfaceIBC::setGeometryBCs(LevelSigmaCS& a_coords,
				    const ProblemDomain& a_domain,
				    const RealVect& a_dx,
				    Real a_time, Real a_dt)
{
  if (m_extrapBoundary)
    {
      ExtrapGhostCells(a_coords.getH(), a_domain);
      ExtrapGhostCells(a_coords.getTopography(), a_domain);
    } 
  else
    {
      //slc : i think reflection is a better default : works for isolated
      //      islands (Antarctica, Greenland) and divides, 
      //      where grad(s) = grad(H) = grad(topo) = 0 (Pine Island).
      //      (and in that case, this ought to be unnecessary)
      for (int dir = 0; dir < SpaceDim; ++dir)
	{
	  ReflectGhostCells(a_coords.getH(), a_domain, dir, Side::Lo);
	  ReflectGhostCells(a_coords.getH(), a_domain, dir, Side::Hi);
	  ReflectGhostCells(a_coords.getTopography(), a_domain, dir, Side::Lo);
	  ReflectGhostCells(a_coords.getTopography(), a_domain, dir, Side::Hi);
	}
    }

}


/// set grids using Boxes passed in from Glimmer-CISM
/** creates a DisjointBoxLayout using the grid boxes and 
    processor distribution used by CISM. */
void 
FortranInterfaceIBC::setGrids(DisjointBoxLayout& a_grids, 
                              Box& a_gridBox,
                              const ProblemDomain& a_domain,
                              const IntVect& a_nGhost,
                              bool a_nodal,
                              bool a_verbose)
{

  if (a_nodal)
    {
      a_gridBox.enclosedCells();
    }
  a_gridBox.grow(-a_nGhost);
  if (a_nodal)
    {
      const Box& domainBox = a_domain.domainBox();
      const IntVect& domainSmall = domainBox.smallEnd();
      // if nodal, and if lower end of grid box isn't at lower domain boundary, then 
      // need to grow lower end of box by one to cover "missing" cell between the two CISM nodes.
      for (int dir=0; dir<SpaceDim; dir++)
        {
          // check if this box isn't already at the lower boundary
          if (a_gridBox.smallEnd()[dir] > domainSmall[dir])
            {
              // now grow one cell on the low end
              a_gridBox.growLo(dir,1);
            } // end if box isn't on lower boundary
        } // end loop over diredr
    } // end if nodal

  if (a_verbose)
    {
      pout() << "in setGrids, box = " << a_gridBox << endl;
    }

  int status;
  Vector<Box> filteredBoxes;
  Vector<int> filteredProcAssign;

  status = LoadBalance(filteredProcAssign,
                       filteredBoxes,
                       a_gridBox,
                       numProc());


  if (status != 0)
    {
      MayDay::Error("Failed LoadBalance");
    }
  
  
  if (a_verbose)
    {
      pout () << "after LoadBalance: " << endl;
      pout() << "filteredBoxes = " << filteredBoxes << endl;
      pout() << "filteredProcAssign = " << filteredProcAssign << endl;
      pout() << "entering DBL::define..." << endl;
    }

  // define DisjointBoxLayout
  a_grids.define(filteredBoxes, filteredProcAssign, a_domain);
  
  if (a_verbose)
    {
      pout () << "after DBL define" << endl;
    }
}

/// utility function to fill in holes in topography
/** looks for isolated values of holeVal and replaces then
    with average of neighbors */
void
FortranInterfaceIBC::fillTopographyHoles(Real a_holeVal)
{

  if (m_verbose) 
    {
      pout() << "FortranInterfaceIBC::fillTopographyHoles" << endl;
    }

  CH_assert(isDefined("topography"));
  //  CH_assert(!inputTopography.box().isEmpty());

  int topoComp = getInputDataComp("topography");
  
  Real compareThreshold = 1.0e-10;
  // neighborCutoff is number of neighbors which are not the 
  // holeValue required before we do averaging. (max number of 
  // neigbors in 2d is 8
  int neighborCutoff = 5;
  
  FArrayBox& inputTopography = *m_vectInputData[topoComp];
  Box testBox = inputTopography.box();
  testBox.grow(-1);

  Box neighborBox(-IntVect::Unit, IntVect::Unit);
  IntVectSet neighborIVS(neighborBox);
  neighborIVS -= IntVect::Zero;

  IVSIterator neighborIt(neighborIVS);

  BoxIterator bit(testBox);
  for (bit.begin(); bit.ok(); ++bit)
    {
      IntVect iv = bit();
      if (fabs(inputTopography(iv, 0) - a_holeVal) < compareThreshold)
        {
          Real sum = 0;
          int num = 0;
          for (neighborIt.begin(); neighborIt.ok(); ++neighborIt)
            {
              IntVect newIV = iv + neighborIt();
              if (fabs(inputTopography(newIV, 0) - a_holeVal) > compareThreshold)
                {
                  sum += inputTopography(newIV, 0);
                  num++;
                }
            }

          if (num > neighborCutoff)
            {
              inputTopography(iv,0) = sum / num;
            }
        }
    }
          

#if 0
  // try this in c++ first
  FORT_FILLHOLES(CHF_FRA1(inputTopography,0),
                 CHF_REAL(a_holeVal),
                 CHF_REAL(compareThreshold),
                 CHF_INT(neighborCutoff),
                 CHF_BOX(testBox));
#endif
}


  /// set up initial ice state
  /** reads info from ParmParse and sets up ice sheet geometry
   */
void
FortranInterfaceIBC::initializeIceGeometry(LevelSigmaCS& a_coords,
                                           const RealVect& a_dx,
                                           const RealVect& a_domainSize,
                                           const Real& a_time, 
					   const LevelSigmaCS* a_crseCoords,
					   const int a_refRatio)
{
  if (m_verbose) 
    {
      pout() << "FortranInterfaceIBC::initializeIceGeometry" << endl;
    }

  
  ParmParse geomPP("geometry");

  geomPP.query("setDefaultValues", m_setDefaultValues);

  geomPP.query("interpolate_upper_surface", m_interpolate_upper_surface);

  //CH_assert(m_isDefined);

  // assume that thickness and topography from glimmer are defined on the same 
  // mesh
  int thicknessComp = getInputDataComp("thickness");
  int topoComp = getInputDataComp("topography");

  CH_assert(m_vectInputData[thicknessComp]->box() == m_vectInputData[topoComp]->box());
  CH_assert(m_vectInputDataDx[thicknessComp] == m_vectInputDataDx[topoComp]);

  // get scaling factor for ice thickness -- not sure if I really need this
  Real thicknessScale =1;
  geomPP.query("thickness_scale", thicknessScale);

  if (m_verbose)
    {
      pout() << " ...setting up thickness LevelData..." << endl;
    }


    // grab periodicity info from a_coords
  const DisjointBoxLayout& destGrids = a_coords.grids();
  const ProblemDomain& destDomain = destGrids.physDomain();
  if (geomPP.contains("basalSlope") 
      && (destDomain.isPeriodic(0) || destDomain.isPeriodic(1)) )
    {
      //slc : periodic domains need not have periodic topography b,
      //instead b = f(x,y) + Ax + By where A,B are constants and f is periodic.
      //for now, read A,B from the input file - periodic problems
      //are rare, so it is possibly not worth the effort of devising
      //something robust, e.g working out A and B from glimmer's model%geometry%topg, 
      //which is node-centred data. It would be easy to do that in serial, 
      //but in parallel the details would depend on the
      //interaction between glimmer's domain decomposition and ours.
      RealVect basalSlope(RealVect::Zero);
      Vector<Real> t(SpaceDim, 0.0);
      geomPP.getarr("basalSlope", t, 0, SpaceDim);
      D_TERM(basalSlope[0] = t[0];,
	     basalSlope[1] = t[1];,
	     basalSlope[2] = t[2];);
      if (m_verbose)
	{      
	  pout() << " ... adding constant background slope " 
		 << basalSlope ;
	}
      if (basalSlope.dotProduct(basalSlope) > 1.0e-10)
	{
	  MayDay::Error("periodic problems with non-zero basal slope not yet implemented");
	}
      a_coords.setBackgroundSlope(basalSlope);

      //RealVect unitShift = basalSlope * a_domainSize;
      if (m_verbose)
	{      
	  pout() << " a_domainSize[0] = "  
		 << a_domainSize[0]
		 << " ... " << std::endl;
	}

      
    }

  if (m_verbose)
    {
      pout() << " Done with background slope" << endl;
    }

  DisjointBoxLayout ChomboGrids = a_coords.grids();
  LevelData<FArrayBox>& ChomboThickness = a_coords.getH();
  
  IntVect thicknessGhostVect =  ChomboThickness.ghostVect();
  IntVect sigmaGhostVect = thicknessGhostVect - IntVect::Unit;

  //LevelData<FArrayBox> ChomboTopography(ChomboGrids, 1, thicknessGhostVect);
  LevelData<FArrayBox>& ChomboTopography = a_coords.getTopography();

  // initialize to defaults, if desired
  if (m_setDefaultValues)
    {
      Real thicknessDefault, topographyDefault;
      geomPP.get("thicknessDefault", thicknessDefault);
      geomPP.get("topographyDefault", topographyDefault);
      DataIterator dit = ChomboThickness.dataIterator();
      for (dit.begin(); dit.ok(); ++dit)
        {
          ChomboThickness[dit].setVal(thicknessDefault);
          ChomboTopography[dit].setVal(topographyDefault);
        }
    }

  // if necessary, set up reference LevelSigmaCS, which will
  // compute upper surface in a consistent way
  if (m_interpolate_upper_surface)
    {
      if (!m_referenceCS.isDefined())
        {
          RealVect srcDx = m_vectInputDataDx[thicknessComp];
          CH_assert(srcDx[0] == m_vectInputDataDx[topoComp][0]);
          const LevelData<FArrayBox>& srcThickness = *m_vectInputDataLDF[thicknessComp];
          const LevelData<FArrayBox>& srcTopo = *m_vectInputDataLDF[topoComp];
          const DisjointBoxLayout srcGrids = srcThickness.getBoxes();
          CH_assert(srcGrids == srcTopo.getBoxes());


          m_referenceCS.define(srcGrids, srcDx, this);
          m_referenceCS.setTopography(srcTopo);
          LevelData<FArrayBox>& referenceCS_thickness = m_referenceCS.getH();
          srcThickness.copyTo(referenceCS_thickness);
          m_referenceCS.recomputeGeometry(a_crseCoords, a_refRatio);

        } // end defining levelSigmaCS
    } // end if interpolating upper surface


  Real tolerance = 1.0e-6;
  if (a_crseCoords != NULL &&
      a_refRatio * a_dx[0] <= m_vectInputDataDx[thicknessComp][0] * (1.0 + tolerance))
    {
      // in this (common) case, interpolation from a_crseCoords is as good as it gets
      if (m_verbose)
	{
	  pout() << " ...interpolating data from coarse LevelSigmaCS with refinement ratio = " 
		 << a_refRatio << endl;
	}

      a_coords.interpFromCoarse(*a_crseCoords, a_refRatio);
    }
  else if (!m_interpolate_upper_surface)
    {
      if (m_verbose)
        {
          pout() << "calling FillFromReference for thickness..." << endl;
        }

      int thicknessComp = getInputDataComp("thickness");
      RefCountedPtr<LevelData<FArrayBox> > thicknessLDF = m_vectInputDataLDF[thicknessComp];
      const RealVect& thicknessDx = m_vectInputDataDx[thicknessComp];

      FillFromReference(ChomboThickness,
			(*thicknessLDF),
			a_dx,
			thicknessDx,
			m_verbose);


      if (m_verbose)
        {
          pout() << "...and topography..." << endl;
        }


      int topoComp = getInputDataComp("topography");
      RefCountedPtr<LevelData<FArrayBox> > topoLDF = m_vectInputDataLDF[topoComp];
      const RealVect& topoDx = m_vectInputDataDx[topoComp];

      FillFromReference(ChomboTopography,
			(*topoLDF),
			a_dx,
			topoDx,
			m_verbose);
      if (m_verbose)
        {
          pout() << "...done!" << endl;
        }

      if (a_crseCoords!= NULL)
	{
          if (m_verbose)
            {
              pout() << "filling ghost cells" << endl;
            }
	  // fill ghost cells
	  a_coords.interpFromCoarse(*a_crseCoords, a_refRatio, 
				    false, false, false);
          if (m_verbose) 
            {
              pout() << "done filling ghost cells" << endl;
            }
	}

    } // end if interpolating thickness
  else 
    {
      // interpolate upper surface
      if (m_verbose)
        {
          pout() << "calling FillFromReference for upper surface..." << endl;
        }
      // define temp storage for usurf
      LevelData<FArrayBox> ChomboUsrf(ChomboTopography.getBoxes(), 1,
                                      ChomboTopography.ghostVect());
      
      const LevelData<FArrayBox>& referenceUsrf = m_referenceCS.getSurfaceHeight();

      FillFromReference(ChomboUsrf,
			referenceUsrf,
			a_dx,
			m_referenceCS.dx(),
			m_verbose);

      a_coords.setSurfaceHeight(ChomboUsrf);
      

      if (m_verbose)
        {
          pout() << "...and topography..." << endl;
        }


      int topoComp = getInputDataComp("topography");
      RefCountedPtr<LevelData<FArrayBox> > topoLDF = m_vectInputDataLDF[topoComp];
      const RealVect& topoDx = m_vectInputDataDx[topoComp];

      FillFromReference(ChomboTopography,
			(*topoLDF),
			a_dx,
			topoDx,
			m_verbose);
      if (m_verbose)
        {
          pout() << "...done!" << endl;
        }

      // now compute thickness from upper surface + topography
      a_coords.computeThicknessFromUpperSurface();

      if (a_crseCoords!= NULL)
	{
          if (m_verbose)
            {
              pout() << "filling ghost cells" << endl;
            }
	  // fill ghost cells
	  a_coords.interpFromCoarse(*a_crseCoords, a_refRatio, 
				    false, false, false);
          if (m_verbose) 
            {
              pout() << "done filling ghost cells" << endl;
            }
	}

    } // end if we're interpolating the upper surface

  if (m_verbose) 
    {      
      pout() << "calling exchange..." << endl;
    }
  ChomboThickness.exchange();
  //ChomboTopography.exchange();
  //LevelSigmaCS.exchangeTopography() takes care of constant topography slopes
  a_coords.exchangeTopography();
  
  // if we have ghost cells, then use extrapolation BC's (for now, at least)
  // to fill in reasonable values for topography and thickness
  m_extrapBoundary = true;
  geomPP.query("extrap_boundary", m_extrapBoundary );
  if (m_extrapBoundary)
    {
      if (m_verbose)
	{      
	  pout() << "extrapolating boundary thickness and topography" << endl;
	}
      ExtrapGhostCells(ChomboThickness, destDomain);
      ExtrapGhostCells(ChomboTopography, destDomain);
    }
  else 
    {
      //slc : I think reflection would make a better default : works for isolated
      //      islands (Antarctica, Greenland) and divides, 
      //      where grad(s) = grad(H) = grad(topo) = 0 (Pine Island).
      if (m_verbose)
	{      
	  pout() << "reflecting boundary thickness and topography" << endl;
	}
      for (int dir = 0; dir < SpaceDim; ++dir)
	{
	  ReflectGhostCells(ChomboThickness, destDomain, dir, Side::Lo);
	  ReflectGhostCells(ChomboThickness, destDomain, dir, Side::Hi);
	  ReflectGhostCells(ChomboTopography, destDomain, dir,  Side::Lo);
	  ReflectGhostCells(ChomboTopography, destDomain, dir, Side::Hi);
	}
    }
  //this can wait
  //a_coords.recomputeGeometry();
  if (m_verbose)
    {      
      pout() << "leaving FortranInterfaceIBC::initializeIceGeometry" << endl;
    }
}

void
FortranInterfaceIBC::regridIceGeometry(LevelSigmaCS& a_coords,
				       const RealVect& a_dx,
				       const RealVect& a_domainSize,
				       const Real& a_time, 
				       const LevelSigmaCS* a_crseCoords,
				       const int a_refRatio)
{

   if (m_verbose)
    {      
      pout() << "entering FortranInterfaceIBC::regridIceGeometry" << endl;
    }

   int thicknessComp = getInputDataComp("thickness");
   Real tolerance = 1.0e-6;
   if (a_crseCoords != NULL &&
       a_refRatio * a_dx[0] <= m_vectInputDataDx[thicknessComp][0] * (1.0 + tolerance))
     {
       // in this (common) case, interpolation from a_crseCoords is as good as it gets
       if (m_verbose)
	 {
	   pout() << " ...interpolating data from coarse LevelSigmaCS with refinement ratio = " 
		  << a_refRatio << endl;
	 }
       
       a_coords.interpFromCoarse(*a_crseCoords, a_refRatio);
     }
   else
     {
       int topoComp = getInputDataComp("topography");
       LevelData<FArrayBox>& ChomboTopography = a_coords.getTopography();
       FillFromReference(ChomboTopography,
			 *m_vectInputData[topoComp],
			 a_dx,
			 m_vectInputDataDx[topoComp],
			 m_vectInputDataGhost[topoComp],
			 m_verbose);
       if (a_crseCoords!= NULL)
	 {
	   // fill ghost cells
	   a_coords.interpFromCoarse(*a_crseCoords, a_refRatio, 
				     false, false, false);
	 }
     }
   if (m_verbose)
     {      
       pout() << "leaving FortranInterfaceIBC::regridIceGeometry" << endl;
     }
   
}

/*
  flatten thickness and basal topography back to input FArrayBoxes
  re-store in inputThickness and inputTopography -- not const 
  because we modify the values in the data holders
*/
void
FortranInterfaceIBC::flattenIceGeometry(const Vector<RefCountedPtr<LevelSigmaCS> > & a_amrGeometry)
{
  
  // start with coarsest level and call FillFromReference
  int numLevels = a_amrGeometry.size();
  // check for case where not all levels have been defined...
  for (int lev=numLevels-1; lev>0; lev--)
    {
      if (a_amrGeometry[lev].isNull())
        {
          numLevels = lev;
        }
    }

  Vector<LevelData<FArrayBox>* > vectH(numLevels, NULL);
  Vector<LevelData<FArrayBox>* > vectTopo(numLevels, NULL);
  Vector<LevelData<FArrayBox>* > vectSurface(numLevels, NULL);
  Vector<LevelData<FArrayBox>* > vectLowerSurface(numLevels, NULL);
  Vector<LevelData<FArrayBox>* > vectLowerCellZ(numLevels, NULL);
  Vector<LevelData<FArrayBox>* > vectLowerCellTemp(numLevels, NULL);
  Vector<LevelData<FArrayBox>* > vectFloatingMask(numLevels, NULL);
  Vector<LevelData<FArrayBox>* > vectIceMask(numLevels, NULL);
  Vector<RealVect> vectDx(numLevels);

  for (int lev=0; lev<numLevels; lev++)
    {
      const LevelData<FArrayBox>& levelThickness = a_amrGeometry[lev]->getH();
      const LevelData<FArrayBox>& levelTopography = a_amrGeometry[lev]->getTopography();
      const LevelData<FArrayBox>& levelSurface = a_amrGeometry[lev]->getSurfaceHeight();

      //const DisjointBoxLayout& levelGrids = levelThickness.getBoxes();
     
#if 0 
      CornerCopier cornerCopier(levelGrids, levelGrids, 
				levelGrids.physDomain(),
                                levelThickness.ghostVect());
#endif


      LevelData<FArrayBox>* levelLowerSurfacePtr = NULL;
      if (isDefined("lsurf"))
        {
          levelLowerSurfacePtr = new LevelData<FArrayBox>(levelSurface.getBoxes(), 1, IntVect::Zero);          
          DataIterator dit = levelThickness.dataIterator();
          for (dit.begin(); dit.ok(); ++dit)
            {
              const FArrayBox& thisH = levelThickness[dit];
              const FArrayBox& thisS = levelSurface[dit];
              FArrayBox& thisLsurf = (*levelLowerSurfacePtr)[dit];
              thisLsurf.copy(thisS, thisLsurf.box());
              thisLsurf.minus(thisH, thisLsurf.box(), 0,0,1);
            } // end loop over boxes to compute lsurf
          
        }

      LevelData<FArrayBox>* levelLowerCellZPtr=NULL;
      if (isDefined("lowerCellZ"))
        {
          levelLowerCellZPtr = new LevelData<FArrayBox>(levelThickness.getBoxes(), 1, IntVect::Zero);          
          vectLowerCellZ[lev] = levelLowerCellZPtr;
          // vector of sigma values
          const Vector<Real>& sigma = a_amrGeometry[lev]->getSigma();
          int nSigma = sigma.size();
          Real lowerSigmaVal = sigma[nSigma-1];
          Real thicknessFraction = 1.0 - lowerSigmaVal;
          DataIterator dit = levelThickness.dataIterator();
          for (dit.begin(); dit.ok(); ++dit)
            {
              const FArrayBox& thisH = levelThickness[dit];
              FArrayBox& thisLowerCellZ = (*levelLowerCellZPtr)[dit];
              // for now, take shortcut assuming that lower surface
              // is also defined
              FArrayBox& thisLsurf = (*levelLowerSurfacePtr)[dit];
              BoxIterator bit(thisLowerCellZ.box());
              for (bit.begin(); bit.ok(); ++bit)
                {
                  IntVect iv = bit();
                  Real ccval = thicknessFraction*thisH(iv,0);
                  thisLowerCellZ(iv,0) = thisLsurf(iv,0) + ccval;
                } // end loop over box
            } // end loop over boxes to compute lowerCellZ
          
        }

      LevelData<FArrayBox>* levelLowerCellTempPtr=NULL;
      if (isDefined("lowerCellTemp"))
        {
          levelLowerCellTempPtr = new LevelData<FArrayBox>(levelThickness.getBoxes(), 1, IntVect::Zero);          
          vectLowerCellTemp[lev] = levelLowerCellTempPtr;
          // for now, setval to something bogus
          DataIterator dit = levelLowerCellTempPtr->dataIterator();
          for (dit.begin(); dit.ok(); ++dit)
            {
              Real bogusTemp = 10000;
              (*levelLowerCellTempPtr)[dit].setVal(bogusTemp);
            }
        }

          
      
      LevelData<FArrayBox>* levelFloatingMaskPtr=NULL;
      if (isDefined("floatingMask"))
        {
          levelFloatingMaskPtr = new LevelData<FArrayBox>(levelSurface.getBoxes(), 1, IntVect::Zero);
          // now set mask: 0 = grounded, 1 = floating 
          LevelData<FArrayBox>& levelFloatingMask = *levelFloatingMaskPtr;
          const LevelData<BaseFab<int> >& levelIntegerMask = a_amrGeometry[lev]->getFloatingMask();
          DataIterator levelDit = levelFloatingMask.dataIterator();
          for (levelDit.begin(); levelDit.ok(); ++levelDit)
            {
              FArrayBox& destMask = levelFloatingMask[levelDit];
              // set default to be grounded
              // (on the theory that we are masking for ice shelves)
              destMask.setVal(0.0);
              // set real mask values
              Real realGroundedMaskVal = 0.0;
              Real realFloatingMaskVal = 1.0;
              const BaseFab<int>& intMask = levelIntegerMask[levelDit];
              BoxIterator bit(destMask.box());
              for (bit.begin(); bit.ok(); ++bit)
                {
                  IntVect iv = bit();
                  if (intMask(iv,0) == GROUNDEDMASKVAL) 
                    {
                      destMask(iv,0) = realGroundedMaskVal;
                    }
                  else if (intMask(iv,0) == FLOATINGMASKVAL)
                    {
                      destMask(iv,0) = realFloatingMaskVal;
                    }
                  else if (intMask(iv,0) == OPENLANDMASKVAL)
                    {     
                      // open land == grounded
                      destMask(iv,0) = realGroundedMaskVal;
                    }
                  else if (intMask(iv,0) == OPENSEAMASKVAL)
                    {
                      // open sea -> floating 
                      destMask(iv,0) = realFloatingMaskVal;
                    }
                  
                } // end loop over box
            } // end loop over grids
          levelFloatingMask.exchange();
        }


      LevelData<FArrayBox>* levelIceMaskPtr=NULL;
      if (isDefined("iceMask"))
        {
          levelIceMaskPtr = new LevelData<FArrayBox>(levelSurface.getBoxes(), 1, IntVect::Zero);
          // now set mask: 0 = no ice, 1 = ice 
          //#define USE_AMRICE_MASK
#ifdef USE_AMRICE_MASK
          // use mask computed in AmrIce
#else
          // define our own mask
          LevelData<FArrayBox>& levelIceMask = *levelIceMaskPtr;
          const LevelData<BaseFab<int> >& levelIntegerMask = a_amrGeometry[lev]->getFloatingMask();
          DataIterator levelDit = levelIceMask.dataIterator();
          for (levelDit.begin(); levelDit.ok(); ++levelDit)
            {
              FArrayBox& destMask = levelIceMask[levelDit];
              // set default to be no ice
              destMask.setVal(0.0);
              // set real mask values
              Real realNoIceMaskVal = 0.0;
              Real realIceMaskVal = 1.0;
              const BaseFab<int>& intMask = levelIntegerMask[levelDit];
              BoxIterator bit(destMask.box());
              for (bit.begin(); bit.ok(); ++bit)
                {
                  IntVect iv = bit();
                  if (intMask(iv,0) == GROUNDEDMASKVAL) 
                    {
                      destMask(iv,0) = realIceMaskVal;
                    }
                  else if (intMask(iv,0) == FLOATINGMASKVAL)
                    {
                      destMask(iv,0) = realIceMaskVal;
                    }
                  else if (intMask(iv,0) == OPENLANDMASKVAL)
                    {     
                      // open land == no ice
                      destMask(iv,0) = realNoIceMaskVal;
                    }
                  else if (intMask(iv,0) == OPENSEAMASKVAL)
                    {
                      // open sea -> no ice 
                      destMask(iv,0) = realNoIceMaskVal;
                    }
                  
                } // end loop over box
            } // end loop over grids
          levelIceMask.exchange();
        }
#endif
      RealVect levelDx = a_amrGeometry[lev]->dx();

      // can cast away const-ness here because they will be sent in as 
      // const arguments
      vectH[lev] = const_cast<LevelData<FArrayBox>* >(&levelThickness);
//      vectH[lev]->exchange(vectH[lev]->interval(), cornerCopier);
      vectTopo[lev] = const_cast<LevelData<FArrayBox>* >(&levelTopography);
      vectSurface[lev] = const_cast<LevelData<FArrayBox>* >(&levelSurface);
      vectLowerSurface[lev] = levelLowerSurfacePtr;
      vectFloatingMask[lev] = levelFloatingMaskPtr;
      vectIceMask[lev] = levelIceMaskPtr;
      vectDx[lev] = levelDx;
      
      
      // these can be useful for debugging..
      bool resetInitialLevel = false;
      bool resetEachLevel = false;
      if (resetEachLevel || (resetInitialLevel && (lev == 0)))
        {
          RefCountedPtr<LevelData<FArrayBox> >& thicknessLDFPtr = inputLDFPtr("thickness");
          DataIterator dit = thicknessLDFPtr->dataIterator();
          for (dit.begin(); dit.ok(); ++dit)
            {
              (*thicknessLDFPtr)[dit].setVal(float(lev*111));
            }
        }

    } // end loop over levels

  // now flatten and copy back to the input storage

  if (isDefined("thickness") )
    {
      flattenAndCopyToInput(vectH, vectDx,  "thickness");
    }

  if (isDefined("topography"))
    {
      flattenAndCopyToInput(vectTopo, vectDx, "topography");
    }

  if (isDefined("usurf"))
    {
      flattenAndCopyToInput(vectSurface, vectDx, "usurf");
    }

  if (isDefined("lsurf"))
    {
      flattenAndCopyToInput(vectLowerSurface, vectDx, "lsurf");
    }

  if (isDefined("lowerCellZ"))
    {
      flattenAndCopyToInput(vectLowerCellZ, vectDx, "lowerCellZ");
    }

  if (isDefined("lowerCellTemp"))
    {
      flattenAndCopyToInput(vectLowerCellTemp, vectDx,  "lowerCellTemp");
    }


  if (isDefined("floatingMask"))
    {
      flattenAndCopyToInput(vectFloatingMask, vectDx, "floatingMask");
    }
  
  if (isDefined("iceMask"))
    {
      flattenAndCopyToInput(vectIceMask, vectDx, "iceMask");
    }
  


  // clean up storage
  for (int lev=0; lev< vectLowerSurface.size(); lev++)
    {
      if (vectLowerSurface[lev] != NULL)
        {
          delete vectLowerSurface[lev];
          vectLowerSurface[lev] = NULL;
        }
    }

  for (int lev=0; lev< vectFloatingMask.size(); lev++)
    {
      if (vectFloatingMask[lev] != NULL)
        {
          delete vectFloatingMask[lev];
          vectFloatingMask[lev] = NULL;
        }
    }


  for (int lev=0; lev< vectIceMask.size(); lev++)
    {
      if (vectIceMask[lev] != NULL)
        {
          delete vectIceMask[lev];
          vectIceMask[lev] = NULL;
        }
    }


  for (int lev=0; lev< vectLowerCellZ.size(); lev++)
    {
      if (vectLowerCellZ[lev] != NULL)
        {
          delete vectLowerCellZ[lev];
          vectLowerCellZ[lev] = NULL;
        }
    }



  for (int lev=0; lev< vectLowerCellTemp.size(); lev++)
    {
      if (vectLowerCellTemp[lev] != NULL)
        {
          delete vectLowerCellTemp[lev];
          vectLowerCellTemp[lev] = NULL;
        }
    }

}


/// flatten an arbitrary dataset back to input FArrayBoxes
void
FortranInterfaceIBC::flattenData(Real* a_data_ptr,
                                 const int* a_dimInfo,
                                 const int* a_boxlo, const int* a_boxhi,
                                 const Real* a_dew, const Real* a_dns,
                                 const IntVect& a_offset,
                                 Vector<LevelData<FArrayBox>* >& a_amrData,
                                 const Vector<int>& a_vectRefRatio,
                                 const Vector<Real>& a_amrDx,
                                 int a_srcComp,
                                 int a_destComp,
                                 int a_nComp,
                                 const IntVect& a_nGhost,
                                 const bool a_nodal)
{
  RealVect dx(D_DECL(*a_dew,*a_dns,*a_dew) );
              
  // first set up FArrayBox
  FArrayBox dataFab, CCdataFab;

  setFAB(a_data_ptr, a_dimInfo, a_boxlo, a_boxhi,
         a_dew, a_dns, a_offset, a_nGhost,
         dataFab, CCdataFab, a_nodal, m_verbose);
        
  // if we haven't already set the grids, do it now
  if (!gridsSet())
    {
      if (m_verbose) 
        {
          pout() << " -- entering setGrids" << endl;
        }
      Box gridBox(CCdataFab.box());
      //gridBox.grow(-a_nGhost);
      setGrids(m_grids, gridBox, m_domain, a_nGhost, a_nodal, m_verbose);
      m_gridsSet = true;
      if (m_verbose)
        {
          pout() << " -- out of setGrids" << endl;
        }
    }
      
  // create LevelData
  // if nodal, we'd like at least one ghost cell for the LDF
  // (since we'll eventually have to average back to nodes)
  int thicknessComp = getInputDataComp("thickness");
  IntVect LDFghost = m_vectInputDataGhost[thicknessComp];
  if (a_nodal && (LDFghost[0] == 0))
    {
      LDFghost += IntVect::Unit;
    }
  LevelData<FArrayBox> ldf(m_grids, a_amrData[0]->nComp(), LDFghost);


  Vector<RealVect> vectDx(a_amrDx.size());
  for (int lev=0; lev<vectDx.size(); lev++)
    {
      RealVect levelDx = a_amrDx[lev]*RealVect::Unit;
      vectDx[lev] = levelDx;
    }
  flattenCellData(ldf, dx, a_amrData, vectDx, m_verbose);


#if 0
  // start with coarsest level, calling FillFromReference
  int numLevels = a_amrData.size();
    // check for case where not all levels are actually defined
  for (int lev=numLevels-1; lev>0; lev--)
    {
      if (a_amrData[lev] == NULL)
        {
          numLevels = lev;
        }
      else if (a_amrData[lev]->nComp() == 0)
        {
          numLevels = lev;
        }
    }


  for (int lev=0; lev<numLevels; lev++)
    {
      RealVect levelDx = a_amrDx[lev]*RealVect::Unit;
      FillFromReference(ldf, *a_amrData[lev],
                        dx, levelDx,
                        m_verbose);
    }
#endif

  ldf.exchange();

  // finally, either copy or average to nodes
  if (a_nodal)
    {
      // have to average back to nodes
      DataIterator dit= ldf.dataIterator();
      //const DisjointBoxLayout& grids = ldf.getBoxes();
      for (dit.begin(); dit.ok(); ++dit)
        {
          const Box nodeBox = dataFab.box();
          Box grownCCBox = nodeBox;
          grownCCBox.enclosedCells();
          grownCCBox.grow(1);
          
          FArrayBox ccGrownFAB(grownCCBox,ldf.nComp());
          ccGrownFAB.copy(ldf[dit]);

          for (int i=0; i<a_nComp; i++)
            {
              FORT_CELLTONODE(CHF_FRA1(dataFab,a_destComp+i),
                              CHF_CONST_FRA1(ccGrownFAB,a_srcComp+i),
                              CHF_BOX(nodeBox));
            }
          
        } // end dataIterator "loop"
      
    } // end if nodal thickness    
  else
    {
      // simple copy will do
      DataIterator dit= ldf.dataIterator();
      const DisjointBoxLayout& grids = ldf.getBoxes();
      for (dit.begin(); dit.ok(); ++dit)
        {
          Box intersectBox(grids[dit]);
          intersectBox &= CCdataFab.box();
                           
          CCdataFab.copy(ldf[dit], a_srcComp, a_destComp, a_nComp);
          
        } // end dataIterator "loop"
    } // end if not nodal

}


/// flatten an arbitrary dataset back to input FArrayBoxes
/* src data kept constant
 */
void
FortranInterfaceIBC::flattenDataConst(Real* a_data_ptr,
                                      const int* a_dimInfo,
                                      const int* a_boxlo, const int* a_boxhi,
                                      const Real* a_dew, const Real* a_dns,
                                      const IntVect& a_offset,
                                      const Vector<LevelData<FArrayBox>* >& a_amrData,
                                      const Vector<int>& a_vectRefRatio,
                                      const Vector<Real>& a_amrDx,
                                      int a_srcComp,
                                      int a_destComp,
                                      int a_nComp,
                                      const IntVect& a_nGhost,
                                      const bool a_nodal)
{
  RealVect dx(D_DECL(*a_dew,*a_dns,*a_dew) );
              
  // first set up FArrayBox
  FArrayBox dataFab, CCdataFab;

  setFAB(a_data_ptr, a_dimInfo, a_boxlo, a_boxhi,
         a_dew, a_dns, a_offset, a_nGhost,
         dataFab, CCdataFab, a_nodal, m_verbose);
        
  // if we haven't already set the grids, do it now
  if (!gridsSet())
    {
      if (m_verbose) 
        {
          pout() << " -- entering setGrids" << endl;
        }
      Box gridBox(CCdataFab.box());
      //gridBox.grow(-a_nGhost);
      setGrids(m_grids, gridBox, m_domain, a_nGhost, a_nodal, m_verbose);
      m_gridsSet = true;
      if (m_verbose)
        {
          pout() << " -- out of setGrids" << endl;
        }
    }
      
  // create LevelData
  // if nodal, we'd like at least one ghost cell for the LDF
  // (since we'll eventually have to average back to nodes)
  int thicknessComp = getInputDataComp("thickness");
  IntVect LDFghost = m_vectInputDataGhost[thicknessComp];
  if (a_nodal && (LDFghost[0] == 0))
    {
      LDFghost += IntVect::Unit;
    }
  LevelData<FArrayBox> ldf(m_grids, a_amrData[0]->nComp(), LDFghost);
              
  // start with coarsest level, calling FillFromReference
  int numLevels = a_amrData.size();
    // check for case where not all levels are actually defined
  for (int lev=numLevels-1; lev>0; lev--)
    {
      if (a_amrData[lev] == NULL)
        {
          numLevels = lev;
        }
      else if (a_amrData[lev]->nComp() == 0)
        {
          numLevels = lev;
        }
    }

  for (int lev=0; lev<numLevels; lev++)
    {
      RealVect levelDx = a_amrDx[lev]*RealVect::Unit;
      FillFromReference(ldf, *a_amrData[lev],
                        dx, levelDx,
                        m_verbose);
    }

  ldf.exchange();

  // finally, either copy or average to nodes
  if (a_nodal)
    {
      // have to average back to nodes
      DataIterator dit= ldf.dataIterator();
      //const DisjointBoxLayout& grids = ldf.getBoxes();
      for (dit.begin(); dit.ok(); ++dit)
        {
          const Box nodeBox = dataFab.box();
          Box grownCCBox = nodeBox;
          grownCCBox.enclosedCells();
          grownCCBox.grow(1);
          
          FArrayBox ccGrownFAB(grownCCBox,ldf.nComp());
          ccGrownFAB.copy(ldf[dit]);

          for (int i=0; i<a_nComp; i++)
            {
              FORT_CELLTONODE(CHF_FRA1(dataFab,a_destComp+i),
                              CHF_CONST_FRA1(ccGrownFAB,a_srcComp+i),
                              CHF_BOX(nodeBox));
            }
          
        } // end dataIterator "loop"
      
    } // end if nodal thickness    
  else
    {
      // simple copy will do
      DataIterator dit= ldf.dataIterator();
      const DisjointBoxLayout& grids = ldf.getBoxes();
      for (dit.begin(); dit.ok(); ++dit)
        {
          Box intersectBox(grids[dit]);
          intersectBox &= CCdataFab.box();
                           
          CCdataFab.copy(ldf[dit], a_srcComp, a_destComp, a_nComp);
          
        } // end dataIterator "loop"
    } // end if not nodal

}


/// flatten velocity field to the 3D velocity data holder
void
FortranInterfaceIBC::flattenVelocity(Real* a_uVelPtr, Real* a_vVelPtr,
                                     const int* a_dimInfo,
                                     const int* a_boxlo, const int* a_boxhi,
                                     const Real* a_dew, const Real* a_dns,
                                     const IntVect& a_offset,
                                     Vector<LevelData<FArrayBox>* >& a_amrVel,
                                     const Vector<int>& a_vectRefRatio,
                                     const Vector<Real>& a_amrDx,
                                     const IntVect& a_nGhost,
                                     const bool a_nodal)
{

  pout() << "in FortranInterfaceIBC::flattenVelocity" << endl;

  RealVect dx(D_DECL(*a_dew,*a_dns,*a_dew) );
  
  // first set up FArrayBox
  FArrayBox uDataFab, vDataFab, uCCdataFab, vCCdataFab;
  
  setVelFAB(a_uVelPtr, a_vVelPtr,a_dimInfo, a_boxlo, a_boxhi,
            a_dew, a_dns, a_offset, a_nGhost,
            uDataFab, vDataFab, uCCdataFab, vCCdataFab, a_nodal,
            false);

  
  if (m_verbose)
    {
      pout() << "exited setVelFAB function: uDataFAB box: " 
             << uDataFab.box() << ", ncomp = " << uDataFab.nComp() << endl;
      pout() << "                           vDataFAB box: "
             << vDataFab.box() << ", ncomp = " << vDataFab.nComp() << endl;
    }

  // create LevelData
  // if nodal, we'd like one more ghost cell for the LDF than nghost
  // (since we'll need to average back to nodes)
  IntVect LDFghost = a_nGhost;
  if (a_nodal)
    {
      LDFghost += IntVect::Unit;
    }

  LevelData<FArrayBox> ldf(m_grids, SpaceDim, LDFghost);

  // need to create Vector<RealVect> form of dx
  Vector<RealVect> realVectDx(a_amrDx.size());
  for (int i=0; i<a_amrDx.size(); i++)
    {
      realVectDx[i] = a_amrDx[i]*RealVect::Unit;
    }

  flattenCellData(ldf, dx, a_amrVel, realVectDx, m_verbose);
  
  if (m_verbose)  pout () << "before exchange" << endl;
  ldf.exchange();

  //writeLevel(&ldf);
  if (m_verbose) pout() << "after exchange" << endl;


  //#define SET_CONST_VEL 
#ifdef SET_CONST_VEL
  // debugging aid -- set velocity to a constant value in each box
  {
    Real uVal = 1.0 + procID();
    Real vVal = 10.0 + procID();

    pout() << "uVal = " << uVal << endl;
    pout() << "vVal = " << vVal << endl;

    DataIterator dit = ldf.dataIterator();
    for (dit.begin(); dit.ok(); ++dit)
      {
        FArrayBox& velFab = ldf[dit];
        Box gridBox = m_grids[dit];
        velFab.setVal(uVal, gridBox, 0);
        velFab.setVal(vVal, gridBox, 1);
      }
  }
  //writeLevel(&ldf);
#endif

  // finally, either copy or average to nodes
  if (a_nodal)
    {
      // have to average back to nodes
      DataIterator dit= ldf.dataIterator();
      const DisjointBoxLayout& grids = ldf.getBoxes();
      for (dit.begin(); dit.ok(); ++dit)
        {
          Box nodeBox = grids[dit];
          nodeBox.surroundingNodes();
          // shrink by one because velocities are only on interior nodes
          nodeBox.grow(-1);
          nodeBox.grow(a_nGhost);

          // first do u...
          int xghost = a_nGhost[0];
          int xoffset = a_offset[0];
          
          if (m_verbose) pout () << "entering cell-to-node" << endl;
          
          IntVect boxloVect(D_DECL(a_boxlo[0], a_boxlo[1], a_boxlo[2]));


          //#define COMPUTE_VEL_DIFFS  1
#ifdef COMPUTE_VEL_DIFFS
          // save copy of original velocity to subtract off if we want
          // differences
          FArrayBox diffFab(uDataFab.box(), uDataFab.nComp());
          diffFab.copy(uDataFab);
#endif
          pout() << "nodeBox = " << nodeBox << endl;
          FORT_CELLTONODECISMVELNOSHEAR(CHF_FRA(uDataFab),
                                        CHF_CONST_FRA1(ldf[dit],0),
                                        CHF_CONST_INT(xghost),
                                        CHF_CONST_INT(xoffset),
                                        CHF_INTVECT(boxloVect),
                                        CHF_BOX(nodeBox));
#ifdef COMPUTE_VEL_DIFFS
          uDataFab.minus(diffFab);
#endif

          if (SpaceDim > 1)
            {
              // ...then do v
              int yghost = a_nGhost[1];
              int yoffset = a_offset[1];
#ifdef COMPUTE_VEL_DIFFS
              diffFab.copy(vDataFab);
#endif
              FORT_CELLTONODECISMVELNOSHEAR(CHF_FRA(vDataFab),
                                            CHF_CONST_FRA1(ldf[dit],1),
                                            CHF_CONST_INT(yghost),
                                            CHF_CONST_INT(yoffset),
                                            CHF_INTVECT(boxloVect),
                                            CHF_BOX(nodeBox));
#ifdef COMPUTE_VEL_DIFFS
              vDataFab.minus(diffFab);
#endif            
            }

#if 0
          // debugging dump
          if (m_verbose) 
            {
              pout () << "uData: " << endl;
              BoxIterator uBit(uDataFab.box());
              for (uBit.begin(); uBit.ok(); ++uBit)
                {
                  IntVect iv = uBit();
                  int testComp = uDataFab.nComp()/2;
                  pout() << iv << ":  " << uDataFab(iv,testComp) << endl;
                }
              pout() << endl;
              pout() << endl;
              //pout () << "vData: " << vDataFab << endl;
            }
#endif

        } // end dataIterator "loop"
      
    } // end if nodal 
  else
    {
      // would be a simple copy, except for the ijk->kij conversion
      DataIterator dit= ldf.dataIterator();
      const DisjointBoxLayout& grids = ldf.getBoxes();
      for (dit.begin(); dit.ok(); ++dit)
        {

          Box cellBox = grids[dit];
          cellBox.grow(a_nGhost);
          
          // account for the "extra" cell we added in 
          for (int dir=0; dir<SpaceDim; dir++)
            {
              if (cellBox.smallEnd()[dir] > m_domain.domainBox().smallEnd()[dir])
                {
                  cellBox.growLo(dir,-1);
                }
            }

          // first do u...
          int xghost = a_nGhost[0];
          int xoffset = a_offset[0];

          // initial "no-shear" implementation. Copy to 
          // each sigma level

          IntVect boxloVect(D_DECL(a_boxlo[0], a_boxlo[1], a_boxlo[2]));

          if (m_verbose)
            {
              pout() << "calling cismvelnoshear: " << endl;
              pout() << "                       uDataFab: " << uDataFab.box() << endl;
              pout() << "                       ldf fab : " << ldf[dit].box() << endl;
              pout() << "                       xghost = " << xghost << ", xoffset = " << xoffset << endl;
              pout() << "                       boxlovect = " << boxloVect << endl;
              pout() << "                       cellBox = " << cellBox << endl;
            }

          FORT_CISMVELNOSHEAR(CHF_FRA(uDataFab),
                              CHF_CONST_FRA1(ldf[dit],0),
                              CHF_CONST_INT(xghost),
                              CHF_CONST_INT(xoffset),
                              CHF_INTVECT(boxloVect),
                              CHF_BOX(cellBox));

          if (SpaceDim > 1)
            {
              // ...then do v
              int yghost = a_nGhost[1];
              int yoffset = a_offset[1];

              FORT_CISMVELNOSHEAR(CHF_FRA(vDataFab),
                                  CHF_CONST_FRA1(ldf[dit],1),
                                  CHF_CONST_INT(yghost),
                                  CHF_CONST_INT(yoffset),
                                  CHF_INTVECT(boxloVect),
                                  CHF_BOX(cellBox));
            }


          
        } // end dataIterator "loop"
    } // end if not nodal


}


/// flatten velocity field to the 3D velocity data holder
void
FortranInterfaceIBC::flattenVelocityConst(Real* a_uVelPtr, Real* a_vVelPtr,
                                          const int* a_dimInfo,
                                          const int* a_boxlo, const int* a_boxhi,
                                          const Real* a_dew, const Real* a_dns,
                                          const IntVect& a_offset,
                                          const Vector<LevelData<FArrayBox>* >& a_amrVel,
                                          const Vector<int>& a_vectRefRatio,
                                          const Vector<Real>& a_amrDx,
                                          const IntVect& a_nGhost,
                                          const bool a_nodal)
{

  pout() << "in FortranInterfaceIBC::flattenVelocity" << endl;

  RealVect dx(D_DECL(*a_dew,*a_dns,*a_dew) );
  
  // first set up FArrayBox
  FArrayBox uDataFab, vDataFab, uCCdataFab, vCCdataFab;
  
  setVelFAB(a_uVelPtr, a_vVelPtr,a_dimInfo, a_boxlo, a_boxhi,
            a_dew, a_dns, a_offset, a_nGhost,
            uDataFab, vDataFab, uCCdataFab, vCCdataFab, a_nodal,
            false);

  
  if (m_verbose)
    {
      pout() << "exited setVelFAB function: uDataFAB box: " 
             << uDataFab.box() << ", ncomp = " << uDataFab.nComp() << endl;
      pout() << "                           vDataFAB box: "
             << vDataFab.box() << ", ncomp = " << vDataFab.nComp() << endl;
    }

  // create LevelData
  // if nodal, we'd like one more ghost cell for the LDF than nghost
  // (since we'll need to average back to nodes)
  IntVect LDFghost = a_nGhost;
  if (a_nodal)
    {
      LDFghost += IntVect::Unit;
    }

  LevelData<FArrayBox> ldf(m_grids, SpaceDim, LDFghost);

  // need to create Vector<RealVect> form of dx
  Vector<RealVect> realVectDx(a_amrDx.size());
  for (int i=0; i<a_amrDx.size(); i++)
    {
      realVectDx[i] = a_amrDx[i]*RealVect::Unit;
    }

  flattenCellDataConst(ldf, dx, a_amrVel, realVectDx, m_verbose);
  
  if (m_verbose)  pout () << "before exchange" << endl;
  ldf.exchange();

  //writeLevel(&ldf);
  if (m_verbose) pout() << "after exchange" << endl;


  //#define SET_CONST_VEL 
#ifdef SET_CONST_VEL
  // debugging aid -- set velocity to a constant value in each box
  {
    Real uVal = 1.0 + procID();
    Real vVal = 10.0 + procID();

    pout() << "uVal = " << uVal << endl;
    pout() << "vVal = " << vVal << endl;

    DataIterator dit = ldf.dataIterator();
    for (dit.begin(); dit.ok(); ++dit)
      {
        FArrayBox& velFab = ldf[dit];
        Box gridBox = m_grids[dit];
        velFab.setVal(uVal, gridBox, 0);
        velFab.setVal(vVal, gridBox, 1);
      }
  }
  //writeLevel(&ldf);
#endif

  // finally, either copy or average to nodes
  if (a_nodal)
    {
      // have to average back to nodes
      DataIterator dit= ldf.dataIterator();
      const DisjointBoxLayout& grids = ldf.getBoxes();
      for (dit.begin(); dit.ok(); ++dit)
        {
          Box nodeBox = grids[dit];
          nodeBox.surroundingNodes();
          // shrink by one because velocities are only on interior nodes
          nodeBox.grow(-1);
          nodeBox.grow(a_nGhost);

          // first do u...
          int xghost = a_nGhost[0];
          int xoffset = a_offset[0];
          
          if (m_verbose) pout () << "entering cell-to-node" << endl;
          
          IntVect boxloVect(D_DECL(a_boxlo[0], a_boxlo[1], a_boxlo[2]));


          //#define COMPUTE_VEL_DIFFS  1
#ifdef COMPUTE_VEL_DIFFS
          // save copy of original velocity to subtract off if we want
          // differences
          FArrayBox diffFab(uDataFab.box(), uDataFab.nComp());
          diffFab.copy(uDataFab);
#endif
          pout() << "nodeBox = " << nodeBox << endl;
          FORT_CELLTONODECISMVELNOSHEAR(CHF_FRA(uDataFab),
                                        CHF_CONST_FRA1(ldf[dit],0),
                                        CHF_CONST_INT(xghost),
                                        CHF_CONST_INT(xoffset),
                                        CHF_INTVECT(boxloVect),
                                        CHF_BOX(nodeBox));
#ifdef COMPUTE_VEL_DIFFS
          uDataFab.minus(diffFab);
#endif

          if (SpaceDim > 1)
            {
              // ...then do v
              int yghost = a_nGhost[1];
              int yoffset = a_offset[1];
#ifdef COMPUTE_VEL_DIFFS
              diffFab.copy(vDataFab);
#endif
              FORT_CELLTONODECISMVELNOSHEAR(CHF_FRA(vDataFab),
                                            CHF_CONST_FRA1(ldf[dit],1),
                                            CHF_CONST_INT(yghost),
                                            CHF_CONST_INT(yoffset),
                                            CHF_INTVECT(boxloVect),
                                            CHF_BOX(nodeBox));
#ifdef COMPUTE_VEL_DIFFS
              vDataFab.minus(diffFab);
#endif            
            }

#if 0
          // debugging dump
          if (m_verbose) 
            {
              pout () << "uData: " << endl;
              BoxIterator uBit(uDataFab.box());
              for (uBit.begin(); uBit.ok(); ++uBit)
                {
                  IntVect iv = uBit();
                  int testComp = uDataFab.nComp()/2;
                  pout() << iv << ":  " << uDataFab(iv,testComp) << endl;
                }
              pout() << endl;
              pout() << endl;
              //pout () << "vData: " << vDataFab << endl;
            }
#endif

        } // end dataIterator "loop"
      
    } // end if nodal 
  else
    {
      // would be a simple copy, except for the ijk->kij conversion
      DataIterator dit= ldf.dataIterator();
      const DisjointBoxLayout& grids = ldf.getBoxes();
      for (dit.begin(); dit.ok(); ++dit)
        {

          Box cellBox = grids[dit];
          cellBox.grow(a_nGhost);
          
          // account for the "extra" cell we added in 
          for (int dir=0; dir<SpaceDim; dir++)
            {
              if (cellBox.smallEnd()[dir] > m_domain.domainBox().smallEnd()[dir])
                {
                  cellBox.growLo(dir,-1);
                }
            }

          // first do u...
          int xghost = a_nGhost[0];
          int xoffset = a_offset[0];

          // initial "no-shear" implementation. Copy to 
          // each sigma level

          IntVect boxloVect(D_DECL(a_boxlo[0], a_boxlo[1], a_boxlo[2]));

          if (m_verbose)
            {
              pout() << "calling cismvelnoshear: " << endl;
              pout() << "                       uDataFab: " << uDataFab.box() << endl;
              pout() << "                       ldf fab : " << ldf[dit].box() << endl;
              pout() << "                       xghost = " << xghost << ", xoffset = " << xoffset << endl;
              pout() << "                       boxlovect = " << boxloVect << endl;
              pout() << "                       cellBox = " << cellBox << endl;
            }

          FORT_CISMVELNOSHEAR(CHF_FRA(uDataFab),
                              CHF_CONST_FRA1(ldf[dit],0),
                              CHF_CONST_INT(xghost),
                              CHF_CONST_INT(xoffset),
                              CHF_INTVECT(boxloVect),
                              CHF_BOX(cellBox));

          if (SpaceDim > 1)
            {
              // ...then do v
              int yghost = a_nGhost[1];
              int yoffset = a_offset[1];

              FORT_CISMVELNOSHEAR(CHF_FRA(vDataFab),
                                  CHF_CONST_FRA1(ldf[dit],1),
                                  CHF_CONST_INT(yghost),
                                  CHF_CONST_INT(yoffset),
                                  CHF_INTVECT(boxloVect),
                                  CHF_BOX(cellBox));
            }


          
        } // end dataIterator "loop"
    } // end if not nodal


}


void 
FortranInterfaceIBC::setupBCs()
{
  ParmParse ppBC("bc");

  // get boundary conditions 
  Vector<int> loBCvect(SpaceDim), hiBCvect(SpaceDim);
  ppBC.getarr("lo_bc", loBCvect, 0, SpaceDim);
  ppBC.getarr("hi_bc", hiBCvect, 0, SpaceDim);
  bool new_bc = false;
  ppBC.query("new_bc", new_bc);

  if (new_bc)
    {
      m_velBCs = RefCountedPtr<BCFunction>(dynamic_cast<BCFunction*>(new CompGridVTOBC));
      // now specifically set bcs (default is dirichlet)
      for (int dir=0; dir<SpaceDim; dir++)
        {
          // first do low-side...
          // dirichlet case
          if (loBCvect[dir] == 0)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][0][comp] = true;
                }
            }
          // neumann case
          else if (loBCvect[dir] == 1)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][0][comp] = false;
                }
            }
          // slip-wall -- Dirichlet in normal direction, free-slip otherwise
          else if (loBCvect[dir] == 2)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][0][comp] = false;
                }
              m_velBCs->m_bcDiri[dir][0][dir] = true;
            }
          else
            {
              MayDay::Error("Unknown BC type in MarineIBC::setupBCs");
            }

          // then do high side...
          // dirichlet case
          if (hiBCvect[dir] == 0)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][1][comp] = true;
                }
            }
          // neumann case
          else if (hiBCvect[dir] == 1)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][1][comp] = false;
                }
            }
          // slip-wall case -- Dirichlet in normal direction, free-slip otherwis
          else if (hiBCvect[dir] == 2)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][1][comp] = false;
                }
              m_velBCs->m_bcDiri[dir][1][dir] = true;
            }
          else
            {
              MayDay::Error("Unknown BC type in MarineIBC::setupBCs");
            }
        } // end loop over directions    

    } // end if using new bcs
  else
    {
      // if all BCs are the same, calll the basic BC functions
      if ((loBCvect[0] == loBCvect[1]) &&
          (hiBCvect[0] == hiBCvect[1]) &&
          (loBCvect[0] == hiBCvect[0]))
        {
          if (loBCvect[0] == FIBC_Dirichlet)
            {
              m_velBCs = RefCountedPtr<CompGridVTOBC>(new IceBCFuncWrapper(iceDirichletBC_FIBC));
            }
          else if (loBCvect[0] == FIBC_Neumann)
            {
              m_velBCs = RefCountedPtr<CompGridVTOBC>(new IceBCFuncWrapper(iceNeumannBC_FIBC));
            }
          else if (loBCvect[0] == FIBC_iceDivide)
            {
              m_velBCs = RefCountedPtr<BCFunction>(new BCFuncWrapper(iceDivideBC_FIBC));
            }
          else if (loBCvect[0] == FIBC_iceStreamXBC)
            {
              m_velBCs = RefCountedPtr<BCFunction>(new BCFuncWrapper(iceStreamXBC_FIBC));
            }
          else
            {
              MayDay::Error("bad BC type");
            }
        }
      else
        {
          m_velBCs = RefCountedPtr<BCFunction>(new BCFuncWrapper(combinedBC_FIBC));
          
        }
    } // end if not new bc
  m_isBCsetUp = true;
}
      
void FortranInterfaceIBC::checkOK() const
{
  int topoComp = getInputDataComp("topography");
  const FArrayBox& inputTopography = *m_vectInputData[topoComp];
  if (m_verbose)
    {
      pout() << "FortranInterfaceIBC::checkOK() &inputTopography = " 
             << &inputTopography << std::endl;
    }
  CH_assert(inputTopography.norm(0) < 1.0e+5);
}

// non-const accessor
RefCountedPtr<LevelData<FArrayBox> >& 
FortranInterfaceIBC::inputLDFPtr(const string& a_varName) 
{
  int dataComp = -1;
  for (int i=0; i<m_numVar; i++)
    {
      if (m_vectInputDataNames[i] == a_varName)
        {
          dataComp = i;
        }
    }
  if (dataComp < 0)
    {
      pout() << "failed to find " << a_varName << endl;
      MayDay::Error("FortranInterfaceIBC::inputLDFPtr -- varName not found");
    }
  return m_vectInputDataLDF[dataComp];
}

// const accessor
const RefCountedPtr<LevelData<FArrayBox> >& 
FortranInterfaceIBC::inputLDFPtr(const string& a_varName) const
{
  int dataComp = -1;
  for (int i=0; i<m_numVar; i++)
    {
      if (m_vectInputDataNames[i] == a_varName)
        {
          dataComp = i;
        }
    }
  if (dataComp < 0)
    {
      pout() << "failed to find " << a_varName << endl;
      MayDay::Error("FortranInterfaceIBC::inputLDFPtr -- varName not found");
    }
  return m_vectInputDataLDF[dataComp];
}


/// has the variable been defined in the IBC?
bool
FortranInterfaceIBC::isDefined(const string& a_varName) const
{
  bool is_defined = false;
  for (int i=0; i<m_numVar; i++)
    {
      if (m_vectInputDataNames[i] == a_varName)
        {
          is_defined = true;
        }
    }
  
  return is_defined;
}

/// what component number in the IBC is the variable? (-1 means undefined)ssss
int
FortranInterfaceIBC::getInputDataComp(const string& a_varName) const
{
  int dataComp = -1;
  for (int i=0; i<m_numVar; i++)
    {
      if (m_vectInputDataNames[i] == a_varName)
        {
          dataComp = i;
        }
    }
  
  return dataComp;
}


void 
FortranInterfaceIBC::flattenAndCopyToInput(Vector<LevelData<FArrayBox>* >&  a_vectAMRData, 
                                           const Vector<RealVect>& a_amrDx,
                                           const string& a_dataName)
{
  int dataComp = getInputDataComp(a_dataName);
  RefCountedPtr<LevelData<FArrayBox> > dataLDFPtr = m_vectInputDataLDF[dataComp];
  RealVect dataDx = m_vectInputDataDx[dataComp];
      
  flattenCellData(*dataLDFPtr, dataDx,
                  a_vectAMRData, a_amrDx, 
                  m_verbose);

  dataLDFPtr->exchange();
  // now copy back to original storage for this data comp
  if (m_vectIsNodal[dataComp])
    {
      // have to average back to nodes
      FArrayBox& inputDataFAB = *m_vectInputData[dataComp];
      DataIterator dit= dataLDFPtr->dataIterator();
      for (dit.begin(); dit.ok(); ++dit)
        {
          const Box nodeBox = inputDataFAB.box();
          Box grownCCBox = nodeBox;
          grownCCBox.enclosedCells();
          grownCCBox.grow(1);
          
          FArrayBox ccGrownFAB(grownCCBox,1);
          ccGrownFAB.copy((*dataLDFPtr)[dit]);
          
          // Average Cells->Nodes 
          FORT_CELLTONODE(CHF_FRA1(inputDataFAB,0),
                          CHF_CONST_FRA1(ccGrownFAB,0),
                          CHF_BOX(nodeBox));
          
          // don't think I really need to do anything with 
          // ccInputData in this case
          
        } // end dataIterator "loop"
      
    } // end if nodal data
  else
    {
      // simple copy will do
      DataIterator dit= dataLDFPtr->dataIterator();
      const DisjointBoxLayout& grids = dataLDFPtr->getBoxes();
      for (dit.begin(); dit.ok(); ++dit)
        {
          
          Box intersectBox(grids[dit]);
          FArrayBox& ccInputData = *m_vectCCInputData[dataComp];
          intersectBox &= ccInputData.box();
          
          ccInputData.copy((*dataLDFPtr)[dit], intersectBox);
          
        } // end dataIterator "loop"
    }
}

  





#include "NamespaceFooter.H"
