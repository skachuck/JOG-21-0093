#ifdef CH_LANG_CC
/*
*      _______              __
*     / ___/ /  ___  __ _  / /  ___
*    / /__/ _ \/ _ \/  V \/ _ \/ _ \
*    \___/_//_/\___/_/_/_/_.__/\___/
*    Please refer to Copyright.txt, in Chombo's root directory.
*/
#endif

#include "SurfaceFlux.H"
#include "LevelDataSurfaceFlux.H"
#include "ISMIP6OceanForcing.H"
#include "GroundingLineLocalizedFlux.H"
#include "HotspotFlux.H"
#include "MarineIBC.H"
#ifdef HAVE_PYTHON
#include "PythonInterface.H"
#endif
#include "IceConstants.H"
#include "FineInterp.H"
#include "CoarseAverage.H"
#include "BisiclesF_F.H"
#include "ParmParse.H"
#include "AmrIce.H"
#include "FortranInterfaceIBC.H"
#include "FillFromReference.H"

#include "NamespaceHeader.H"

  /// factory method
  /** return a pointerto a new SurfaceFlux object
   */

SurfaceFlux* 
zeroFlux::new_surfaceFlux()
{
  zeroFlux* newPtr = new zeroFlux;
  return static_cast<SurfaceFlux*>(newPtr);
}

  /// define source term for thickness evolution and place it in flux
  /** dt is included in case one needs integrals or averages over a
      timestep
  */
void
zeroFlux::surfaceThicknessFlux(LevelData<FArrayBox>& a_flux,
			       const AmrIce& a_amrIce, 
			       int a_level, Real a_dt)
{
  DataIterator dit = a_flux.dataIterator();
  for (dit.begin(); dit.ok(); ++dit)
    {
      a_flux[dit].setVal(0.0);
    }
}


constantFlux::constantFlux() : m_isValSet(false)
{
}

SurfaceFlux* 
constantFlux::new_surfaceFlux()
{
  constantFlux* newPtr = new constantFlux;
  newPtr->m_fluxVal = m_fluxVal;
  newPtr->m_isValSet = m_isValSet;
  return static_cast<SurfaceFlux*>(newPtr);
}

  /// define source term for thickness evolution and place it in flux
  /** dt is included in case one needs integrals or averages over a
      timestep
  */
void
constantFlux::surfaceThicknessFlux(LevelData<FArrayBox>& a_flux,
				   const AmrIce& a_amrIce, 
				   int a_level, Real a_dt)
{
  CH_assert(m_isValSet);
  DataIterator dit = a_flux.dataIterator();
  for (dit.begin(); dit.ok(); ++dit)
    {
      a_flux[dit].setVal(m_fluxVal);
    }
}


///
void
constantFlux::setFluxVal(const Real& a_fluxVal) 
{
  m_fluxVal = a_fluxVal; 
  // input value is in meters/year divide by secondsperyear 
  // to get flux in meters/second
  // slc: switch to flux in m/a
  //m_fluxVal/= secondsperyear;
  
  m_isValSet = true;
}

constantTimeDepFlux::constantTimeDepFlux() : m_isValSet(false)
{
}

SurfaceFlux* 
constantTimeDepFlux::new_surfaceFlux()
{
  constantTimeDepFlux* newPtr = new constantTimeDepFlux;
  newPtr->m_fluxFactor = m_fluxFactor;
  newPtr->m_isValSet = m_isValSet;
  return static_cast<SurfaceFlux*>(newPtr);
}

  /// define source term for thickness evolution and place it in flux
  /** dt is included in case one needs integrals or averages over a
      timestep
  */
void
constantTimeDepFlux::surfaceThicknessFlux(LevelData<FArrayBox>& a_flux,
					  const AmrIce& a_amrIce, 
					  int a_level, Real a_dt)
{
  CH_assert(m_isValSet);
  Real time = a_amrIce.time();
  DataIterator dit = a_flux.dataIterator();
  for (dit.begin(); dit.ok(); ++dit)
    {
      a_flux[dit].setVal(time*m_fluxFactor);
    }
}


///
void
constantTimeDepFlux::setFluxFactor(const Real& a_fluxFactor) 
{
  m_fluxFactor = a_fluxFactor; 
  // input value is in meters/year divide by secondsperyear 
  // to get flux in meters/second
  // slc: switch to flux in m/a
  //m_fluxVal/= secondsperyear;
  
  m_isValSet = true;
}




// --------------------------------------------------------------
// fortran interface surface flux
// --------------------------------------------------------------

/// class which takes an input fortran array 
/** averages or interpolates as necessary to fill the flux
 */

/// constructor
fortranInterfaceFlux::fortranInterfaceFlux()
  : m_gridsSet(false), m_nodalFlux(false), m_scalingFactor(1.0), m_backgroundFlux(0.0), m_isValSet(false)
{
}

/// factory method
/** return a pointer to a new SurfaceFlux object
 */
SurfaceFlux* 
fortranInterfaceFlux::new_surfaceFlux()
{
  if (m_verbose)
    {
      pout() << "in fortranInterfaceFlux::new_surfaceFlux" << endl;
    }

  fortranInterfaceFlux* newPtr = new fortranInterfaceFlux;

  newPtr->m_grids = m_grids;
  newPtr->m_gridsSet = m_gridsSet;
  newPtr->m_backgroundFlux = m_backgroundFlux;
  newPtr->m_scalingFactor = m_scalingFactor;

    // keep these as aliases, if they're actually defined
  if (!m_inputFlux.box().isEmpty())
    {
      newPtr->m_inputFlux.define(m_inputFlux.box(), 
                                 m_inputFlux.nComp(),
                                 m_inputFlux.dataPtr());
    }

  if (!m_ccInputFlux.box().isEmpty())
    {
      newPtr->m_ccInputFlux.define(m_ccInputFlux.box(), 
                                   m_ccInputFlux.nComp(),
                                   m_ccInputFlux.dataPtr());
    }      
  
  newPtr->m_inputFluxLDF = m_inputFluxLDF;
  
  newPtr->m_fluxGhost = m_fluxGhost;
  newPtr->m_inputFluxDx = m_inputFluxDx;
  newPtr->m_grids = m_grids;
  newPtr->m_gridsSet = m_gridsSet;
  
  newPtr->m_verbose = m_verbose;

  newPtr->m_isValSet = m_isValSet;
  return static_cast<SurfaceFlux*>(newPtr);  
}

/// define source term for thickness evolution and place it in flux
/** dt is included in case one needs integrals or averages over a
    timestep. flux should be defined in meters/second in the current 
    implementation. 
*/
void 
fortranInterfaceFlux::surfaceThicknessFlux(LevelData<FArrayBox>& a_flux,
					   const AmrIce& a_amrIce, 
					   int a_level, Real a_dt)
{
  CH_assert(m_isValSet);

  // this looks a lot like the code in FortranInterfaceIBC

  DisjointBoxLayout levelGrids = m_grids;
  RealVect dx = a_amrIce.dx(a_level);

  // initialize to background value to handle case where BISICLES domain is 
  // larger than the CISM one
  
  DataIterator dit = a_flux.dataIterator();
  Real unscaled_background = m_backgroundFlux / m_scalingFactor;
  for (dit.begin(); dit.ok(); ++dit)
    {
      a_flux[dit].setVal(unscaled_background);
    }

  FillFromReference(a_flux,
                    *m_inputFluxLDF,
                    dx, m_inputFluxDx,
                    m_verbose);

  // finally, multiply by scalingFactor
  if (m_scalingFactor != 1.0)
    {
      DataIterator dit = a_flux.dataIterator();
      for (dit.begin(); dit.ok(); ++dit)
        {
          a_flux[dit] *= m_scalingFactor;
        }
    }
}

/// set fortran array-valued surface flux
void
fortranInterfaceFlux::setFluxVal(Real* a_data_ptr,
                                 const int* a_dimInfo,
                                 const int* a_boxlo, const int* a_boxhi, 
                                 const Real* a_dew, const Real* a_dns,
                                 const IntVect& a_offset,
                                 const IntVect& a_nGhost,
                                 const ProblemDomain& a_domain,
                                 const bool a_nodal)

{

  m_fluxGhost = a_nGhost;
  m_nodalFlux = a_nodal;
  m_domain = a_domain;

  // dimInfo is (SPACEDIM, nz, nx, ny)

  // assumption is that data_ptr is indexed using fortran 
  // ordering from (1:dimInfo[1])1,dimInfo[2])
  // we want to use c ordering
  //cout << "a_dimonfo" << a_dimInfo[0] << a_dimInfo[1] << endl;  

  if (m_verbose)
    {
      pout() << "In FortranInterfaceFlux::setFlux:" << endl;
      pout() << " -- entering setFAB..." << endl;
    }
  
  FortranInterfaceIBC::setFAB(a_data_ptr, a_dimInfo,a_boxlo, a_boxhi,
                              a_dew,a_dns,a_offset,a_nGhost,
                              m_inputFlux, m_ccInputFlux, a_nodal);

  if (m_verbose)
    {
      pout() << "... done" << endl;
    }

  // if we haven't already set the grids, do it now
  if (!gridsSet())
    {
      if (m_verbose) 
        {
          pout() << " -- entering setGrids" << endl;
        }
      Box gridBox(m_ccInputFlux.box());
      //gridBox.grow(-a_nGhost);
      FortranInterfaceIBC::setGrids(m_grids, gridBox, m_domain, a_nGhost, a_nodal, m_verbose);
      m_gridsSet = true;
      if (m_verbose)
        {
          pout() << " -- out of setGrids" << endl;
        }
    }
  


  m_inputFluxDx = RealVect(D_DECL(*a_dew, *a_dns, 1));

  // now define LevelData and copy from FAB->LevelData 
  // (at some point will likely change this to be an  aliased 
  // constructor for the LevelData, but this should be fine for now....
  
  // if nodal, we'd like at least one ghost cell for the LDF
  // (since we'll eventually have to average back to nodes)
  IntVect LDFghost = m_fluxGhost;
  if (a_nodal && (LDFghost[0] == 0))
    {
      LDFghost += IntVect::Unit;
    }
      
  RefCountedPtr<LevelData<FArrayBox> > localLDFPtr(new LevelData<FArrayBox>(m_grids, 1, LDFghost) );

  m_inputFluxLDF = localLDFPtr;
  // fundamental assumption that there is no more than one box/ processor 
  // don't do anything if there is no data on this processor
  DataIterator dit = m_grids.dataIterator();
  for (dit.begin(); dit.ok(); ++dit)
    {
      Box copyBox = (*m_inputFluxLDF)[dit].box();
      copyBox &= m_ccInputFlux.box();
      (*m_inputFluxLDF)[dit].copy(m_ccInputFlux, copyBox);
      
    } // end DataIterator loop

  m_isValSet = true;
}

// -------------  maskedFortranFlux ---------------------------------

/// constructor
maskedFortranFlux::maskedFortranFlux()
  : m_maskVal(FLOATINGMASKVAL)
{
  
}

  /// factory method
  /** return a pointer to a new SurfaceFlux object
   */
SurfaceFlux* 
maskedFortranFlux::new_surfaceFlux()
{
  if (m_verbose)
    {
      pout() << "in fortranInterfaceFlux::new_surfaceFlux" << endl;
    }
  
  maskedFortranFlux* newPtr = new maskedFortranFlux;
 
  newPtr->m_maskVal = m_maskVal;
  newPtr->m_grids = m_grids;
  newPtr->m_gridsSet = m_gridsSet;
  newPtr->m_backgroundFlux = m_backgroundFlux;
  newPtr->m_scalingFactor = m_scalingFactor;
  
  // keep these as aliases, if they're actually defined
  if (!m_inputFlux.box().isEmpty())
    {
      newPtr->m_inputFlux.define(m_inputFlux.box(), 
                                 m_inputFlux.nComp(),
                                 m_inputFlux.dataPtr());
    }
  
  if (!m_ccInputFlux.box().isEmpty())
    {
      newPtr->m_ccInputFlux.define(m_ccInputFlux.box(), 
                                   m_ccInputFlux.nComp(),
                                   m_ccInputFlux.dataPtr());
    }      
  
  newPtr->m_inputFluxLDF = m_inputFluxLDF;
  
  newPtr->m_fluxGhost = m_fluxGhost;
  newPtr->m_inputFluxDx = m_inputFluxDx;
  newPtr->m_grids = m_grids;
  newPtr->m_gridsSet = m_gridsSet;
  
  newPtr->m_verbose = m_verbose;
  
  newPtr->m_isValSet = m_isValSet;
  return static_cast<SurfaceFlux*>(newPtr);  
  
}

  /// define source term for thickness evolution and place it in flux
  /** dt is included in case one needs integrals or averages over a
      timestep. flux should be defined in meters/second in the current 
      implementation. 

      if level = 0, then redistribute flux to neigboring cells if no masked
      cells are present...
  */
void
maskedFortranFlux::surfaceThicknessFlux(LevelData<FArrayBox>& a_flux,
                                        const AmrIce& a_amrIce, 
                                        int a_level, Real a_dt)
{

  // if level = 0, do mask-based flux redistribution
  if (a_level == 0)
    {
      redistributeSrcFlux(a_amrIce);
    }

  // determine if this is a same-level copy, a coarsening, or an 
  // interpolation from the reference flux to finer levels
  Real destDx = a_amrIce.amrDx()[a_level];
  Real refRatio = m_inputFluxDx[0]/destDx;

  // tolerance used when converting refinement ratio from Real -> integer
  Real tolerance = 1.0e-6;

  // reality check
  Real testDx = destDx*refRatio;
  if (abs((long double)(testDx-m_inputFluxDx[0]))/m_inputFluxDx[0] > TINY_NORM)
    {
      MayDay::Error("maskedFortranFlux::incompatible src and dest dx");
    }
  
  // interpolation
  if (refRatio > 1.0 + tolerance)
    {
      MayDay::Error("maskedFortranFlux: interpolation not defined yet");
    }
  // averaging
  else if (refRatio < 1.0 - tolerance)
    {
      // this is easy, since we'll never coarsen into a completely empty cell
      RealVect destDxVect = destDx*RealVect::Unit;
      FillFromReference(a_flux, *m_redistributedFluxLDF, 
                        destDxVect, m_inputFluxDx,
                        m_verbose);
    }
  else
    {
      // same-size copy
      m_redistributedFluxLDF->copyTo(m_redistributedFluxLDF->interval(),
                                     a_flux, a_flux.interval());
    }

      
}


// this function redistributes flux from masked-out cells into neighboring 
// active cells
void
maskedFortranFlux::redistributeSrcFlux(const AmrIce& a_amrIce)
{
  /// first define mask on AMR heirarchy based on specified mask value
  const Vector<RefCountedPtr<LevelSigmaCS> >& amrGeom = a_amrIce.amrGeometry();

  m_amrMask.resize(amrGeom.size());

  for (int lev=0; lev<m_amrMask.size(); lev++)
    {
      const LevelData<BaseFab<int> > & levelMask = amrGeom[lev]->getFloatingMask();
      const DisjointBoxLayout& levelGrids = levelMask.getBoxes();
      IntVect maskGhost = IntVect::Unit;
      if (m_amrMask[lev] != NULL)
        {
          delete m_amrMask[lev];
        }
      m_amrMask[lev] = new LevelData<FArrayBox>(levelGrids,1,maskGhost);

      DataIterator dit = levelMask.dataIterator();
      for (dit.begin(); dit.ok(); ++dit)
        {
          FArrayBox& newMaskFab = (*m_amrMask[lev])[dit];
          newMaskFab.setVal(0.0);
          const BaseFab<int>& thisSrcMask = levelMask[dit];
          // note that this will include ghost cells
          BoxIterator bit(newMaskFab.box());
          for (bit.begin(); bit.ok(); ++bit)
            {
              IntVect iv = bit();
              if (thisSrcMask(iv,0) == m_maskVal)
                {
                  newMaskFab(iv,0) = 1.0;
                }
            } // end loop over cells in this box
        } // end loop over grids on this level
    } // end loop over levels

  // we now have a new mask defined on the AMR hierarchy and which is 1.0
  // where the original mask has the desired value, and 0 elsewhere

  // now we flatten to the source resolution
  const Vector<Real> amrDx = a_amrIce.amrDx();
  Vector<RealVect> amrDxVect(amrDx.size(),RealVect::Zero);
  for (int lev=0; lev<amrDx.size(); lev++)
    {
      amrDxVect[lev] = amrDx[lev]*RealVect::Unit;
    }

  bool verbose = true;
  // define this with an extra layer of ghost cells to consistently 
  // handle the case where a cell which needs to be redistributed lives on a 
  // box boundary
  LevelData<FArrayBox> flattenedMask(m_inputFluxLDF->getBoxes(),1,
                                     2*IntVect::Unit);

  // note that this also averages fine-level masks onto covered regions, which 
  // we will also need...
  flattenCellData(flattenedMask,
                  m_inputFluxDx,
                  m_amrMask,
                  amrDxVect,
                  verbose);
  
  flattenedMask.exchange();

  // we now have a mask, defined on the src-data resolution, which ranges
  // between 0 and 1. Values between 0 and 1 are the fractional amount that 
  // each reference-level cell has maskVal on the finest levels.

  // next step is to search through original src data and redistribute 
  // where mask is zero but src is not.
  Real zeroTol = 1.0e-6;
  m_inputFluxLDF->copyTo(*m_redistributedFluxLDF);
  
  int searchRad = 1;
  Box searchBox(-searchRad*IntVect::Unit,searchRad*IntVect::Unit);
  IntVectSet searchNeighborhood(searchBox);
  // remove (0,0) to produce ring around src cell
  searchNeighborhood -= IntVect::Zero;

  DataIterator dit = m_redistributedFluxLDF->dataIterator();
  for (dit.begin(); dit.ok(); ++dit)
    {
      FArrayBox& thisFlux = m_redistributedFluxLDF->operator[](dit);
      FArrayBox& thisMask = flattenedMask[dit];
      
      // iterate over box grown by one to ensure we catch the
      const Box&  gridBox = flattenedMask.getBoxes()[dit];
      Box grownGridBox(gridBox);
      grownGridBox.grow(1);

      BoxIterator grownBit(grownGridBox);
      for (grownBit.begin(); grownBit.ok(); ++grownBit)
        {
          IntVect iv = grownBit();
          // check for case where mask is zero but flux isn't
          if ( (thisMask(iv,0) < zeroTol) && (thisFlux(iv,0) > zeroTol) )
            {

              if (verbose)
                {
                  pout() << "...redistributing flux from cell "
                         << iv << endl;
                }
              
              // search one-cell neighborhood and count up 
              // neighboring cells in which the mask is not zero
              Vector<IntVect> neighbors;
              IVSIterator ivsIt(searchNeighborhood);
              for (ivsIt.begin(); ivsIt.ok(); ++ivsIt)
                {
                  IntVect neighborLoc = ivsIt();
                  neighborLoc += iv;
                  // first check to see if neighbor cell is in domain
                  if (thisMask.box().contains(neighborLoc))
                    {
                      if (thisMask(neighborLoc,0) > zeroTol)
                        {
                          neighbors.push_back(neighborLoc);
                        }
                    }
                  
                } // end loop over neighborhood search

              
              if (neighbors.size() > 0) 
                {
                  Real fluxPerCell = thisFlux(iv,0);
                  fluxPerCell /= neighbors.size();

                  for (int i=0; i<neighbors.size(); i++)
                    {
                      thisFlux(neighbors[i],0) += fluxPerCell;
                    }
                  thisFlux(iv,0) = 0.0;
                  
                } // end if we found neighbors
              else
                {
                  // no neighbors were found! need to increase search radius
                  // will come back and revisit this if necessary
                  MayDay::Error("no neighbor cells found");
                }
            } // end if mask is zero and flux is nonzero
                   
        } // end loop over cells
    } // end loop over boxes
}

  


 /// constructor
MaskedFlux::MaskedFlux(SurfaceFlux* a_groundedIceFlux, SurfaceFlux* a_floatingIceFlux,
		       SurfaceFlux* a_openSeaFlux, SurfaceFlux* a_openLandFlux)
  :m_groundedIceFlux(a_groundedIceFlux),m_floatingIceFlux(a_floatingIceFlux),
   m_openSeaFlux(a_openSeaFlux),m_openLandFlux(a_openLandFlux)
{
  CH_assert(a_groundedIceFlux);
  CH_assert(a_floatingIceFlux);
  CH_assert(a_openSeaFlux);
  CH_assert(a_openLandFlux);
}
/// factory method
/** return a pointer to a new SurfaceFlux object
 */
SurfaceFlux* MaskedFlux::new_surfaceFlux()
{
  SurfaceFlux* f = m_floatingIceFlux->new_surfaceFlux();
  SurfaceFlux* g = m_groundedIceFlux->new_surfaceFlux();
  SurfaceFlux* s = m_openSeaFlux->new_surfaceFlux();
  SurfaceFlux* l = m_openLandFlux->new_surfaceFlux();
  return static_cast<SurfaceFlux*>(new MaskedFlux(g,f,s,l));
}

void MaskedFlux::surfaceThicknessFlux(LevelData<FArrayBox>& a_flux,
				      const AmrIce& a_amrIce, 
				      int a_level, Real a_dt)
{

  //somewhat ineffcient, because we compute all fluxes everywhere. 
  //At some point, come back and only compute (say) grounded ice flux
  //in boxes where all the ice is grounded.

  //first, grounded ice values
  if (m_groundedIceFlux)
    m_groundedIceFlux->surfaceThicknessFlux(a_flux,a_amrIce,a_level,a_dt);

  //floating ice values
  LevelData<FArrayBox> floatingFlux;
  floatingFlux.define(a_flux);

  if (m_floatingIceFlux)
    m_floatingIceFlux->surfaceThicknessFlux(floatingFlux, a_amrIce,a_level,a_dt);

  for (DataIterator dit(a_flux.dataIterator()); dit.ok(); ++dit)
    {
      const BaseFab<int>& mask =  a_amrIce.geometry(a_level)->getFloatingMask()[dit];
      
      Box box = mask.box();
      box &= a_flux[dit].box();

      int m = FLOATINGMASKVAL;
      FORT_MASKEDREPLACE(CHF_FRA1(a_flux[dit],0),
			 CHF_CONST_FRA1(floatingFlux[dit],0),
			 CHF_CONST_FIA1(mask,0),
			 CHF_CONST_INT(m),
			 CHF_BOX(box));

      
      m = OPENSEAMASKVAL;
      FORT_MASKEDREPLACE(CHF_FRA1(a_flux[dit],0),
			 CHF_CONST_FRA1(floatingFlux[dit],0),
			 CHF_CONST_FIA1(mask,0),
			 CHF_CONST_INT(m),
			 CHF_BOX(box));

    }

}

SurfaceFlux* AxbyFlux::new_surfaceFlux()
{
  return static_cast<SurfaceFlux*>(new AxbyFlux(m_a, m_x,m_b, m_y) );
}

AxbyFlux::AxbyFlux(const Real& a_a, SurfaceFlux* a_x, 
		   const Real& a_b, SurfaceFlux* a_y)
{

  m_a = a_a;
  m_b = a_b;
  
  CH_assert(a_x != NULL);
  CH_assert(a_y != NULL);
  m_x = a_x->new_surfaceFlux();
  m_y = a_y->new_surfaceFlux();
  CH_assert(m_x != NULL);
  CH_assert(m_y != NULL);

}

AxbyFlux::~AxbyFlux()
{
  if (m_x != NULL)
    {
      delete m_x; m_x = NULL;
    }
  if (m_y != NULL)
    {
      delete m_y; m_y = NULL;
    }
}

void AxbyFlux::surfaceThicknessFlux(LevelData<FArrayBox>& a_flux,
					  const AmrIce& a_amrIce, 
					  int a_level, Real a_dt)
{

  LevelData<FArrayBox> y_flux(a_flux.disjointBoxLayout(),1,a_flux.ghostVect());
  m_x->surfaceThicknessFlux(a_flux, a_amrIce, a_level,a_dt );
  m_y->surfaceThicknessFlux(y_flux, a_amrIce, a_level,a_dt );
  for (DataIterator dit(a_flux.disjointBoxLayout()); dit.ok(); ++dit)
    {
      a_flux[dit].axby(a_flux[dit],y_flux[dit],m_a,m_b);
    }
  

}


/// factory method
/** return a pointer to a new SurfaceFlux object
 */
SurfaceFlux* CompositeFlux::new_surfaceFlux()
{
  return static_cast<SurfaceFlux*>(new CompositeFlux(m_fluxes));
}

CompositeFlux::CompositeFlux(const Vector<SurfaceFlux*>& a_fluxes)
{
  m_fluxes.resize(a_fluxes.size());
  for (int i =0; i < a_fluxes.size(); i++)
    {
      CH_assert(a_fluxes[i] != NULL);
      m_fluxes[i] =  a_fluxes[i]->new_surfaceFlux();
    }
}

CompositeFlux::~CompositeFlux()
{
  for (int i =0; i < m_fluxes.size(); i++)
    {
      if (m_fluxes[i] != NULL)
	{
	  delete m_fluxes[i];
	  m_fluxes[i] = NULL;
	}
    }
}

void CompositeFlux::surfaceThicknessFlux(LevelData<FArrayBox>& a_flux,
					  const AmrIce& a_amrIce, 
					  int a_level, Real a_dt)
{
  m_fluxes[0]->surfaceThicknessFlux(a_flux, a_amrIce, a_level,a_dt );

  // this is hardly effcient... but it is convenient
  LevelData<FArrayBox> tmpFlux(a_flux.disjointBoxLayout(),1,a_flux.ghostVect());
  for (int i = 1; i <  m_fluxes.size(); i++)
    {
      m_fluxes[i]->surfaceThicknessFlux(tmpFlux, a_amrIce, a_level,a_dt );
      for (DataIterator dit(a_flux.disjointBoxLayout()); dit.ok(); ++dit)
	{
	  a_flux[dit] += tmpFlux[dit];
	}
    }

}



SurfaceFlux* BoxBoundedFlux::new_surfaceFlux()
{
  return static_cast<SurfaceFlux*>( new BoxBoundedFlux(m_lo, m_hi,m_startTime,m_endTime,m_fluxPtr));
}


void BoxBoundedFlux::surfaceThicknessFlux(LevelData<FArrayBox>& a_flux,
					  const AmrIce& a_amrIce, 
					  int a_level, Real a_dt)
{

  Real time = a_amrIce.time();
  

  for (DataIterator dit(a_flux.disjointBoxLayout()); dit.ok(); ++dit)
    {
      a_flux[dit].setVal(0.0);
    }

  if (time >= m_startTime && time < m_endTime)
    {
      // this is hardly efficient... but it is convenient
      LevelData<FArrayBox> tmpFlux(a_flux.disjointBoxLayout(),1,a_flux.ghostVect());
      m_fluxPtr->surfaceThicknessFlux(tmpFlux, a_amrIce, a_level,a_dt);
      const RealVect& dx = a_amrIce.dx(a_level);
      
      IntVect ilo,ihi;
      for (int dir =0; dir < SpaceDim; dir++)
	{
	  ilo[dir] = int(m_lo[dir]/dx[dir] - 0.5);
	  ihi[dir] = int(m_hi[dir]/dx[dir] - 0.5);
	}
      
    
      for (DataIterator dit(a_flux.disjointBoxLayout()); dit.ok(); ++dit)
	{
	  const Box& b = a_flux[dit].box();
	  if (b.intersects(Box(ilo,ihi)))
	    { 
	      Box sub(max(b.smallEnd(),ilo), min(b.bigEnd(),ihi));
	      a_flux[dit].plus(tmpFlux[dit],sub,0,0,1);
	    }
	}
    }

}

PiecewiseLinearFlux::PiecewiseLinearFlux(const Vector<Real>& a_abscissae, 
					 const Vector<Real>& a_ordinates, 
					 Real a_minWaterDepth)
  :m_abscissae(a_abscissae),m_ordinates(a_ordinates),
   m_minWaterDepth(a_minWaterDepth)
{
  CH_assert(m_abscissae.size() == m_ordinates.size());
}


SurfaceFlux* PiecewiseLinearFlux::new_surfaceFlux()
{
  return static_cast<SurfaceFlux*>(new PiecewiseLinearFlux(m_abscissae,m_ordinates,m_minWaterDepth));
}

void PiecewiseLinearFlux::surfaceThicknessFlux(LevelData<FArrayBox>& a_flux,
					       const AmrIce& a_amrIce, 
					       int a_level, Real a_dt)
{
  Vector<Real> dx(m_abscissae.size());
  Vector<Real> db(m_abscissae.size());

  const LevelData<FArrayBox>& levelH = a_amrIce.geometry(a_level)->getH();
  const LevelData<FArrayBox>& levelS = a_amrIce.geometry(a_level)->getSurfaceHeight();
  const LevelData<FArrayBox>& levelR = a_amrIce.geometry(a_level)->getTopography();
  for (DataIterator dit(a_flux.dataIterator()); dit.ok(); ++dit)
    {

      FORT_PWLFILL(CHF_FRA1(a_flux[dit],0),
		   CHF_CONST_FRA1(levelH[dit],0),
		   CHF_CONST_VR(m_abscissae),
		   CHF_CONST_VR(m_ordinates),
		   CHF_VR(dx),CHF_VR(db),
		   CHF_BOX(a_flux[dit].box()));
       
      if (m_minWaterDepth > 0.0)
	{
	  
	  FArrayBox D(a_flux[dit].box(),1);
	  FORT_WATERDEPTH(CHF_FRA1(D,0),
			  CHF_CONST_FRA1(levelH[dit],0),
			  CHF_CONST_FRA1(levelS[dit],0),
			  CHF_CONST_FRA1(levelR[dit],0),
			  CHF_BOX(a_flux[dit].box()));
  
	  
	  FORT_ZEROIFLESS(CHF_FRA1(a_flux[dit],0),
			  CHF_CONST_FRA1(D,0),
			  CHF_CONST_REAL(m_minWaterDepth),
			  CHF_BOX(a_flux[dit].box()));

	}

    }
}


SurfaceFlux* SurfaceFlux::parseSurfaceFlux(const char* a_prefix)
{
  
  SurfaceFlux* ptr = NULL;
  std::string type = "";
  
  ParmParse pp(a_prefix);
  pp.query("type",type);
  
  if (type == "zeroFlux")
    {
      ptr = new zeroFlux;
    }
  else if (type == "constantFlux")
    {
      constantFlux* constFluxPtr = new constantFlux;
      Real fluxVal;
      pp.get("flux_value", fluxVal);
      constFluxPtr->setFluxVal(fluxVal);
      ptr = static_cast<SurfaceFlux*>(constFluxPtr);
    }
  else if (type == "hotspotFlux")
    {
      HotspotFlux* hotspotFluxPtr = new HotspotFlux;
      Real fluxVal;
      pp.get("flux_value", fluxVal);
      hotspotFluxPtr->setFluxVal(fluxVal);
      Vector<Real> vect(SpaceDim,0.0);

      pp.getarr("radius",vect,0,SpaceDim);
      RealVect radius(D_DECL(vect[0], vect[1],vect[2]));      

      pp.getarr("center",vect,0,SpaceDim);
      RealVect center(D_DECL(vect[0], vect[1],vect[2]));

      hotspotFluxPtr->setSpotLoc(radius, center);
      
      Real startTime = -1.2345e300;
      Real stopTime = 1.2345e300;
      pp.query("start_time", startTime);
      pp.query("stop_time", stopTime);
      hotspotFluxPtr->setSpotTimes(startTime, stopTime);
      
      ptr = static_cast<SurfaceFlux*>(hotspotFluxPtr);
    }
  else if (type == "deRydtFlux")
    {
      deRydtSurfaceFlux* newFluxPtr = new deRydtSurfaceFlux();
      ptr = static_cast<SurfaceFlux*>(newFluxPtr);
    }
  else if (type == "constantTimeDepFlux")
    {
      constantTimeDepFlux* newFluxPtr;
      newFluxPtr = new constantTimeDepFlux;
      Real fluxVal;
      pp.get("flux_factor", fluxVal);
      newFluxPtr->setFluxFactor(fluxVal);
      ptr = static_cast<SurfaceFlux*>(newFluxPtr);
    }
  else if (type == "LevelData")
    {
      std::string fileFormat;
      pp.get("fileFormat",fileFormat);
      int n;
      pp.get("n",n);
      int offset = 0;
      pp.query("offset",offset);

      Real startTime = 0.0, timeStep = 1.0;
      pp.query("startTime", startTime);
      pp.query("timeStep", timeStep);
      std::string name = "flux";
      pp.query("name", name);
      	
      RefCountedPtr<std::map<Real,std::string> > tf
	(new std::map<Real,std::string>);
      
      for (int i =0; i < n; i++)
	{
	  char* file = new char[fileFormat.length()+32];
	  sprintf(file, fileFormat.c_str(),i + offset);
	  tf->insert(make_pair(startTime + Real(i)*timeStep, file));
	  delete file;
	}
      
      LevelDataSurfaceFlux* ldptr = new LevelDataSurfaceFlux(tf,name);
      ptr = static_cast<SurfaceFlux*>(ldptr);
    }
  else if (type == "fortran")
    {
      // don't have the context here to actually set values, but
      // we can at least allocate the object here and return it 
      fortranInterfaceFlux* fifptr = new fortranInterfaceFlux;

      // background flux value in case fortran domain is smaller 
      // than BISICLES domain
      Real backgroundFlux = 0.0;
      pp.query("backgroundFlux", backgroundFlux);
      fifptr->setBackgroundFlux(backgroundFlux);

      ptr = static_cast<SurfaceFlux*>(fifptr);
    }
  else if (type == "piecewiseLinearFlux")
    {
      int n = 1;  
      pp.query("n",n);
      Vector<Real> vabs(n,0.0);
      Vector<Real> vord(n,0.0);
      pp.getarr("abscissae",vabs,0,n);
      pp.getarr("ordinates",vord,0,n);
      
      Real dmin = -1.0;
      pp.query("minWaterDepth",dmin);
      
      PiecewiseLinearFlux* pptr = new PiecewiseLinearFlux(vabs,vord,dmin);
      ptr = static_cast<SurfaceFlux*>(pptr);
    }
  else if (type == "maskedFlux")
    {
      std::string groundedPrefix(a_prefix);
      groundedPrefix += ".grounded";
      SurfaceFlux* groundedPtr = parseSurfaceFlux(groundedPrefix.c_str());
      if (groundedPtr == NULL)
	{
	  groundedPtr = new zeroFlux;
	}
 
      std::string floatingPrefix(a_prefix);
      floatingPrefix += ".floating";
      SurfaceFlux* floatingPtr = parseSurfaceFlux(floatingPrefix.c_str());
      if (floatingPtr == NULL)
	{
	  floatingPtr = new zeroFlux;
	}

      std::string openLandPrefix(a_prefix);
      openLandPrefix += ".openLand";
      SurfaceFlux* openLandPtr = parseSurfaceFlux(openLandPrefix.c_str());
      if (openLandPtr == NULL)
	{
	  openLandPtr = new zeroFlux;
	}

      
      std::string openSeaPrefix(a_prefix);
      openSeaPrefix += ".openSea";
      SurfaceFlux* openSeaPtr = parseSurfaceFlux(openSeaPrefix.c_str());
      if (openSeaPtr == NULL)
	{
	  openSeaPtr = new zeroFlux;
	}

      ptr = static_cast<SurfaceFlux*>
	(new MaskedFlux(groundedPtr->new_surfaceFlux(),
			floatingPtr->new_surfaceFlux(),
			openSeaPtr->new_surfaceFlux(),
			openLandPtr->new_surfaceFlux()));
      
      delete groundedPtr;
      delete floatingPtr;
      delete openSeaPtr;
      delete openLandPtr;
    }
  else if (type == "boxBoundedFlux")
    {
      Vector<Real> tmp(SpaceDim); 
      pp.getarr("lo",tmp,0,SpaceDim);
      RealVect lo (D_DECL(tmp[0], tmp[1],tmp[2]));
      pp.getarr("hi",tmp,0,SpaceDim);
      RealVect hi (D_DECL(tmp[0], tmp[1],tmp[2]));

      Vector<Real> time(2);
      time[0] = -1.2345678e+300;
      time[1] = 1.2345678e+300;
      pp.queryarr("time",time,0,2);
           
      std::string prefix(a_prefix);
      prefix += ".flux";
      SurfaceFlux* fluxPtr = parseSurfaceFlux(prefix.c_str());

      BoxBoundedFlux bbf(lo,hi,time[0],time[1],fluxPtr);
      ptr = static_cast<SurfaceFlux*>(bbf.new_surfaceFlux());

    }
  else if (type == "axbyFlux")
   {
     Real a; 
     pp.get("a",a);
     
     std::string xpre(a_prefix);
     xpre += ".x";
     SurfaceFlux* x = parseSurfaceFlux(xpre.c_str());
     
     Real b; 
     pp.get("b",b);
     
     std::string ypre(a_prefix);
     ypre += ".y";
     SurfaceFlux* y = parseSurfaceFlux(ypre.c_str());
    
     AxbyFlux axbyFlux(a,x,b,y);
     ptr = static_cast<SurfaceFlux*>(axbyFlux.new_surfaceFlux());

   }
  else if (type == "compositeFlux")
   {
     
     
     int nElements;
     pp.get("nElements",nElements);
     
     std::string elementPrefix(a_prefix);
     elementPrefix += ".element";

     Vector<SurfaceFlux*> elements(nElements);
     for (int i = 0; i < nElements; i++)
       {
	 std::string prefix(elementPrefix);
	 char s[32];
	 sprintf(s,"%i",i);
	 prefix += s;
	 ParmParse pe(prefix.c_str());
	 elements[i] = parseSurfaceFlux(prefix.c_str());
	 CH_assert(elements[i] != NULL);
	 
       }
     CompositeFlux compositeFlux(elements);
     ptr = static_cast<SurfaceFlux*>(compositeFlux.new_surfaceFlux());
   
   }
  else if (type == "groundingLineLocalizedFlux")
    {
      Real powerOfThickness = 0.0;
      pp.query("powerOfThickness",powerOfThickness);

      std::string glPrefix(a_prefix);
      glPrefix += ".groundingLine";
      SurfaceFlux* glPtr = parseSurfaceFlux(glPrefix.c_str());
      if (glPtr == NULL)
	{
	  glPtr = new zeroFlux;
	}
       
      std::string ambientPrefix(a_prefix);
      ambientPrefix += ".ambient";
      SurfaceFlux* ambientPtr = parseSurfaceFlux(ambientPrefix.c_str());
      if (ambientPtr == NULL)
	{
	  ambientPtr = new zeroFlux;
	}
      
      ptr = static_cast<SurfaceFlux*>
	(new GroundingLineLocalizedFlux(glPtr->new_surfaceFlux(),
					ambientPtr->new_surfaceFlux(),
					powerOfThickness ));
	 
      delete glPtr;
      delete ambientPtr;

    }
  else if (type == "IMSIP6OceanForcing")
    {
      ptr = new ISMIP6OceanForcing(pp);
    }
#ifdef HAVE_PYTHON
  else if (type == "pythonFlux") {
    
    std::string module;
    pp.get("module",module);
    std::string function;
    pp.get("function",function);
    PythonInterface::PythonSurfaceFlux pythonFlux(module, function);
    ptr = static_cast<SurfaceFlux*>(pythonFlux.new_surfaceFlux());

  }
#endif
  return ptr;
  
}


#ifdef HAVE_PYTHON
#include "signal.h"


#endif
#include "NamespaceFooter.H"
