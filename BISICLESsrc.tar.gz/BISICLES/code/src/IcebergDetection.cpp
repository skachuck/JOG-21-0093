/*
 * readAMRPlots.cpp
 *
 *  Created on: May 19, 2014
 *      Author: xczou
 */

#include "IcebergDetection.H"
#include <sys/types.h>
#include <unistd.h>
#include "IceConstants.H"
#include <sstream>
#include "NamespaceHeader.H"

#ifdef CH_MPI

int IcebergDetection::ICE_GROUNDED = GROUNDEDMASKVAL;
int IcebergDetection::ICE_FLOATING = FLOATINGMASKVAL;
int IcebergDetection::ICE_OPENSEA = OPENSEAMASKVAL;
int IcebergDetection::ICE_OPENLAND = OPENLANDMASKVAL;

/*
 *  Patch logic view :                 (highPtr)
 *          |  .....................  |
 *          |  .....................  |
 *          |  .........up..........  |
 *          |  ..left.|cell|.right..  |
 *          |  ........down.........  |
 *  lowPtr  |  .....................  |
 */
IcebergDetection::IcebergDetection() {
	int sweepDir = 0;
	int sign = 1; // +1 or -1 depending on sweep direction
	rightShiftV = sign*BASISV(sweepDir); // => (1, 0 )
	sign = -1;
	leftShiftV = sign*BASISV(sweepDir); // => (-1, 0 )
	sweepDir = 1;
	sign = -1 ;
	downShiftV = sign*BASISV(sweepDir); // => (0, -1 )
	sign = 1;
	upShiftV = sign*BASISV(sweepDir); // => (0, 1 )
	varName= "thickness";
	thresholdVal = 1.0;
}



IcebergDetection::~IcebergDetection() {
}

void IcebergDetection::setVarName(string name){
	varName = name;
}
void IcebergDetection::setThresholdVal(Real t){
	thresholdVal = t;
}

string IcebergDetection::getVarName(){
	return varName ;
}
Real IcebergDetection::getThresholdVal(){
	return thresholdVal ;
}

// Find the minimal value starting @arg ind.
inline int afind(const std::vector<int>& equiv, const int ind) {
	int ret = ind;
	while (equiv[ret] < ret)
		ret = equiv[ret];
	return ret;
} // afind

// Set the values starting with @arg ind.
inline void aset(std::vector<int>& equiv, const int ind, const int val) {
	int i = ind;
	while (equiv[i] < i) {
		int j = equiv[i];
		equiv[i] = val;
		i = j;
	}
	equiv[i] = val;
} // aset

//assume the size of eq is divisible by 2
inline void printEquivLabel(std::set<std::pair<int, int> > &eq) {
	std::set<std::pair<int, int> >::iterator it;
	for (it = eq.begin(); it != eq.end(); ++it) {
		pout() << "(" << (*it).first << ", " << (*it).second << ")";
	}
	pout() << endl;
}

inline void printLabelVec(std::vector<int>& equiv) {
	pout() << "parent array : ";
	for (unsigned i = 0; i < equiv.size(); ++i) {
		pout() << equiv[i] << ",";
	}
	pout() << endl;
}


void IcebergDetection::updateLocalLabelToUniqueLabel(
		DisjointBoxLayout &levelPatch, LevelData<FArrayBox>& levelLabel,
		std::vector<int> & uniqLabelVec, int labelOffset) {
	CH_TIME("PCCL-Main:11:updateLocalLabelToUniqueLabel");

	DataIterator patchItr = levelLabel.dataIterator();
	for (patchItr.begin(); patchItr.ok(); ++patchItr) {
		FArrayBox& patchLabel = levelLabel[patchItr];
		//		Box patchBox = patchLabel.box();
		Box patchBox = levelPatch[patchItr]; // only update the valid region
		BoxIterator cellItr(patchBox); // iterator of cells
		IntVect size = patchBox.size();
		IntVect lowPtr = patchBox.smallEnd(); // this is a starting point/cell of this patch
		IntVect highPtr = patchBox.bigEnd(); // this is an ending point/cell of this patch
		IntVect currentPtr = lowPtr;
		int column = size[0]; // column = 48 - 23 + 1 = 26
		int row = size[1]; // row = 64 - 31 + 1 = 34
		if (!patchBox.isEmpty()) { // patch is not empty
			for (int r = 0; r < row; r++) {
				for (int c = 0; c < column; c++) {
					if (patchLabel(currentPtr) > 0) {
						// update label on cells
						// for the second pass, assigning the final label, we dont have the root of label to assign
						patchLabel(currentPtr) = uniqLabelVec[patchLabel(currentPtr) - labelOffset];

					}
					currentPtr = currentPtr+ rightShiftV ; // move to right

				}
				currentPtr.setVal(0, lowPtr[0]);//reset to original value at first dimension direction
				currentPtr = currentPtr + upShiftV; // move up
			}
		}
	}
}

void IcebergDetection::updateLocalLabel(DisjointBoxLayout &levelPatch,
		LevelData<FArrayBox>& levelLabel, int labelOffset) {
	CH_TIME("PCCL-Main:3:updateLocalLabel");
	DataIterator patchItr = levelLabel.dataIterator();
	for (patchItr.begin(); patchItr.ok(); ++patchItr) {
		FArrayBox& patchLabel = levelLabel[patchItr];
		Box patchBox = patchLabel.box();
		BoxIterator cellItr(patchBox); // iterator of cells
		IntVect size = patchBox.size();
		IntVect lowPtr = patchBox.smallEnd(); // this is a starting point/cell of this patch
		IntVect highPtr = patchBox.bigEnd(); // this is an ending point/cell of this patch
		IntVect currentPtr = lowPtr;
		int column = size[0]; // column = 48 - 23 + 1 = 26
		int row = size[1]; // row = 64 - 31 + 1 = 34
		if (!patchBox.isEmpty()) { // patch is not empty
			for (int r = 0; r < row; r++) {
				for (int c = 0; c < column; c++) {
					if (patchLabel(currentPtr) > 0) // only update foreground cells
						patchLabel(currentPtr) += labelOffset;
					currentPtr = currentPtr+ rightShiftV ; // move to right
				}
				currentPtr.setVal(0, lowPtr[0]);//reset to original value at first dimension direction
				currentPtr = currentPtr + upShiftV; // move up
			}
		}
	}
}

int IcebergDetection::inspectCommSizeOnGhostCells(
		DisjointBoxLayout & levelPatch, LevelData<FArrayBox> & levelLabel,
		IntVect & ghostVect, string methodName, int lev, int labelLow, int labelHigh) {
	DataIterator patchItr = levelLabel.dataIterator();
	int numData = 0;
	for (patchItr.begin(); patchItr.ok(); ++patchItr) {
		FArrayBox& patchLabel = levelLabel[patchItr];
		Box region = patchLabel.box(); // including ghost cells
		IntVect lowPtr = region.smallEnd();
		IntVect highPtr = region.bigEnd();
		IntVect size = region.size(); // two dimensional size, from this, we have column & row
		int columns = size[0]; // in x-direction
		int rows = size[1]; // in y-direction

		//******left to right (bottom side)***************/
		IntVect currentPtr = lowPtr;
		for (int c = 0; c < columns; c++) {
			if (!(patchLabel(currentPtr) < labelLow ||
					patchLabel(currentPtr) > labelHigh))
				numData ++;
			currentPtr += rightShiftV; // move toward right direction
		}
		currentPtr += leftShiftV;// back up one step

		//******bottom to up (right side) ***************/
		for (int r = 0; r < rows; r++) {
			if (!(patchLabel(currentPtr) < labelLow ||
								patchLabel(currentPtr) > labelHigh))
				numData ++;
			currentPtr += upShiftV;  // moves up
		}
		currentPtr += downShiftV; // back up one step

		//******left to right (top side) ***************/
		for (int c = 0; c < columns; c++) { // moving from left to right
			if (!(patchLabel(currentPtr) < labelLow ||
								patchLabel(currentPtr) > labelHigh))
				numData ++;
			currentPtr += leftShiftV; // move left
		}
		currentPtr += rightShiftV;

		//******up to bottom (left side) ***************/
		for (int r = 0; r < rows; r++) {
			if (!(patchLabel(currentPtr) < labelLow ||
								patchLabel(currentPtr) > labelHigh))
				numData ++;
			currentPtr += downShiftV; // move down
		}

	}

}



/*
 * labelUBNum: the upper bound label numbers
 * levelLabel: labels of one layer
 * levelThickness: thickness value
 * threshold: thickness threshold value
 * NOTE: DOES NOT INCLUDE GHOST CELLS, since ghost cells would connect the disconnected component via some detouring
 */
void IcebergDetection::CCLonLocalPatches( DisjointBoxLayout &levelLayout,
		LevelData<FArrayBox>& levelLabel, LevelData<FArrayBox>& levelThickness,
		Real threshold, int lev,
		std::vector<int> &equiv/*OUT*/) {

	DataIterator patchItr = levelThickness.dataIterator();

	// equivalence array for every level
	unsigned patchNextLabel = 1, leftL, topL; // leftR, topR; // starting label
	// initialize equivalence array
	equiv.reserve(50);
	equiv.push_back(0);

	int patchCount = 0;
	// scan through every patch on this level
	for (patchItr.begin(); patchItr.ok(); ++patchItr) {

		patchCount++;
		const FArrayBox& thickDataFab = levelThickness[patchItr];

		FArrayBox& patchLabel = levelLabel[patchItr]; //patch label recording the label of each cell in the patch
		patchLabel.setVal(0); // all cells are marked as 0 initially

//		Box patchBox = thickDataFab.box(); // include the ghost cells
		Box patchBox = levelLayout[patchItr]; // EXCLUDE the ghost cells
		BoxIterator cellItr(patchBox); // iterator of cells

		//We want to know the number of cells in this patch
		//	long cellNums = levelGrids[patchItr].numPts();  // the numPtrs return the "VALID" cell number
		//We also want to know the cell dimension of this patch: number of rows and number of columns
		//If mesh is structured, we can use row and column to access the neighbor cells
		//However, if mesh is structured, how do we access the the neighbor cells? using the graph representation?
		IntVect size = patchBox.size(); // two dimensional size, from this, we have column & row
		// The logic view of original sauf algorithm defines the horizontal direction is column, and vertical direction is row
		//   -------------------------------------------> column
		//   |                                            (48,64)
		//   |
		//  \ /(23,31)
		//  row
		int column = size[0]; // column = 48 - 23 + 1 = 26
		int row = size[1]; // row = 64 - 31 + 1 = 34
		long totalCellNums = row * column; // = valid cells + ghost cells
		// the valid cell region is wrapped with `ghostV(i)` cells in each direction

		IntVect lowPtr = patchBox.smallEnd(); // this is a starting point/cell of this patch
		IntVect highPtr = patchBox.bigEnd(); // this is an ending point/cell of this patch
		IntVect currentPtr = lowPtr;


		// we are marking all cells, including ghost cells
		if (!patchBox.isEmpty()) { // patch is not empty
			//******first cell of first row**********//
			if (thickDataFab(currentPtr) > threshold) { // its object cell
				patchLabel(currentPtr) = patchNextLabel;
				equiv.push_back(patchNextLabel);
				patchNextLabel++;
			}
			currentPtr = currentPtr+ rightShiftV;  // move to next cell

			//******cells on first row, except the first one**********//
			for (int moves = 1; moves < column; moves++) {
				if (thickDataFab(currentPtr) > threshold) { // its object cell
					if (patchLabel(currentPtr + leftShiftV) > 0) { // left object cell is marked as some labels
						// current cell follows the label on the left cell
						patchLabel(currentPtr) = patchLabel(
								currentPtr + leftShiftV);
					} else { // current cell has a new label
						patchLabel(currentPtr) = patchNextLabel;
						equiv.push_back(patchNextLabel);
						patchNextLabel++;
					}
				}
				currentPtr = currentPtr+ rightShiftV; // moves toward to right on x-axis,keeping on y-axis

			}

			//******cells on rows starting from second row **********//
			//TODO: topDelta => down cell??
			IntVect tmpPtr;
			currentPtr = lowPtr; // reset currentPtr to origin (starting point)
			for (int j = column; j < totalCellNums; j += column) {
				currentPtr = currentPtr + upShiftV;  // moving toward to top; currentPtr now points to cells at first column

				// cells at first column**********//
				// these cells do not have left cell, it only needs to check the cell that is below to current cell
				if (thickDataFab(currentPtr) > threshold) {
					if (patchLabel(currentPtr + downShiftV) > 0) { // top object cell is marked as some labels
						// current cell follows the label on the top cell
						patchLabel(currentPtr) = patchLabel(
								currentPtr + downShiftV);
					} else { // current cell has a new label
						patchLabel(currentPtr) = patchNextLabel;
						equiv.push_back(patchNextLabel);
						patchNextLabel++;
					}
				}
				tmpPtr = currentPtr;


				//******rest cells **********//
				// these cells have left & top cells

				for (int i = j + 1; i < j + column; ++i) {
					tmpPtr = tmpPtr + rightShiftV ; // move to right
					// TODO: will use decision tree. but at this point, use the straightforward way

					if (thickDataFab(tmpPtr) > threshold) { // current cell must be object cell
						// Does the left(west) cell has the same value as the current cell
						if (thickDataFab(tmpPtr + leftShiftV) > threshold) {
							// assign current label with label from left
							patchLabel(tmpPtr) = patchLabel(tmpPtr + leftShiftV);
						}

						//Do both cells to the top(North) and left(West) of the current pixel have the same value as the current pixel
						//but not the same label?
						if ((thickDataFab(tmpPtr + leftShiftV) > threshold
								&& thickDataFab(tmpPtr + downShiftV) > threshold) // they are same value
								&& patchLabel(tmpPtr + leftShiftV)
										!= patchLabel(tmpPtr + downShiftV) // they have different labels
						) {

							//We know that the North and West pixels belong to the same region and must be merged.
							//Assign the current pixel the minimum of the North and West labels, and record their equivalence relationship
							leftL = patchLabel(tmpPtr + leftShiftV);
							topL = patchLabel(tmpPtr + downShiftV);

							patchLabel(tmpPtr)
									= doMergeLabels(equiv, leftL, topL);

						}

						//Does the pixel to the left (West) have a different value and the one to the North the same value as the current pixel?
						if ((thickDataFab(tmpPtr + leftShiftV) <= threshold
								&& thickDataFab(tmpPtr + downShiftV) > threshold)) {
							//assigning label of current cell with label of north cell
							patchLabel(tmpPtr) = patchLabel(tmpPtr + downShiftV);
						}

						//Do the pixel's North and West neighbors have different pixel values than current pixel?
						if (thickDataFab(tmpPtr + downShiftV) <= threshold
								&& thickDataFab(tmpPtr + leftShiftV)
										<= threshold) {
							//Create a new label id and assign it to the current pixel
							patchLabel(tmpPtr) = patchNextLabel;
							equiv.push_back(patchNextLabel);
							patchNextLabel++;
						}
					}

				}

			}

		} // end of one patch

	} // end of "for (patchItr.begin(); patchItr.ok(); ++patchItr)"

}



/*
 * after exchange function, we reset labels on ghost cells.
 * This is for distinguishing the ghost labels that are updated by fillInterp function
 */
void IcebergDetection::clearLabelsOnGhostCells(
		DisjointBoxLayout & levelPatch, LevelData<FArrayBox> & levelLabel,
		IntVect & ghostVect, int lev) {
	CH_TIME("PCCL-Main:12:clearLabelsOnGhostCells");
	// for each patch, walking around the ghost cells,
	// and set the label to 0,
	// its okay this walking-through algorithm touches twice on four corner cells
	DataIterator patchItr = levelLabel.dataIterator();
	for (patchItr.begin(); patchItr.ok(); ++patchItr) {
		FArrayBox& patchLabel = levelLabel[patchItr];
		Box region = patchLabel.box(); // including ghost cells
		IntVect lowPtr = region.smallEnd();
		IntVect highPtr = region.bigEnd();
		IntVect size = region.size(); // two dimensional size, from this, we have column & row
		int columns = size[0]; // in x-direction
		int rows = size[1]; // in y-direction

		//******left to right (bottom side)***************/
		IntVect currentPtr = lowPtr;
		for (int c = 0; c < columns; c++) {
			patchLabel(currentPtr) = 0;
			currentPtr += rightShiftV; // move toward right direction
		}
		currentPtr += leftShiftV;// back up one step

		//******bottom to up (right side) ***************/
		for (int r = 0; r < rows; r++) {
			patchLabel(currentPtr) = 0;
			currentPtr += upShiftV;  // moves up
		}
		currentPtr += downShiftV; // back up one step

		//******left to right (top side) ***************/
		for (int c = 0; c < columns; c++) { // moving from left to right
			patchLabel(currentPtr) = 0;
			currentPtr += leftShiftV; // move left
		}
		currentPtr += rightShiftV;

		//******up to bottom (left side) ***************/
		for (int r = 0; r < rows; r++) {
			patchLabel(currentPtr) = 0;
			currentPtr += downShiftV; // move down
		}

	}
}

/*only for debugging */
void IcebergDetection::mpiGdbDebug(){
	int wait = 1;
	cout << getpid() << endl;
	while(wait) {
		sleep(2);
	}
}

void IcebergDetection::insertOneEquivPair(int curLabel, int ghostLabel, bool includeSameLabel, std::set<std::pair<int,int> > & labelEquiv)
{
    if(curLabel > 0 && ghostLabel > 0){
        // only ghost cell & current cell are labeled
        if(includeSameLabel){
            labelEquiv.insert(std::make_pair(curLabel, ghostLabel));
        }else{
            if(curLabel != ghostLabel){
                // we have label equivalence
                labelEquiv.insert(std::make_pair(curLabel, ghostLabel));
            }
        }

    }

}

/*
 *
 * I currently use a simple structure, an 1-D array, assuming the number of equivalent label pair is half of the array size
 * Walking on the boundary path of a patch and collect the label equivalence info.
 * "includeSameLabel" is a flag that indicates where the pair such as ( 2 , 2) should included into output,
 *  for same level's label equivalence collection, we dont need to include them.
 *  whereas, for collecting label equivalence across multiple levels, we need to include them
 *  For the returning set of pairs, such as ( <1,34> <3,5> ... )
 *    the first element in the pair stands for the label on the local valid region,
 *    the second element in the pair stands for the label on the ghost region
 */
void IcebergDetection::collectLabelEquivPair(DisjointBoxLayout &levelLayout,
		LevelData<FArrayBox>& levelLabel, IntVect &ghostVect,
		std::set<std::pair<int, int> > &localLabelEquiv/*OUT*/, int lev, bool includeSameLabel) {

	CH_TIME("PCCL-Main:6:collectLabelEquivalence");
	DataIterator patchItr = levelLabel.dataIterator();
	int patchCount = 0;
	for (patchItr.begin(); patchItr.ok(); ++patchItr) {
		patchCount++;
		FArrayBox& patchLabel = levelLabel[patchItr];
//		Box region = patchLabel.box(); // including ghost cells
		Box validRegion = levelLayout[patchItr]; // excluding ghost cells
		IntVect lowPtr = validRegion.smallEnd();
		IntVect size = validRegion.size(); // two dimensional size, from this, we have column & row
		int columns = size[0]; // in x-direction
		int rows = size[1]; // in y-direction

		// walk down on the south bound
		IntVect currentPtr = lowPtr;
		// Cells that on the four corners, they need to check two neighbor cells
		// Thats why following for-loop all starts with 0

		//******left to right (bottom side), looking at one cell (i,j-1) below current cell ***************/
		int ghostLabel , curLabel ;
		for (int c = 0; c < columns; c++) {
			//comparing the label
			ghostLabel = patchLabel(currentPtr + downShiftV);
			curLabel = patchLabel(currentPtr);
			insertOneEquivPair(curLabel, ghostLabel, includeSameLabel, localLabelEquiv);
			currentPtr += rightShiftV ; // move toward right direction
		}
		currentPtr += leftShiftV; // back up one step

		//******bottom to up (right side), looking at right cell (i+1,j) ***************/
		for (int r = 0; r < rows; r++) { // currentPtr has accessed the corner cell, needs to decrease one here
			ghostLabel = patchLabel(currentPtr + rightShiftV);
			curLabel =   patchLabel(currentPtr);
			insertOneEquivPair(curLabel, ghostLabel, includeSameLabel, localLabelEquiv);
			currentPtr += upShiftV ;// moves up
		}
		currentPtr += downShiftV ;

		//******left to right (top side), looking at top cell (i,j+1)  ***************/
		for (int c = 0; c < columns; c++) { // moving from left to right
			ghostLabel =  patchLabel(currentPtr + upShiftV);
			curLabel =   patchLabel(currentPtr);
			insertOneEquivPair(curLabel, ghostLabel, includeSameLabel, localLabelEquiv);
			currentPtr += leftShiftV;
		}
		currentPtr += rightShiftV;

		//******up to bottom (left side), looking at left cell (i-1,j)  ***************/
		for (int r = 0; r < rows; r++) { // the left bound has 2 cells already been accessed
			ghostLabel = patchLabel(currentPtr + leftShiftV);
			curLabel = patchLabel(currentPtr);
			insertOneEquivPair(curLabel, ghostLabel, includeSameLabel, localLabelEquiv);
			currentPtr += downShiftV;
		}

	}
}

void IcebergDetection::convertArrayToVector(std::vector<int> & vec,
		int * arr, int & size) {
	vec.reserve(size + 1); // 0 at the first possible takes the extra one
	vec.push_back(0);
	vec.insert(vec.end(), arr, arr + size);
}



/*
 * merge parents of both label by using the minimum of two parents
 * return the minimum parent label
 */
int IcebergDetection::doMergeLabels(std::vector<int> & globalLabelVec, int l1,
		int l2) {
	int r1, r2;
	r1 = afind(globalLabelVec, l1);
	r2 = afind(globalLabelVec, l2);

	if (r1 > r2)
		r1 = r2;

	aset(globalLabelVec, l1, r1);
	aset(globalLabelVec, l2, r1);
	return r1;
}


void IcebergDetection::aggLabelEquivPair(
		std::set<std::pair<int, int> > labelEquiv, int groupLeader,
		MPI_Comm & groupComm,
		std::set<std::pair<int, int> > & globalLabelEquiv /*OUTPUT, on group leader*/, int lev) {

	CH_TIME("PCCL-Main:7:aggLabelEquiv");

	int grouprank = 0, aggTotalElm = 0;
	MPI_Comm_rank(groupComm, &grouprank);
	int *glabel2;
	//convert set<pair> to array so that we can transfer it
	int equivSize = labelEquiv.size() * 2;
	int *labelEquivArray = new int[equivSize];
	int li = 0;
	std::set<std::pair<int, int> >::iterator it;
	for (it = labelEquiv.begin(); it != labelEquiv.end(); ++it) {
		labelEquivArray[li++] = (*it).first;
		labelEquivArray[li++] = (*it).second;
	}
	CH_assert(li == equivSize);
	aggregationToGroupLeader(groupLeader, equivSize, labelEquivArray, groupComm, glabel2, aggTotalElm);

	//TODO: this stupid CompareByPair is not able to eliminate the duplicates ( same equivalence pair: (1,3) = (3,1) )
//So, we currently keep this way since it does not affect the final array
//TODO: since we aggregate this label equiv. from group member, on which the equiv. info. would be duplicated, the group leader would have less number of paris than the sum number of pairs
	if (grouprank == groupLeader) {
		for (int j = 0; j < aggTotalElm; j += 2) {
			globalLabelEquiv.insert(std::make_pair(glabel2[j], glabel2[j + 1]));
		}
		delete[] glabel2;
	}
	delete[] labelEquivArray;


}

void IcebergDetection::createPatchGroup(DisjointBoxLayout & levelLayout,
		MPI_Comm *patchComm) {
	Vector<int> procs = levelLayout.procIDs(); // a group of processors have patches at this level
	// procs contains duplicate processor ID, which causes an error for the MPI_Group_incl
	// I have to remove the duplicates, and to do so, I can not use the `unique` function since the Vector type does not match type required from `unique`
	// a temporal & awkward solution is to convert this sturcture to set, and convert back to vector
	std::set<int> uniqProcsSet;
	for (int i = 0; i < procs.size(); i++) {
		uniqProcsSet.insert(procs[i]);
	}
	std::vector<int> uniqProcs(uniqProcsSet.size());
	uniqProcs.assign(uniqProcsSet.begin(), uniqProcsSet.end());
	MPI_Group commGroup, patchGroup;
	/* Extract the original group handle */
	MPI_Comm_group(MPI_COMM_WORLD, &commGroup);
	MPI_Group_incl(commGroup, uniqProcs.size(), &uniqProcs[0], &patchGroup);
	MPI_Comm_create(MPI_COMM_WORLD, patchGroup, patchComm);
}

void IcebergDetection::propagateGroundness(int numAMRLevel,
		std::vector<set<std::pair<int, int> > *> & amrLabelEquiv,
		std::vector<std::vector<int> *> &groundness /*IN&OUT*/) {

	for (int lev = amrLabelEquiv.size() - 1; lev >= 0; lev--) {
		int amrLevel = lev + 1;
		std::set<std::pair<int, int> > *labelEquivs = amrLabelEquiv[lev]; // amrLabelEquiv is has less than one layer
		std::set<std::pair<int, int> >::iterator it;
		for (it = (*labelEquivs).begin(); it != (*labelEquivs).end(); ++it) {
			// start with building the equivalent label chain
			std::vector<int> chain(numAMRLevel, 0);
			std::pair<int, int> p = *it;
			int lidx = amrLevel;
			chain[lidx--] = p.first;
			chain[lidx--] = p.second;
			//propagate this change to next level
			int plabel = p.second;
			bool keepPropagate = true;
			int nextLevel = lev - 1;

			while (keepPropagate && nextLevel >= 0) {
				std::set<std::pair<int, int> > *le = amrLabelEquiv[nextLevel];
				std::set<std::pair<int, int> >::iterator it2;
				bool found = false;
				for (it2 = (*le).begin(); it2 != (*le).end(); ++it2) {
					if ((*it2).first == plabel) {
						plabel = (*it2).second;
						chain[lidx--] = plabel;
						nextLevel--;
						found = true;
						break;
					}
				}

				if (!found) {
					keepPropagate = false;
				} else {
					(*le).erase(it2);
				}
			}

			// search any label has "grounded" in the groundness
			int isGrounded = IcebergDetection::ICE_FLOATING;
			for (int l = 0; l < chain.size(); l++) {
				int label = chain[l];
				if (label > 0) {
					std::vector<int> * levelg = groundness[l];
					if ((*levelg)[label] == IcebergDetection::ICE_GROUNDED) {
						isGrounded = IcebergDetection::ICE_GROUNDED;
						break;
					}
				}
			}
			//found "grounded" in the chain, we should update the groundness of labels in the chain
			if (isGrounded == IcebergDetection::ICE_GROUNDED) {
				for (int l = 0; l < chain.size(); l++) {
					int label = chain[l];
					if (label > 0) {
						std::vector<int> * levelg = groundness[l];
						(*levelg)[label] = IcebergDetection::ICE_GROUNDED;
					}

				}
			}

		}

	}

}

std::vector<int> IcebergDetection::collectGroundnessOfLabeledComponent(
		int uniqLevelLabelNum, LevelData<FArrayBox> & levelLabel,
		const LevelData<BaseFab<int> > & levelMask, DisjointBoxLayout & levelLayout) {

	// the label starts with 0, the groundness contains the groundness info even for label 0, but we don't use it
	std::vector<int> groundess(uniqLevelLabelNum,
			IcebergDetection::ICE_FLOATING);
	// once groundCount is decreased down to 0, it means all components are grounded, so we dont continue our search
	int groundCount = uniqLevelLabelNum - 1; // excluding label 0
	int patchCount = 0;
	DataIterator patchItr = levelLayout.dataIterator();
	for (patchItr.begin(); patchItr.ok(); ++patchItr) {
		patchCount ++;
		FArrayBox & patchLabel = levelLabel[patchItr];
		const BaseFab<int> & patchMask = levelMask[patchItr];
		Box patchBox = levelLayout[patchItr]; // only update the valid region
		BoxIterator cellItr(patchBox); // iterator of cells
		IntVect size = patchBox.size();
		IntVect lowPtr = patchBox.smallEnd(); // this is a starting point/cell of this patch
		//				IntVect highPtr = patchBox.bigEnd(); // this is an ending point/cell of this patch
		IntVect currentPtr = lowPtr;
		int column = size[0]; // column = 48 - 23 + 1 = 26
		int row = size[1]; // row = 64 - 31 + 1 = 34
		if (!patchBox.isEmpty()) {

			for (int r = 0; r < row && (groundCount >= 0); r++) {
				for (int c = 0; c < column && (groundCount >= 0); c++) {
					if (patchLabel(currentPtr) > 0
							&& groundess[patchLabel(currentPtr)] == IcebergDetection::ICE_FLOATING
							&& patchMask(currentPtr) == IcebergDetection::ICE_GROUNDED) {
							groundess[patchLabel(currentPtr)]  = IcebergDetection::ICE_GROUNDED;
							groundCount--;
					}
					currentPtr = currentPtr+ rightShiftV;
				}

				currentPtr.setVal(0, lowPtr[0]); //reset to original value at first dimension direction
				currentPtr = currentPtr + upShiftV;
			}
		}

	}

	return groundess;

}



void IcebergDetection::aggGroundness(
		std::vector < int> &localGroundness, int groupLeader, MPI_Comm & groupComm,
		std::vector<int> & aggGroundness/* only exist on groupLeader */){
		int groupRank;
		MPI_Comm_rank(groupComm, &groupRank);
		int aggTotalElm = 0;
		int *sendLabel = &localGroundness[1];
		int * outbuf ;
		aggregationToGroupLeader(groupLeader, localGroundness.size() -1 ,
				sendLabel, groupComm, outbuf, aggTotalElm );

		if (groupRank == groupLeader) {

			aggGroundness.reserve(aggTotalElm + 1); // 0 at the first possible takes the extra one
			aggGroundness.push_back(IcebergDetection::ICE_FLOATING);
			aggGroundness.insert(aggGroundness.end(), outbuf, outbuf + aggTotalElm);

			delete[] outbuf;
		}
}



void IcebergDetection::aggParentArray(
		std::vector<int> labelVec,	int groupLeader, MPI_Comm & groupComm,
		std::vector<int> & aggLabelVec/* only exist on groupLeader */, int lev ){

		CH_TIME("PCCL-Main:4:aggParentArray");

		int groupRank;
		MPI_Comm_rank(groupComm, &groupRank);
		int aggTotalElm = 0;
		int *sendLabel = &labelVec[1];
		int * recvBuf ;
		aggregationToGroupLeader(groupLeader, labelVec.size() -1 ,
				sendLabel, groupComm, recvBuf, aggTotalElm );

		if (groupRank == groupLeader) {
			convertArrayToVector(aggLabelVec, recvBuf, aggTotalElm);
			delete[] recvBuf;
		}
}

/*
 * OUT data exists only on group leader processor
 */
void IcebergDetection::aggregationToGroupLeader(int groupLeader, int transferSize
		 ,int *aggreInputBuf, MPI_Comm groupComm
		 ,int *& aggreOutputBuf /*OUT*/
		 ,int & totalAggreElms  /*OUT*/) {
	int * disp, *rcounts;
	int groupRank, groupSize;
	MPI_Comm_rank(groupComm, &groupRank);
	MPI_Comm_size(groupComm, &groupSize);
	int *recvBuf;

	// collect size of data transferring on each processor
	if (groupRank == groupLeader) {
		recvBuf = new int[groupSize];
	}

	MPI_Gather(&transferSize, 1, MPI_INT, recvBuf, 1, MPI_INT, groupLeader, groupComm);
	if (groupRank == groupLeader) {
		disp = new int[groupSize];
		rcounts = new int[groupSize];
		disp[0] = 0;
		rcounts[0] = recvBuf[0];
		totalAggreElms = rcounts[0];
		for (int r = 1; r < groupSize; r++) {
			rcounts[r] = recvBuf[r];
			disp[r] = disp[r - 1] + recvBuf[r - 1]; // displace is equal to rcounts, there is no gap between data
			totalAggreElms += rcounts[r];
		}
		aggreOutputBuf = new int[totalAggreElms];
	}
	/*
	 * int MPI_Gatherv(const void *sendbuf, int sendcount, MPI_Datatype sendtype,
	 void *recvbuf, const int *recvcounts, const int *displs,
	 MPI_Datatype recvtype, int root, MPI_Comm comm)
	 */
	MPI_Gatherv(aggreInputBuf, transferSize, MPI_INT, aggreOutputBuf, rcounts,
			disp, MPI_INT, groupLeader, groupComm);

	if (groupRank == groupLeader){
		delete [] recvBuf;
		delete [] disp;
		delete [] rcounts;
	}
}

void IcebergDetection::flattenParrentArray(
		std::vector<int> & GLLabelVec /*IN & OUT*/, int & uniqLevelLabelNum/*OUT*/) {
	uniqLevelLabelNum = 0;
    const int nequiv = GLLabelVec.size();
//        pout() << "====Size of label equivalence (before flattening) on group leader of level-computing group is : " << nequiv << endl;
        //============= Flatten Array ===================//
        for(int l = 0;l < nequiv;++l){
            if(GLLabelVec[l] < l){
                // chase one more time
                GLLabelVec[l] = GLLabelVec[GLLabelVec[l]];
            }else{
                // change to the next smallest unused label
                GLLabelVec[l] = uniqLevelLabelNum;
                // ensure this is the unique label number
                ++uniqLevelLabelNum;
            }
     }

}
void IcebergDetection::processParrenArrayOnLeader(
		  std::set<std::pair<int,int> > *GLLabelEquivPair
		, std::vector<int> & GLLabelVec /*IN & OUT*/, int & uniqLevelLabelNum/*OUT*/)
{
		CH_TIME("PCCL-Main:8:processParrenArrayOnLeader");
        //*********** go through the equivalent label pair, and compress the label array ***********/

		mergeLabel(GLLabelEquivPair, GLLabelVec);
		flattenParrentArray(GLLabelVec, uniqLevelLabelNum);
        // after label compression, I will send the label number to the root processor
        // The number of labels are not needed, as we dont have relabeling across multiple levels
        /*int LN = globalLabelVec.size() - 1; // excluding label 0
				 MPI_Request req;
				 MPI_Isend(&LN, 1, MPI_INT, root, maxLabelTag, MPI_COMM_WORLD,
				 &req);*/

}

/*
 * disseminate aggLabelVec to each processor in the group
 * each process will have uniLabelVec
 */
void IcebergDetection::disseminateUniqueLabel(int groupLeader
		, int localLabelNum
		, std::vector<int> aggLabelVec, MPI_Comm & groupComm
		, std::vector<int> & uniqLabelVec /*OUT*/, int lev)
{

    int *sendBuf, *uniqL, * disp, *rcounts, *recvBuf;
	int groupRank, groupSize;
	MPI_Comm_rank(groupComm, &groupRank);
	MPI_Comm_size(groupComm, &groupSize);

//	int transferSize = aggLabelVec.size() - 1; // skip the first 0 label
	int transferSize = localLabelNum;
	// collect size of data transferring on each processor
	if (groupRank == groupLeader) {
		recvBuf = new int[groupSize];
	}

	MPI_Gather(&transferSize, 1, MPI_INT, recvBuf, 1, MPI_INT, groupLeader, groupComm);


	if (groupRank == groupLeader) {
		disp = new int[groupSize];
		rcounts = new int[groupSize];
		disp[0] = 0;
		rcounts[0] = recvBuf[0];
		for (int r = 1; r < groupSize; r++) {
			rcounts[r] = recvBuf[r];
			disp[r] = disp[r - 1] + recvBuf[r - 1]; // displace is equal to rcounts, there is no gap between data
		}

        sendBuf = &aggLabelVec[1]; // skip the first 0 label
    }

    uniqL = new int[localLabelNum];
    /*int MPI_Scatterv(const void *sendbuf, const int *sendcounts, const int *displs,
	 MPI_Datatype sendtype, void *recvbuf, int recvcount,
	 MPI_Datatype recvtype,
	 int root, MPI_Comm comm)*/
    MPI_Scatterv(sendBuf, rcounts, disp, MPI_INT, uniqL, localLabelNum, MPI_INT,
					groupLeader, groupComm);


    convertArrayToVector(uniqLabelVec, uniqL, localLabelNum);

    if ( groupRank == groupLeader){
    	delete [] recvBuf;
    	delete [] disp;
    	delete [] rcounts;
    }

    delete [] uniqL;

}

/*
 * make a level-wise view of the groundness, each process has its own view of groundness
 * this function unions the groundness view
 * There is a assumption thta each local groundness has same size, so the GLgroudness is
 * label number:  0  1  2  3
 * Processor 0:   G, N  G  N
 * processor 1:   N, G  N  N
 * output     :   G, G  G  N
 */
void IcebergDetection::unionGroundnessOnLeader(int groupLeader, MPI_Comm groupComm
		, std::vector<int> & localGroundness , std::vector<int> &GLGroundness)
{
	CH_TIME("PCCL-Main:14:unionGroundnessOnLeader");

    //collected to group leader
    // the non-optimized has one advantage, the size of groundness is same on every processor within this group
	int groupRank, groupSize;
	MPI_Comm_rank(groupComm, &groupRank);
	MPI_Comm_size(groupComm, &groupSize);

    int *rbuf2;
    if(groupRank == groupLeader){
        rbuf2 = new int[groupSize * localGroundness.size()];
    }
    /*
     * int MPI_Gather(const void *sendbuf, int sendcount, MPI_Datatype sendtype,
               void *recvbuf, int recvcount, MPI_Datatype recvtype,
               int root, MPI_Comm comm)
     */
    MPI_Gather(&localGroundness[0], localGroundness.size(), MPI_INT, rbuf2,
    		localGroundness.size(), MPI_INT, groupLeader, groupComm);
    // I collected the groundness info., I have to merge them,
    // any label that is marked as grounded will be finally marked as grounded
    if(groupRank == groupLeader){
        GLGroundness = std::vector<int> (localGroundness.size(), IcebergDetection::ICE_FLOATING);

        for(int j = 0;j < localGroundness.size();j++){
            for(int p = 0;p < groupSize;p++){
                if(rbuf2[p * localGroundness.size() + j] == IcebergDetection::ICE_GROUNDED){
                	GLGroundness[j] = IcebergDetection::ICE_GROUNDED;
                    break;
                }
            }

        }

    }

    if(groupRank == groupLeader){
        delete [] rbuf2;
    }
}

void IcebergDetection::GLSendRank( int rank , int lev , int recvRank, int tag){

	int buf[2] = {lev, rank}; // global rank of the group leader at level `lev`
	MPI_Send(buf, 2, MPI_INT, recvRank, tag, MPI_COMM_WORLD);
}

void IcebergDetection::rootRecvGLRank(std::vector<int> & globalGroupLeaders, int tag){
	int recvBuf[2] = {-1,-1};
	MPI_Status status;
	MPI_Recv(recvBuf, 2, MPI_INT, MPI_ANY_SOURCE, tag, MPI_COMM_WORLD, &status);
//	int lev = recvBuf[0];
	globalGroupLeaders[recvBuf[0]] = recvBuf[1];
}


/**
 * similar to GLsendGroundnessToRoot,
 * | senderRank | lev | vector data |
 */
void IcebergDetection::sendVectorLevelData(int senderRank, std::vector<int> &data,
		int lev, int dest, int dataSizeTag, int dataTag) {
		CH_TIME("PCCL-Main:15:sendVectorData");

		// at the beginning, insert the level info., which is precaution step,
		data.insert(data.begin(), lev);
		data.insert(data.begin(), senderRank);

		MPI_Request req1; //, req2;
		int sendSize = data.size();

		int * sendbuf = new int[sendSize];
		std::copy(data.begin(), data.end(),sendbuf);
		/*
		 * Can not use MPI_Send or MPI_wait after MPI_Isend,
		 * it will cause deadlock if there the groupleader is the root processor
		 * in which the MPI_Send or MPI_Wait is waiting for receiver (root) to complete receive,
		 * but receiver is waiting for MPI_Send to finish to start MPI_Irecv
		 */
		MPI_Isend(&sendSize, 1, MPI_INT, dest, dataSizeTag,
						MPI_COMM_WORLD, &req1);
		/*int *sendbuf = &groundness[0];
		MPI_Isend(sendbuf, sendSize, MPI_INT, root, rootRecv2ndTag,
				MPI_COMM_WORLD, &req2);*/

		//TODO consider switch to Isend
		MPI_Send(sendbuf, sendSize, MPI_INT, dest, dataTag,
				MPI_COMM_WORLD);
		delete [] sendbuf;
}

void IcebergDetection::sendArrayData(int senderRank, int *data, int size
			,int lev, int dest, int dataSizeTag, int dataTag) {
	MPI_Request req1 , req2;
	MPI_Isend(&size, 1, MPI_INT, dest, dataSizeTag,
							MPI_COMM_WORLD, &req1);
	MPI_Isend(data, size, MPI_INT, dest, dataSizeTag,
				MPI_COMM_WORLD, &req2);
}

int * IcebergDetection::recvArrayData(int dataSizeTag, int dataTag, int&recvSize ){
	recvSize = 0;
	MPI_Status mpiStatus, s2;
	MPI_Request request =MPI_REQUEST_NULL, rq2 = MPI_REQUEST_NULL;
	MPI_Irecv(&recvSize, 1, MPI_INT, MPI_ANY_SOURCE, dataSizeTag,
			MPI_COMM_WORLD, &request);
	MPI_Wait(&request, &mpiStatus);
	int *recvBuf = new int[recvSize];
	MPI_Irecv(recvBuf, recvSize, MPI_INT, MPI_ANY_SOURCE,
			dataTag, MPI_COMM_WORLD, &rq2);
	return recvBuf;
}

std::vector<int> * IcebergDetection::recvVectorLevelData( int dataSizeTag, int dataTag, int &recvLev, int &senderRank)
{

		// The number of labels are not needed, as we dont have relabeling across multiple levels
		/*	int recvLabelNum;
		 MPI_Status mpiStatus;
		 MPI_Recv(&recvLabelNum, 1, MPI_INT, MPI_ANY_SOURCE, maxLabelTag,
		 MPI_COMM_WORLD, &mpiStatus); */

		//recv groundness from every level group leader
		int recvSize = 0;
		MPI_Status mpiStatus, s2;
		MPI_Request request =MPI_REQUEST_NULL, rq2 = MPI_REQUEST_NULL;
		MPI_Irecv(&recvSize, 1, MPI_INT, MPI_ANY_SOURCE, dataSizeTag,
				MPI_COMM_WORLD, &request);
		MPI_Wait(&request, &mpiStatus);

		int *recvBuf = new int[recvSize];
		MPI_Irecv(recvBuf, recvSize, MPI_INT, MPI_ANY_SOURCE,
				dataTag, MPI_COMM_WORLD, &rq2);
		MPI_Wait(&rq2, &s2);

		senderRank = recvBuf[0]; // first number is sender's rank
		recvLev = recvBuf[1];  // second number is  the level number
		// new vector [first, end)
		std::vector<int> * recvVec = new vector<int> (recvBuf + 2,
				recvBuf + recvSize );
		delete[ ] recvBuf;
		return recvVec;
}


void IcebergDetection::GLsendGroundnessToRoot( std::vector<int> &groundness,
		int lev, int root, int rootRecv1stTag, int rootRecv2ndTag)
{
			// at the beginning, insert the level info., which is precaution step,
			// in case the groundness info. does not arrive group leader in the level increasing order
			groundness.insert(groundness.begin(), lev);

			//aggregate to root processor
			// The groundness could have varied size once we do the optimization,
			// So, we adapt a generic communication way

			MPI_Request req1; //, req2;
			int sendSize = groundness.size();
			int * sendbuf = new int[sendSize];
			std::copy(groundness.begin(), groundness.end(),sendbuf);
			/*
			 * Can not use MPI_Send or MPI_wait after MPI_Isend,
			 * it will cause deadlock if there the groupleader is the root processor
			 * in which the MPI_Send or MPI_Wait is waiting for receiver (root) to complete receive,
			 * but receiver is waiting for MPI_Send to finish to start MPI_Irecv
			 */
			MPI_Isend(&sendSize, 1, MPI_INT, root, rootRecv1stTag,
							MPI_COMM_WORLD, &req1);
			/*int *sendbuf = &groundness[0];
			MPI_Isend(sendbuf, sendSize, MPI_INT, root, rootRecv2ndTag,
					MPI_COMM_WORLD, &req2);*/
			MPI_Send(sendbuf, sendSize, MPI_INT, root, rootRecv2ndTag,
					MPI_COMM_WORLD);

			delete [] sendbuf;

}

void IcebergDetection::rootRecvGroundness( int rootRecv1stTag, int rootRecv2ndTag, std::vector<std::vector<int> *> & groundness)
{

	//TODO: as we may not need relabeling the label on each level,
    // we dont need to have this, will remove it later

			//	mpiGdbDebug();
			//recv groundness from every level group leader
				int recvSize = 0;
				MPI_Status mpiStatus, s2;
				MPI_Request request =MPI_REQUEST_NULL, rq2 = MPI_REQUEST_NULL;
				MPI_Irecv(&recvSize, 1, MPI_INT, MPI_ANY_SOURCE, rootRecv1stTag,
						MPI_COMM_WORLD, &request);
				MPI_Wait(&request, &mpiStatus);

				int *recvBuf = new int[recvSize];
				MPI_Irecv(recvBuf, recvSize, MPI_INT, MPI_ANY_SOURCE,
						rootRecv2ndTag, MPI_COMM_WORLD, &rq2);
				MPI_Wait(&rq2, &s2);

				int recvLev = recvBuf[0]; // first number is the level number
				// new vector [first, end)
				std::vector<int> * recvGround = new vector<int> (recvBuf + 1,
						recvBuf + recvSize );
				groundness[recvLev] = recvGround;
				delete[ ] recvBuf;
}



void IcebergDetection::labelCrossLayers(int numLevels,
		Vector<DisjointBoxLayout> amrGrids,
		Vector<LevelData<FArrayBox> *> & labels,
		Vector<ProblemDomain> amrDomains, Vector<int> refRatio, int root,
		std::vector<set<std::pair<int, int> > *> & amrLabelEquiv /*OUT*/,
		 std::vector<std::vector<int> *> &groundness/*OUT*/) {

#if defined(LOG)
	pout() << "=============== Label Cross Levels ====================" << endl;
#endif

	int rank = 0;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	int tag1 = 20, rootRecv1stTag, rootRecv2ndTag;
	int tag2 = tag1+ numLevels;
	int *buf;
	int sendNum = 0;

	std::set<std::pair<int, int> > localLabelEquiv; // this label Equivalence info. is derived from adjacent layers
	std::set<std::pair<int, int> > GLLabelEquiv;

	bool GLisRoot = false;
	//******************filling the label from coarsen layer, and unify the label across layers
	for (int lev = 1; lev < numLevels; ++lev) { // skip the coarsest layer
	    localLabelEquiv.clear();
	    GLLabelEquiv.clear();
		GLisRoot = false;
		rootRecv1stTag = tag1 + lev;
		rootRecv2ndTag = tag2 + lev;

		DisjointBoxLayout levelGrids = amrGrids[lev];
		LevelData<FArrayBox> & levelLabel = (*labels[lev]); // data on one level
		//fill ghost cells for thickness data
		PiecewiseLinearFillPatch ghostFiller(levelGrids, amrGrids[lev - 1], 1,
				amrDomains[lev - 1], refRatio[lev - 1], 1);
		// since we're not subcycling, don't need to interpolate in time
		Real time_interp_coeff = 0.0;
		ghostFiller.fillInterp(levelLabel, *labels[lev - 1], *labels[lev - 1],
				time_interp_coeff, 0, 0, 1);
		IntVect ghostV = levelLabel.ghostVect();

		//TODO: We can save this patch group in previous loop
		MPI_Comm patchComm;
		createPatchGroup(levelGrids, &patchComm);
#if defined(LOG)
		pout() << "************ Level " << lev << "***************" << endl;
#endif
		if (patchComm != MPI_COMM_NULL) {
			int groupSize = 0, groupRank = 0;
			MPI_Comm_size(patchComm, &groupSize);
			MPI_Comm_rank(patchComm, &groupRank);
			int groupLeader = groupSize - 1;

			// we have convection here that in the label equivalence pair, the left one is the label number of finest layer,
			// and the right one is the label number from layer that is below finest layer
			collectLabelEquivPair(levelGrids, levelLabel, ghostV, localLabelEquiv,lev, true);
#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev)  << "Collect label equivalent pair size : " << localLabelEquiv.size() << endl;
			pout() << "CrossLevel " ;
#endif
			//mpiGdbDebug();
			aggLabelEquivPair(localLabelEquiv, groupLeader, patchComm, GLLabelEquiv, lev);

#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev)  << "Aggregate label equivalent pair to level-computing group leader : " << GLLabelEquiv.size() << endl;
#endif

			if (groupRank == groupLeader){ // if group leader happens to be root, we dont perform communication
#if defined(LOG)
	pout() << PREFIX_LEVEL_STEP(lev)  << "I am level-computing group leader" << endl;
#endif
				if (rank != root){
					GLSendLabelEquivToRoot( GLLabelEquiv , root, rootRecv1stTag, lev, rootRecv2ndTag);
				}else {
					GLisRoot = true;
				}
			}

		}

		if (rank == root){
			if (GLisRoot){ // data is on this processor, dont need to perform communication
				std::set<std::pair<int, int> > *cpyLabels = new set<std::pair<int, int> > ();
				std::set<std::pair<int, int> >::iterator itr ;
				for(itr = GLLabelEquiv.begin(); itr != GLLabelEquiv.end() ; itr++){
					(*cpyLabels).insert(std::make_pair((*itr).first, (*itr).second));
				}
				if (lev > amrLabelEquiv.size()) {
					pout() << "Wrong: lev [" << lev <<"] is greater than expected maximum level "<< amrLabelEquiv.size() << endl;
				}else if (amrLabelEquiv[lev - 1] != NULL) {
							pout() << "Wrong: amrLabelEquiv data from level " << lev
									<< " already exist in the global vector !" << endl;
				}
				amrLabelEquiv[lev-1] = cpyLabels;
			}else {
				rootRecvLabelEquiv( rootRecv1stTag, rootRecv2ndTag, amrLabelEquiv);
			}
		}

	}

	//NOW, the root processor have the global label equivalence info.
	// it will start to do something????
	// using the maximum label number to update the label value of all AMR layers
	if (rank == root) {
		//Using the label equivalence info, we need to update the groundness
		//The groundness is updated in the way that any "grounded" label will propagate to equivalent component
		//		printLabelPair(amrLabelEquiv);
		//		printGroundness(groundness);

#ifdef LOG
		printGroundness(groundness);
#endif
		propagateGroundness(numLevels, amrLabelEquiv, groundness);

		encodeGroundness(numLevels, groundness, sendNum, buf); //prepare for the groundness broadcast

	}
	MPI_Bcast(&sendNum, 1, MPI_INT, root, MPI_COMM_WORLD);

	if (rank != root)
		buf = new int[sendNum];
	MPI_Bcast(buf, sendNum, MPI_INT, root, MPI_COMM_WORLD);

	decodeGroundness(buf, groundness);

#if defined(LOG)
	pout() <<  "Recv. groundness from root with size " << groundness.size() << endl;
#endif

	delete[] buf;
}




void IcebergDetection::collectLabelEquivAcrossLevels(int numLevels,
		Vector<DisjointBoxLayout> amrGrids,
		Vector<LevelData<FArrayBox> *> & labels,
		Vector<ProblemDomain> amrDomains, Vector<int> refRatio, int root,
		std::vector<set<std::pair<int, int> > *> & amrLabelEquiv /*OUT*/) {

#if defined(LOG)
	pout() << "=============== collectEquivAcrossLevels====================" << endl;
#endif

	int rank = 0;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	int tag1 = 20, rootRecv1stTag, rootRecv2ndTag;
	int tag2 = tag1+ numLevels;

	std::set<std::pair<int, int> > localLabelEquiv; // this label Equivalence info. is derived from adjacent layers
	std::set<std::pair<int, int> > GLLabelEquiv;

	bool GLisRoot = false;
	//******************filling the label from coarsen layer, and unify the label across layers
	for (int lev = 1; lev < numLevels; ++lev) { // skip the coarsest layer
	    localLabelEquiv.clear();
	    GLLabelEquiv.clear();
		GLisRoot = false;
		rootRecv1stTag = tag1 + lev;
		rootRecv2ndTag = tag2 + lev;

		DisjointBoxLayout levelLayout = amrGrids[lev];
		LevelData<FArrayBox> & levelLabel = (*labels[lev]); // data on one level
		//fill ghost cells for thickness data
		PiecewiseLinearFillPatch ghostFiller(levelLayout, amrGrids[lev - 1], 1,
				amrDomains[lev - 1], refRatio[lev - 1], 1);
		// since we're not subcycling, don't need to interpolate in time
		Real time_interp_coeff = 0.0;
		ghostFiller.fillInterp(levelLabel, *labels[lev - 1], *labels[lev - 1],
				time_interp_coeff, 0, 0, 1);
		IntVect ghostV = levelLabel.ghostVect();
		//TODO: We can save this patch group in previous loop
		MPI_Comm patchComm;
		createPatchGroup(levelLayout, &patchComm);
#if defined(LOG)
		pout() << "************ Level " << lev << "***************" << endl;
#endif
		if (patchComm != MPI_COMM_NULL) {
			int groupSize = 0, groupRank = 0;
			MPI_Comm_size(patchComm, &groupSize);
			MPI_Comm_rank(patchComm, &groupRank);
			int groupLeader = assignGroupLeader(groupRank, groupSize);

			// we have convection here that in the label equivalence pair, the left one is the label number of finest layer,
			// and the right one is the label number from layer that is below finest layer
			collectLabelEquivPair(levelLayout, levelLabel, ghostV, localLabelEquiv,lev, true);

#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev)  << "Collect label equivalent pair size : " << localLabelEquiv.size() << endl;
#endif


			//mpiGdbDebug();
			aggLabelEquivPair(localLabelEquiv, groupLeader, patchComm, GLLabelEquiv, lev);

#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev)  << "Aggregate label equivalent pair to level-computing group leader : " << GLLabelEquiv.size() << endl;
#endif

			if (groupRank == groupLeader){ // if group leader happens to be root, we dont perform communication
				if (rank != root){
					GLSendLabelEquivToRoot( GLLabelEquiv , root, rootRecv1stTag, lev, rootRecv2ndTag);

				}else {
					GLisRoot = true;
				}
			}

		}

		if (rank == root){
			if (GLisRoot){ // data is on this processor, dont need to perform communication
				std::set<std::pair<int, int> > *cpyLabels = new set<std::pair<int, int> > ();
				std::set<std::pair<int, int> >::iterator itr ;
				for(itr = GLLabelEquiv.begin(); itr != GLLabelEquiv.end() ; itr++){
					(*cpyLabels).insert(std::make_pair((*itr).first, (*itr).second));
				}
				if (amrLabelEquiv[lev - 1] != NULL) {
							pout() << "Wrong: amrLabelEquiv copied data from level " << lev
									<< " already exist in the global vector !" << endl;
				}
				amrLabelEquiv[lev-1] = cpyLabels;
			}else {
				rootRecvLabelEquiv( rootRecv1stTag, rootRecv2ndTag, amrLabelEquiv);
			}
		}
		MPI_Barrier(MPI_COMM_WORLD);

	}


}

void IcebergDetection::takeParentArraySeg(std::vector<int> &rootParentArrayOffset, int lev
		, std::vector<int> &rootGlobalParentArray
		, std::vector<int> & segParentArray /*OUT*/)
{
    int index = 1; // it skips the first label, which is label 0.
    for(int j = 0
    		; j < (rootParentArrayOffset[lev + 1] - rootParentArrayOffset[lev]); j++){
        segParentArray.push_back(rootGlobalParentArray[rootParentArrayOffset[lev] + index  + j]);
    }
}


/*
 * TODO: consider different cases of ghostVect, some dimension may miss ghost cells
 */

void  IcebergDetection::labelEachLayer(int numLevels,
		Vector<DisjointBoxLayout> & amrGrids, Vector<RefCountedPtr<LevelSigmaCS > > & m_vect_coordSys
		 , Real threshold, int root,
		 Vector<LevelData<FArrayBox> *> & labels /*OUTPUT*/
		, std::vector<std::vector<int> *> &groundness /*OUTPUT*/) {

	int rank = 0;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	int tag1 = 20, rootRecv1stTag, rootRecv2ndTag;
	int tag2 = tag1+ numLevels, groupLeader = -1;
	//=============================************==========================//
	// HAVE TO declare this in the common area, which every processor can see it
	//If I declare it on the group leader, there is a bug when the total processor is 1

	// variables below exists every processor in the the level-computing group, its name begins with "local"
	std::vector<int> localLabelVec;
	std::set<std::pair<int, int> > localLabelEquiv; //
	std::vector<int> localRecvUniqLabel;
	std::vector<int> localGroundness;

	// variables below exists on group leader of the level-computing group, its name begins with "GL" (GroupLeader)
	std::vector<int> GLaggLabelVec;
	std::set<std::pair<int, int> > GLLabelEquivPairs;
	std::vector<int> GLGroundness;
	int GLuniqLabelNum = 0; // exists only on group leader
	bool GLisRoot = false;  // flag indicates group leader is the root if it is true

#if defined(LOG)
	pout() << "=============== Label Level level ====================" << endl;
#endif

	//vector contains the group leader on every level, the rank is the global rank
	for (int lev = 0; lev < numLevels; ++lev) {
		localLabelVec.clear();
		localLabelEquiv.clear();
		localRecvUniqLabel.clear();
		localGroundness.clear();
		GLaggLabelVec.clear();
		GLLabelEquivPairs.clear();
		GLGroundness.clear();
		GLuniqLabelNum =0;
		GLisRoot = false;
		rootRecv1stTag = tag1 + lev;
		rootRecv2ndTag = tag2 + lev;

		DisjointBoxLayout levelLayout = amrGrids[lev];
		labels[lev] = new LevelData<FArrayBox> (levelLayout, 1, IntVect::Unit);
		//		groundness[lev] = new LevelData<int> (levelGrids,1, IntVect::Zero);
		LevelSigmaCS& levelCS = *m_vect_coordSys[lev];
		LevelData<FArrayBox> & levelThickness =  levelCS.getH(); //(*thickness[lev]); // data on one level
		LevelData<FArrayBox> & levelLabel = (*labels[lev]); // data on one level
		const LevelData<BaseFab<int> > & levelMask =   levelCS.getFloatingMask() ;
		// ghost cells are surrounding on every patch, see figure 2.3 on page 45 of ChomboDesign Doc.
		IntVect ghostV = levelThickness.ghostVect();

		//**************The levelData distinguish the processors which has or do not have local data
		//**************since we are doing the aggregation & scatter operation on a specific group
		//**************we have to create a group to ensure the communication happens within this group

#if defined(LOG)
		pout() << "************ Level " << lev << "***************" << endl;
#endif

		MPI_Barrier(MPI_COMM_WORLD);
		MPI_Comm groupComm;

		createPatchGroup(levelLayout, &groupComm);

		if (groupComm != MPI_COMM_NULL) { // only processors that have the patches will participate the following communications

			//Although the levelData helps to distinguish the processor which has the patches,
			// we still need to put this under the group scope, since further action will
			// select patches that are not covered
			//===========STEP1: labeling on local patches =========/

			CCLonLocalPatches(levelLayout, levelLabel,
					levelThickness, threshold,  lev, localLabelVec);
			// local label number
			int localLabelNum = localLabelVec.size() - 1; // from the array, we have to remove the 0 label, which represents the background cell
#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev) << "Local label number: " << localLabelNum << endl;
#endif

			int groupSize = 0, groupRank = 0;
			MPI_Comm_size(groupComm, &groupSize);
			MPI_Comm_rank(groupComm, &groupRank);
			groupLeader = groupSize -1;

			//===========STEP2: calculate accumulated label summary =========/

			int accuLabelSum = 0, localLabelOffset = 0;
			//******** create the label offset for each processor ***************/
			// processors   :  p0    p1     p2     p3     p5
			// # of labels  :  3     4       2     2      1
			// scan results :  3     7       9     11     12
			// label offset :  0     3       7     9      11
			//TODO: have to figure out the group of processors who participates the patch exchange
			// meaning, the processors that have patch at same level is subset of entire processors

			MPI_Scan(&localLabelNum, &accuLabelSum, 1, MPI_INT, MPI_SUM, groupComm);

			//===========STEP3: update to level-wise global label number=========/
			//===========Meanwhile, collect the groundness of each label ????====/
			//****Using label offset to update label, then do the exchange, so that we can figure out the label equivalence clearly */
			// update the array. Note the index of the array is still 0,1,2,3, but the label value is increased by the offset value
			localLabelOffset = accuLabelSum - localLabelNum;
			for (int i = 1; i < localLabelVec.size(); i++) {
				localLabelVec[i] = localLabelVec[i] + localLabelOffset;
			}
			// update label values
			updateLocalLabel(levelLayout, levelLabel, localLabelOffset);
#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev) << "Update local label with offset " << localLabelOffset << endl;
#endif

			/**Aggregate the label array to one of the processor, in this case, we aggregate it to the group leader processor */
			//===========STEP5: aggregate label parent array and groundness array=========/
			//===========this step could happen later ====================================/

			aggParentArray(localLabelVec, groupLeader, groupComm, GLaggLabelVec);
#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev) << "Aggregated label number on level-computing group : " << GLaggLabelVec.size() << endl;
#endif
			//===========STEP6: fill ghost cells at same AMR level =========/
			//=============expensive operation===========================/
			levelLabel.exchange();

			//===========STEP7: derive label equivalence & clear the ghost cells=========/
			// Derive label equivalence info. by checking the labels at boundary cells & ghost cells
			collectLabelEquivPair(levelLayout, levelLabel, ghostV, localLabelEquiv, lev, false);
#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev) << "Collected local label equivalent pair size : " << localLabelEquiv.size() << endl;
#endif

			//===========STEP8:  aggregate label equivalent size ===============/
			aggLabelEquivPair(localLabelEquiv, groupLeader, groupComm,
					GLLabelEquivPairs, lev);
#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev) << "Aggregated label equivalent pair size: "<< GLLabelEquivPairs.size() << endl;
#endif
			//===========STEP9:  update level-wise global label array & flatten it ===============/
			// flatten the array
			if (groupRank == groupLeader)
				processParrenArrayOnLeader( &GLLabelEquivPairs, GLaggLabelVec, GLuniqLabelNum);

#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev) << "Unique label number after flattening on level-computing group leader : " << GLuniqLabelNum << endl;
#endif
			//===========STEP10:  disseminate level-computing group label to each processor===============/
			disseminateUniqueLabel(groupLeader, localLabelNum, GLaggLabelVec, groupComm, localRecvUniqLabel);
#if defined(LOG)
			pout() <<PREFIX_LEVEL_STEP(lev) <<  "Recv unique label equivalent size: " << localRecvUniqLabel.size() <<endl;
#endif
			//broadcast unique label number
			// now every process has its own label number
			MPI_Bcast(&GLuniqLabelNum, 1, MPI_INT, groupLeader, groupComm);

			//===========STEP11:  update local label to level-wise global label ===============/
			// update the labels at cells using this unique label number
			//TODO: we can merge them into same procedure
			updateLocalLabelToUniqueLabel(levelLayout, levelLabel, localRecvUniqLabel, localLabelOffset);
			//clear the labels on ghost cells, preparing for the fillInterp function
			clearLabelsOnGhostCells(levelLayout, levelLabel, ghostV, lev);

			//TODO: if we can know the unique local label,
			// we can do further optimize this, as the decreasing marked grounded number should go down to
			// the unique local label number, instead of level local label
			localGroundness = collectGroundnessOfLabeledComponent( GLuniqLabelNum, levelLabel, levelMask, levelLayout);
#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev) <<  "Collect local groundness size : " << localGroundness.size() << endl;
#endif

			unionGroundnessOnLeader(groupLeader, groupComm, localGroundness, GLGroundness);

			//There is a fast way to determine no icebergs
			// Looking at the groundness on the coarsest layer, if all of components are grounded, then, there is no floating component
			//This is determined by the nested property of AMR data structure, which is a fine layer must properly nest within the coarse layer

#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev) << "Union groundness on level-computing group leader size : " << GLGroundness.size() << endl;
#endif

			if (groupRank == groupLeader){
				if (rank != root){
					GLsendGroundnessToRoot( GLGroundness, lev, root, rootRecv1stTag, rootRecv2ndTag);
				}else {
					GLisRoot = true;
				}
			}
		}else {

#if defined(LOG)
			pout() << PREFIX_LEVEL_STEP(lev) << "I am not in the level-computing group " << endl;
#endif
		}


		MPI_Barrier(MPI_COMM_WORLD);

		if (rank == root){
			if (GLisRoot){ // data is on this processor, dont need to perform communication
				std::vector<int> * cpy = new std::vector<int> ( GLGroundness.begin(),
						GLGroundness.end());
				groundness[lev] = cpy;
			}else {
				rootRecvGroundness(rootRecv1stTag, rootRecv2ndTag, groundness);
			}
		}

	}

}

void IcebergDetection::encodeLabelEquiv(int numLevels,
		std::vector<set<std::pair<int, int> > *> alterLabel,
		int & sendNum /*OUT*/, int *& sendBuf /*OUT*/) {
	//NOW, I broadcast them to very process, so that that can update their label
	// array memory schema : | numLevel | l0 | l1 | l2 |... | l0 pairs | l1 pairs | .. |
	//Prepare the array
	sendNum = 1;
	sendNum += numLevels; // first elements show the size of each level
	std::vector<int> eachLevSize(numLevels, 0);
	for (int i = 0; i < alterLabel.size(); i++) {
		eachLevSize[i] = alterLabel[i]->size() * 2; // set size * 2 , since there are pairs
		sendNum += eachLevSize[i];
	}
	sendBuf = new int[sendNum];
	sendBuf[0] = numLevels;
	int *cPtr = (sendBuf + 1);
	std::copy(eachLevSize.begin(), eachLevSize.end(), cPtr); // copy the first level number size
	cPtr += eachLevSize.size(); //sendBuf+ bufIdx points the location where the copy begins
	for (int i = 0; i < alterLabel.size(); i++) {
		std::set<std::pair<int, int> > *al = alterLabel[i];
		std::set<std::pair<int, int> >::iterator alit;
		for (alit = al->begin(); alit != al->end(); ++alit) {
			*cPtr = (*alit).first;
			cPtr++;
			*cPtr = (*alit).second;
			cPtr++;
		}
	}

}

void IcebergDetection::decodeLabelEquiv(int * sendBuf,
		std::vector<set<std::pair<int, int> > *> & recvLabelEquiv /*OUT*/) {
	// convert sendBuf to std::vector<set<std::pair<int, int> > *>
	int ln = sendBuf[0];
	int *tmp = (sendBuf + 1 + ln);
	recvLabelEquiv = std::vector<set<std::pair<int, int> > *>(ln, NULL);
	int length = 0;
	for (int l = 0; l < ln; l++) {
		length = sendBuf[1 + l];
		CH_assert(length % 2 == 0);
		recvLabelEquiv[l] = new set<std::pair<int, int> > ();
		for (int p = 0; p < length; p += 2) {
			(*recvLabelEquiv[l]).insert(std::make_pair(tmp[p], tmp[p + 1]));
		}
		tmp += length;
	}

}

void IcebergDetection::cleanupAllocatedVec(int numLevels,
		std::vector<set<std::pair<int, int> > *> data) {
	// ONCE finish the label update, free the  recvLabelEquiv;
	for (int lev = 0; lev < numLevels; ++lev) {

		if (data[lev] != NULL) {
			delete data[lev];
			data[lev] = NULL;
		}

	}
}

void IcebergDetection::decodeGroundness(int * sendBuf,
		std::vector<std::vector<int> *> & groundness /*OUT*/) {
	// convert sendBuf to std::vector<set<std::pair<int, int> > *>
	CH_TIME("PCCL-Main:decodeGroundness");

	int ln = sendBuf[0];
	int *tmp = (sendBuf + 1 + ln);
	groundness = std::vector<std::vector<int> *>(ln, NULL);
	//	groundness.resize(ln);
	int length = 0;
	for (int l = 0; l < ln; l++) {
		length = sendBuf[1 + l];
		groundness[l] = new std::vector<int>();
		for (int p = 0; p < length; p++) {
			(*groundness[l]).push_back(tmp[p]);
		}
		tmp += length;
	}

}

void IcebergDetection::encodeGroundness(int numLevels,
		std::vector<std::vector<int> *> & groundness, int & sendNum /*OUT*/,
		int *& sendBuf /*OUT*/) {
	//NOW, I broadcast groundness to very process, so that that can eliminate their cells
	// array memory schema : | numLevel | l0 unique label num | l1 unique label num |... | l0 groundness | l1 groundness | .. |
	//Prepare the array
	sendNum = 1;
	sendNum += numLevels; // first elements show the size of each level
	std::vector<int> eachLevSize(numLevels, 0);
	for (int i = 0; i < groundness.size(); i++) {
		eachLevSize[i] = groundness[i]->size();
		sendNum += eachLevSize[i];
	}
	sendBuf = new int[sendNum];
	sendBuf[0] = numLevels;
	int *cPtr = (sendBuf + 1);
	std::copy(eachLevSize.begin(), eachLevSize.end(), cPtr); // copy the first level number size
	cPtr += eachLevSize.size(); //sendBuf+ bufIdx points the location where the copy begins
	for (int i = 0; i < groundness.size(); i++) {
		std::vector<int> *al = groundness[i];
		std::vector<int>::iterator alit;
		for (alit = al->begin(); alit != al->end(); ++alit) {
			*cPtr = (*alit);
			cPtr++;
		}
	}

}

void IcebergDetection::GLSendLabelEquivToRoot(
		std::set<std::pair<int,int> > GLLabelEquiv,
		int root, int rootRecv1stTag, int lev, int rootRecv2ndTag)
{
    // send this globalLabelEquiv to the root processor
	//MPI_Request req1, req2;
	MPI_Request req1;
	std::set<std::pair<int, int> >::iterator it;
	int sendSize = GLLabelEquiv.size() * 2 + 1; // allocate one extra element for the level info.
	MPI_Isend(&sendSize, 1, MPI_INT, root, rootRecv1stTag,
			MPI_COMM_WORLD, &req1);

	//switch to vector, instead of malloced int arrary, since its hard to deallocate the int array
	int * labelEquivArray = new int[sendSize];
	// NOTE: stupid vector has some issues on the edison server
	// use the array instead now
	int li = 0;
	labelEquivArray[li++]= lev;// first element is the level info.
	for (it = GLLabelEquiv.begin(); it
			!= GLLabelEquiv.end(); ++it) {
		labelEquivArray[li++] = (*it).first;
		labelEquivArray[li++] = (*it).second;
	}

	//NOTE: To free this array, I have to use the blocking send now
	MPI_Send(labelEquivArray, sendSize, MPI_INT, root,
			rootRecv2ndTag, MPI_COMM_WORLD);
	delete [] labelEquivArray;
/*	int * buf= &labelEquivArray[0];
	 MPI_Isend(buf, sendSize, MPI_INT, root,
			rootRecv2ndTag, MPI_COMM_WORLD, &req2);*/
}

void IcebergDetection::rootRecvLabelEquiv( int rootRecv1stTag, int rootRecv2ndTag,
		 std::vector<set<std::pair<int,int> > *> & amrLabelEquiv /*OUT*/)
{
  // I am the one who are supposed to receive these label equivalence info.
		/*int MPI_Recv(void *buf, int count, MPI_Datatype datatype, int source, int tag,
		 MPI_Comm comm, MPI_Status *status)*/
		/*
		 * int MPI_Irecv(void *buf, int count, MPI_Datatype datatype, int source,
		 int tag, MPI_Comm comm, MPI_Request *request)
		 */
		int recvSize;
		MPI_Status mpiStatus;
		MPI_Request request;
		MPI_Irecv(&recvSize, 1, MPI_INT, MPI_ANY_SOURCE, rootRecv1stTag,
				MPI_COMM_WORLD, &request);
		MPI_Wait(&request, &mpiStatus);

		int *recvBuf = new int[recvSize];
		MPI_Irecv(recvBuf, recvSize, MPI_INT, MPI_ANY_SOURCE,
				rootRecv2ndTag, MPI_COMM_WORLD, &request);
		MPI_Wait(&request, &mpiStatus);

		std::set<std::pair<int, int> > *recvLabels = new set<std::pair<int,
				int> > ();
		int recvLev = recvBuf[0]; // first element is excluded
		for (int j = 1/*skip first one*/; j < recvSize; j += 2) {
			(*recvLabels).insert(std::make_pair(recvBuf[j], recvBuf[j + 1]));
		}

#if defined(LOG)
	pout() << "====Root receive label equiv. from level " << recvLev << " with size " << recvSize<< endl;
#endif

		// free
		delete[] recvBuf;
		// Note: amrLabelEquiv size = numLevel -1;
		// the recvLev starts with 0, we have to subtract 1 to make it vector index
		if (recvLev > amrLabelEquiv.size()) {
				pout() << "Wrong: recved lev [" << recvLev <<"] is greater than expected maximum level "<< amrLabelEquiv.size() << endl;
        }else if (amrLabelEquiv[recvLev - 1] != NULL) {
			pout() << "Wrong: amrLabelEquiv received data from level " << recvLev
					<< " already exist in the global vector !" << endl;
		}
		amrLabelEquiv[recvLev - 1] = recvLabels;
		//			amrLabelEquiv.push_back(recvLabels);


}



void IcebergDetection::cleanupVectOfVect(std::vector<std::vector<int> *> &groundness)
{
    for (int i = 0; i < groundness.size(); i++) {
		if (groundness[i] != NULL) {
			delete groundness[i];
			groundness[i] = NULL;
		}
	}
}

void IcebergDetection::cleanupVectData(Vector<LevelData<FArrayBox> *> &vectData){
	for (int lev = 0; lev < vectData.size(); ++lev) {
		if (vectData[lev] != NULL) {
			delete vectData[lev];
			vectData[lev] = NULL;
		}
	}
}


void IcebergDetection::cleanupFloatingMask(Vector<LevelData<BaseFab<int> > *> &floatingMask){
	for (int lev = 0; lev < floatingMask.size(); ++lev) {
		if (floatingMask[lev] != NULL) {
			delete floatingMask[lev];
			floatingMask[lev] = NULL;
		}
	}
}

void IcebergDetection::cleanupLabelEquiv(std::vector<set<std::pair<int,int> > *> &amrLabelEquiv){
	for (int i = 0; i < amrLabelEquiv.size(); i++) {
			if (amrLabelEquiv[i] != NULL) {
				delete amrLabelEquiv[i];
				amrLabelEquiv[i] = NULL;
			}
	}
}


void IcebergDetection::destroyIces(int numLevels, Vector<LevelData<FArrayBox> *> & labels
		,Vector<RefCountedPtr<LevelSigmaCS > > & m_vect_coordSys, Vector<DisjointBoxLayout> amrGrids, std::vector<std::vector<int> *> & groundness)
{

    //now destroy the doomed regions, and reset a_coordSys
    for(int lev = 0;lev < numLevels;++lev){
           LevelData<FArrayBox> & levelLabel = (*labels[lev]);
           LevelSigmaCS& levelCS = *m_vect_coordSys[lev];
           LevelData<FArrayBox> & levelThickness =  levelCS.getH(); //(*thickness[lev]); // data on one level
           std::vector<int> levelGround = *(groundness[lev]);
           DisjointBoxLayout levelGrid = amrGrids[lev];
           DataIterator patchItr = levelGrid.dataIterator();
           for (patchItr.begin(); patchItr.ok(); ++patchItr) {
               FArrayBox & patchLabel = levelLabel[patchItr];
               Box box = levelGrid[patchItr];
               BoxIterator cellItr (box);
               FArrayBox & patchThick = levelThickness[patchItr];
               for(cellItr.begin();cellItr.ok();++cellItr){
                   const IntVect & iv = cellItr();
                   if( patchLabel(iv) > 0 &&
                   	levelGround[patchLabel(iv)] == IcebergDetection::ICE_FLOATING){
                       patchThick(iv) = 0.0;
                   }
               }

           }

      }
}



int  IcebergDetection::assignGroupLeader(int groupRank , int groupSize){
	return groupSize - 1; // choose last processor in the group as the group leader proc.
}

void IcebergDetection::mergeLabel(std::set<std::pair<int,int> > * labelEquivPairs, std::vector<int> & GLaggLabelVec){
    std::set<std::pair<int,int> >::iterator it;
    for(it = labelEquivPairs->begin();it != labelEquivPairs->end();++it){
        doMergeLabels(GLaggLabelVec, (*it).first, (*it).second);
    }
}

void IcebergDetection::insertOneElmInChain(std::map<int, std::set<int> > &mapChain, int key, int value){
	std::map<int, std::set<int> >::iterator found = mapChain.find(key);
		if ( found == mapChain.end() ){
			std::set<int> s1 ;
			s1.insert(value);
			mapChain[key] = s1;
		}else{
			(found->second).insert(value);
		}
}

bool IcebergDetection::findLongMergeLabels(std::map<int, std::set<int> > &mapChain, int countThreshold, int *key){
	int minSize = countThreshold;
	(*key)  = -1;
	bool find = false;
	std::set<int> s;
	for (std::map<int, std::set<int> >::iterator itr = mapChain.begin(); itr != mapChain.end(); ++itr) {
		 s = itr->second;
		if (s.size() >= minSize) {
			find = true;
			(*key) = itr->first;
			minSize = s.size();
		}
	}
	return find;
}

int IcebergDetection::findMinElminSet(std::set<int> &s){
	int min= INT_MAX;
	for(std::set<int>::iterator i1 = s.begin(); i1 != s.end(); i1++){
		if (*i1 < min)
			min = *i1;
	}
	return min;

}

void IcebergDetection::insertPairs(std::set<int> &s, std::set<std::pair<int, int> > & pairs){
	std::set<int>::iterator i1 = s.begin();
	std::set<int>::iterator i2 = s.begin();
	i2++;
	for (int i = 0; i < s.size() -1 ; i ++) {
		int f= *i1;
		int sec = *(i2);
		pairs.insert(std::make_pair(f,sec));
		i1++;
		i2++;
	}
}

/*
 * using smallest element in the `equivSet` to replace any `equivSet` element appears in `pairs`
 */
std::set<std::pair<int, int> > IcebergDetection::replaceRightElmInPairs(
    		std::set<std::pair<int, int> > &pairs, std::set<int> &equivSet ){
	int replaceElm= findMinElminSet(equivSet);
	std::set<std::pair<int, int> > copy ;
	std::set<int>::iterator found;
	for(std::set<std::pair<int,int> >::iterator it = pairs.begin();it != pairs.end();++it){
		found = equivSet.find(it->second);
		if (found != equivSet.end()){ // find it and replace it
			copy.insert(std::make_pair(it->first, replaceElm));
		}else{
			copy.insert(std::make_pair(it->first, it->second));
		}
	}
	return copy;
}

std::set<std::pair<int, int> > IcebergDetection::replaceLeftElmInPairs(
    		std::set<std::pair<int, int> > &pairs, std::set<int> &equivSet ){
	int replaceElm= findMinElminSet(equivSet);
	std::set<std::pair<int, int> > copy ;
	std::set<int>::iterator found;
	for(std::set<std::pair<int,int> >::iterator it = pairs.begin();it != pairs.end();++it){
		found = equivSet.find(it->first);
		if (found != equivSet.end()){ // find it and replace it
			copy.insert(std::make_pair(replaceElm, it->second));
		}else{
			copy.insert(std::make_pair(it->first, it->second));
		}
	}
	return copy;
}

void IcebergDetection::rebuildMap(std::map<int,std::set<int> > &curMap, std::map<int,std::set<int> > &coarseMap, std::set<std::pair<int,int> > &copy)
{
    curMap.clear();
    coarseMap.clear();
    for(std::set<std::pair<int,int> >::iterator it = copy.begin();it != copy.end();++it){
        insertOneElmInChain(curMap, (*it).first, (*it).second);
        insertOneElmInChain(coarseMap, (*it).second, (*it).first);
    }
}


/*
 * input ( <1,3> , <2,3>, <2,2> , <4,3> , < 5, 2> )
 * output:
 *   curPairs :  === > <1,2> < 2, 4> <4,5>
 *   coarsePairs: === > < 2,3>
 *
 */
void IcebergDetection::identifyTwoEquivPairTypes (
		  std::set<std::pair<int, int> > * GLEquivPairs
		, std::set<std::pair<int, int> > & curPairs
		, std::set<std::pair<int, int> > & coarsePairs){

	int countThreshold  =2 ;
	std::set<std::pair<int, int> > copy;
	std::map<int, std::set<int> > curMap;
	std::map<int, std::set<int> > coarseMap;
	for(std::set<std::pair<int,int> >::iterator it = GLEquivPairs->begin();
			it != GLEquivPairs->end();++it){
		copy.insert(std::make_pair(it->first, it->second));
		insertOneElmInChain(curMap, (*it).first, (*it).second);
		insertOneElmInChain(coarseMap, (*it).second, (*it).first);

	}

	bool flag = true;
	std::set<int> s;
	while (flag ){
		int curKey, coarseKey;
		bool curFind =  findLongMergeLabels(curMap,countThreshold, &curKey);
		bool coarseFind = findLongMergeLabels(coarseMap,countThreshold, &coarseKey);

		if ( !curFind && !coarseFind){ // we dont find it in both chains
			flag = false;
			break;
		}

		if (curFind){ // collapse labels on coarse side ( merge right elements in the pairs)
			s = curMap[curKey];
			insertPairs(s, coarsePairs);
			// once label collapse, we have to rebuild it
			copy = replaceRightElmInPairs(copy, s);
			rebuildMap(curMap, coarseMap, copy);
		}else if (coarseFind) {
			s = coarseMap[coarseKey];
			insertPairs(s, curPairs);
			// once label collapse, we have to rebuild it
			copy = replaceLeftElmInPairs(copy, s);
			rebuildMap(curMap, coarseMap, copy);
		}

	}
}

//,Vector<LevelData<FArrayBox>*> &thickness /*IN&OUT*/
		//,Vector<LevelData<BaseFab<int> >*> &floatingMask
void IcebergDetection::doGroundnessDetection( int numLevels
		,Vector<ProblemDomain> &amrDomains
		,Vector<DisjointBoxLayout> &amrGrids
		, Vector<RefCountedPtr<LevelSigmaCS > > & m_vect_coordSys /*OUT Thickness value would be changed*/
		,Vector<int> &refRatio, Real threshold){

	int rank = 0;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	Vector<LevelData<FArrayBox>*> labels(numLevels, NULL);
	std::vector<std::vector<int> *> groundness (numLevels, NULL);
	int root = 0; // a root processor is a processor in charge of collecting label equivalence info. produced from each layer

    labelEachLayer(numLevels, amrGrids,  m_vect_coordSys, threshold, root, labels, groundness);

	MPI_Barrier(MPI_COMM_WORLD);


	// it is supposed to have numLevels-1 size, since we skip the coarse level
	std::vector<std::set<std::pair<int, int> > *> amrLabelEquiv (numLevels-1, NULL);
	labelCrossLayers(numLevels, amrGrids, labels, amrDomains, refRatio, root, amrLabelEquiv,  groundness);

	MPI_Barrier(MPI_COMM_WORLD);

	destroyIces(numLevels, labels, m_vect_coordSys,  amrGrids, groundness);


	cleanupLabelEquiv(amrLabelEquiv);
	cleanupVectOfVect(groundness);
	cleanupVectData(labels);
}


#endif

#include "NamespaceFooter.H"
