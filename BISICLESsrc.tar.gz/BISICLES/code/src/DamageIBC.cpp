#ifdef CH_LANG_CC
/*
*      _______              __
*     / ___/ /  ___  __ _  / /  ___
*    / /__/ _ \/ _ \/  V \/ _ \/ _ \
*    \___/_//_/\___/_/_/_/_.__/\___/
*    Please refer to Copyright.txt, in Chombo's root directory.
*/
#endif
#include "DamageIBC.H"
#include "FillFromReference.H"
#include "ReflectGhostCells.H"
#include "QuadCFInterp.H"
#include "ParmParse.H"
#include "LevelMappedDerivatives.H"
#include "ReadLevelData.H"
#include "AmrIce.H"
#include "IceConstants.H"
#include "NyeCrevasseF_F.H"
#include "SigmaCSF_F.H"
#ifdef HAVE_PYTHON
#include "PythonInterface.H"
#endif
#include "NamespaceHeader.H"


// make this a local function 
void
DamageUtils::extendVelocityAtCalvingFronts(LevelData<FArrayBox>& a_modifiedVel,
                                           const LevelData<FArrayBox>& a_originalVel,
                                           const LevelData<FArrayBox>& a_iceThickness)
{
  
  DataIterator dit = a_modifiedVel.dataIterator();
  Real vel_eps = 1.0e-8;
  Real thickness_eps = 0.1;

  // turns out this might need a cornerCopier
  // put this into its own context because we're playing fast
  // and loose with const-ness 
  {
    const DisjointBoxLayout& grids = a_originalVel.getBoxes();
    const ProblemDomain& domain = grids.physDomain();
    LevelData<FArrayBox>& nonConstVel = *(const_cast<LevelData<FArrayBox>* >(&a_originalVel));
    CornerCopier cc(grids, grids, domain,
                    nonConstVel.ghostVect(), true);

    nonConstVel.exchange(cc);
  } // end cornerCopier scope

  for (dit.begin(); dit.ok(); ++dit)
    {
      FArrayBox& thisVel = a_modifiedVel[dit];
      const FArrayBox& thisH = a_iceThickness[dit];
      thisVel.copy(a_originalVel[dit]);
      //const BaseFab<int>& thisMask = floatingMask[dit];

      // loop over directions first because we want to be able to do ghost cells where possible
      for (int dir=0; dir<SpaceDim; dir++)
        {          
          Box velBox = a_modifiedVel[dit].box();
          velBox.grow(dir,-1);
          BoxIterator bit(velBox);
          SideIterator sit;                  
          for (bit.begin(); bit.ok(); ++bit)
            {
              IntVect iv = bit();
              // only do this for openSea cells
              if (abs(a_originalVel[dit](iv,0)) < vel_eps)
                {
                  for (sit.begin(); sit.ok(); ++sit)
                    {
                      IntVect shiftVect = sign(sit())*BASISV(dir);
                      // are we at a calving front?
                      //                      if (abs(a_originalVel[dit](iv+shiftVect,0)) > vel_eps)
                      if (abs(thisH(iv+shiftVect,0)) > thickness_eps)                      

                        {
                          // linearly extrapolate if possible
                          if ((thisVel.box().contains((iv+2*shiftVect))) && abs(thisH(iv+2*shiftVect,0)) > thickness_eps)
                            {
                              thisVel(iv,0) = 2.0*thisVel(iv+shiftVect,0) - thisVel(iv+2*shiftVect,0);
                              thisVel(iv,1) = 2.0*thisVel(iv+shiftVect,1) - thisVel(iv+2*shiftVect,1);
                            }
                          else
                            {
                              // just copy if stencil doesn't exist
                              thisVel(iv,0) = thisVel(iv+shiftVect,0);
                              thisVel(iv,1) = thisVel(iv+shiftVect,1);
                            }
                        } // end if neigboring cell is floating
                    } // end loop over hi-lo
                } // end if this is an opensea cell
            } // end loop over cells in this box
        } // end loop over directions
    } // end loop over boxes
}




DamageSrc*
ZeroDamageSrc::new_damageSrc() const
{
  ZeroDamageSrc* newPtr= new ZeroDamageSrc();
  return static_cast<DamageSrc*>(newPtr);
}

void
ZeroDamageSrc::getDamageSource(LevelData<FArrayBox>& a_source,
                               const LevelSigmaCS& a_coordSys,
                               const AmrIce* a_amrIcePtr,
                               int a_level,
                               LevelData<FArrayBox>& levelSTS,
                               LevelData<FArrayBox>& levelBTS,
                               Real a_time,
                               Real a_dt,
                               Real eps)
{
  DataIterator dit=a_source.dataIterator();
  for (dit.begin(); dit.ok(); ++dit)
    {
      a_source[dit].setVal(0.0);
    }
}


DamageSrc*
ConstantDamageSrc::new_damageSrc() const
{
  ConstantDamageSrc* newPtr= new ConstantDamageSrc(m_srcVal);
  return static_cast<DamageSrc*>(newPtr);
}

void
ConstantDamageSrc::getDamageSource(LevelData<FArrayBox>& a_source,
                                   const LevelSigmaCS& a_coordSys,
                                   const AmrIce* a_amrIcePtr,
                                   int a_level,
                                   LevelData<FArrayBox>& levelSTS,
                                   LevelData<FArrayBox>& levelBTS,
                                   Real a_time,
                                   Real a_dt,
                                   Real eps)
{
  DataIterator dit=a_source.dataIterator();
  // ice thickness...
  const LevelData<FArrayBox>& iceThickness = a_coordSys.getH();
  // effective ice thickness is the cell-averaged value divided by the ice area fraction
  LevelData<FArrayBox> effectiveH(iceThickness.getBoxes(), 1, iceThickness.ghostVect());
  a_amrIcePtr->computeEffectiveIceThickness(effectiveH, a_level);
  for (dit.begin(); dit.ok(); ++dit)
    {
      a_source[dit].setVal(m_srcVal);
      // integrated damage source
      a_source[dit].mult(effectiveH[dit]);
    }
}



DamageSrc*
CircleSpotDamageSrc::new_damageSrc() const
{
  CircleSpotDamageSrc* newPtr= new CircleSpotDamageSrc(m_srcVal, m_radius, m_center);
  return static_cast<DamageSrc*>(newPtr);
}

void
CircleSpotDamageSrc::getDamageSource(LevelData<FArrayBox>& a_source,
				     const LevelSigmaCS& a_coordSys,
                                     const AmrIce* a_amrIcePtr,
                                     int a_level,
                                     LevelData<FArrayBox>& levelSTS,
                                     LevelData<FArrayBox>& levelBTS,
				     Real a_time,
				     Real a_dt,
                                     Real eps)
{
  RealVect dx = a_coordSys.dx();
  DataIterator dit=a_source.dataIterator();
  Real radSqr = m_radius*m_radius;

  // ice thickness...
  const LevelData<FArrayBox>& iceThickness = a_coordSys.getH();
  // effective ice thickness is the cell-averaged value divided by the ice area fraction
  LevelData<FArrayBox> effectiveH(iceThickness.getBoxes(), 1, iceThickness.ghostVect());
  a_amrIcePtr->computeEffectiveIceThickness(effectiveH, a_level);
  for (dit.begin(); dit.ok(); ++dit)
    {
      FArrayBox& thisSrc = a_source[dit];
      FArrayBox& effectiveHFAB = effectiveH[dit];
      thisSrc.setVal(0.0);
      BoxIterator bit = thisSrc.box();
      for (bit.begin(); bit.ok(); ++bit)
	{
	  IntVect iv = bit();
	  RealVect loc(iv);
	  loc += 0.5*RealVect::Unit;
	  loc *= dx;

	  loc -= m_center;
	  Real locSqr = D_TERM(loc[0]*loc[0], +loc[1]*loc[1], + loc[2]*loc[2]);
	  if (locSqr <= radSqr)
	    {
          // Multiply by effective thickness for integrated damage source
	      thisSrc(iv,0) = m_srcVal*effectiveHFAB(iv,0);
	    }
	} // end loop over cells
    } // end loop over boxes
}

DamageSrc*
PhysicalDamageSrc::new_damageSrc() const
{
  PhysicalDamageSrc* newPtr= new PhysicalDamageSrc();
  return static_cast<DamageSrc*>(newPtr);
}

void
PhysicalDamageSrc::getDamageSource(LevelData<FArrayBox>& a_source,
                               const LevelSigmaCS& a_coordSys,
                               const AmrIce* a_amrIcePtr,
                               int a_level,
                               LevelData<FArrayBox>& levelSTS,
                               LevelData<FArrayBox>& levelBTS,
                               Real a_time,
                               Real a_dt,
                               Real eps)
{
  // Only evolve for nonzero times
  // Pull the constitutive relation from AmrIce
  ConstitutiveRelation* constRelPtr = a_amrIcePtr->getConstitutiveRelation();

  // Pull damage from AmrIce
  const LevelData<FArrayBox>& levelDamage = *(a_amrIcePtr->getDamage()[a_level]);

  const DisjointBoxLayout levelGrids = a_amrIcePtr->amrGrids()[a_level];
  const ProblemDomain& domain = levelGrids.physDomain();

  // ice thickness...
  const LevelData<FArrayBox>& iceThickness = a_coordSys.getH();
  // effective ice thickness is the cell-averaged value divided by the ice area fraction
  LevelData<FArrayBox> effectiveH(iceThickness.getBoxes(), 1, iceThickness.ghostVect());
  a_amrIcePtr->computeEffectiveIceThickness(effectiveH, a_level);

  // Assume that ghost-cell values for velocity have been set.
  // If they haven't, we will have to do coarse-fine interpolation, etc.
  const LevelData<FArrayBox>& iceVel = *a_amrIcePtr->velocity(a_level);

  // ice fraction mask
  const LevelData<FArrayBox>& iceMask = *a_amrIcePtr->iceMask(a_level);

  //  Initialize the undamaged ice viscosity
  //  We need to use one less than the ice velocity ghost vector
  IntVect muGhost = iceVel.ghostVect();
  muGhost -= IntVect::Unit;
  LevelData<FArrayBox> mu(levelGrids, 1, muGhost);

  // need to cast away const-ness for getA
  AmrIce* nonConstAmrIcePtr = const_cast<AmrIce*>(a_amrIcePtr);
  const LevelData<FArrayBox>& A = nonConstAmrIcePtr->getA(a_level);

  // non-const only because we will need to set coarse-fine BC's, but still
  // need to explicitly cast away the const-ness
  LevelData<FArrayBox>& nonConstVel = *(const_cast<LevelData<FArrayBox>*>(&iceVel));

  // coarse-fine boundary-condition stuff -- need coarser level if it exists
  LevelData<FArrayBox>* crseVelPtr = NULL;
  // nRefCrse will be refinement ratio to next coarser-level, if we're on a refined level
  int nRefCrse = -1;
  if (a_level > 0)
    {
      crseVelPtr  = const_cast<LevelData<FArrayBox>*>(a_amrIcePtr->velocity(a_level-1));
      nRefCrse = a_amrIcePtr->refRatios()[a_level-1];
    }

  LevelData<FArrayBox> tempVel(nonConstVel.getBoxes(),
                               nonConstVel.nComp(),
                               nonConstVel.ghostVect());

  
  DamageUtils::extendVelocityAtCalvingFronts(tempVel, nonConstVel, iceThickness);

  
  // Initialize 
  LevelData<FArrayBox> gradU(levelGrids, SpaceDim*SpaceDim, muGhost);

  // Calculate the strain rate invariant tensor
  constRelPtr->computeStrainRateInvariant(mu, gradU, tempVel, crseVelPtr,
                                          nRefCrse, a_coordSys, muGhost);
					  
  // Calculate the viscosity
  constRelPtr->computeMu(mu, tempVel, crseVelPtr, nRefCrse, A,
			 a_coordSys, domain, muGhost);

  // locate specific components of the velocity gradients in the multicomponent gradU arrays.
  // the derivComponent function is in LevelMappedDerivatives.H
  int dudxComp = derivComponent(0,0);
  int dudyComp = derivComponent(1,0);
  int dvdxComp = derivComponent(0,1);
  int dvdyComp = derivComponent(1,1);

  // Loop over individual boxes on a single processor
  DataIterator dit=a_source.dataIterator();
  for (dit.begin(); dit.ok(); ++dit)
    {
      // valid region box for this patch
      const Box& thisBox = levelGrids[dit];

      // this is copied extensively from DamageConsitutiveRelation.cpp in the public branch
      // working with strain rates e here
      // first compute e + I*tr(e)
      FArrayBox ee(thisBox, SpaceDim*SpaceDim);

      // this is a call to a fortran subroutine using the ChomboFortran macros
      // which automates dimensionality (2D, 3D, etc) and the C++/fortran interface
      FORT_UPLUSUT(CHF_FRA(ee), 
		    CHF_CONST_FRA(gradU[dit]),
		    CHF_INT(dudxComp),
		    CHF_INT(dudyComp),
		    CHF_INT(dvdxComp),
		    CHF_INT(dvdyComp),
		    CHF_BOX(thisBox));
      
      //2.0* (2.0e + 2.0*I*tr(e))
//      ee *= 2.0;
    
      //now compute principal strain rate components
      FArrayBox lambda(thisBox, SpaceDim);
      FORT_SYMTEIGEN(CHF_FRA(lambda), 
		     CHF_CONST_FRA(ee),
		     CHF_INT(dudxComp),
		     CHF_INT(dudyComp),
		     CHF_INT(dvdxComp),
		     CHF_INT(dvdyComp),
		     CHF_BOX(thisBox));


      // Initialize relevant parameters
      a_source[dit].setVal(0.0);   // Pre-set the source to zero
      Real iceDensity = a_coordSys.iceDensity();
      Real waterDensity = a_coordSys.waterDensity();
      Real gravity = a_coordSys.gravity();
      Real n = 3.0;
      Real eps = 1.0e-10; // minimum denominator

      // Determine if a manufactured solution test is requested and read in the appropriate parameters
      ParmParse dPP("damage");
      int manufacture = 0;   // Off by default
      dPP.query("manufactured", manufacture);
      Real ell = 0.0;
      dPP.query("ell", ell);
      if (manufacture != 0 && manufacture != 1)
        {
          MayDay::Error("damage.manufactured can only be 0 or 1");
        }

      Real damageInit = 0.5;
      dPP.query("initial_value", damageInit);
      if (damageInit < 0 || damageInit > 1)
        {
          MayDay::Error("damage.initial_value must be specified with a value between 0 and 1");
        }

      int advect = 1;   // On by default
      dPP.query("advect", advect);
      if (advect != 0 && advect != 1)
        {
          MayDay::Error("damage.advect can only be 0 or 1");
        }

      ParmParse ctPP("confinedTongue");
      Real glthk = 340.0;
      ctPP.query("glthk", glthk);
      if (glthk <= 0.0)
        {
          MayDay::Error("confinedTongue.glthk must be specified as a positive value");
        }

      // Evolve damage in time following Bassis & Ma 2015
      FORT_BASSISDAMAGE(CHF_FRA1(a_source[dit],0), 
                        CHF_CONST_FRA1(levelDamage[dit],0),
                        CHF_CONST_FRA1(effectiveH[dit],0),
                        CHF_CONST_FRA1(mu[dit],0),
                        CHF_CONST_FRA(lambda),
                        CHF_CONST_REAL(iceDensity),
                        CHF_CONST_REAL(waterDensity),
                        CHF_CONST_REAL(gravity),
                        CHF_CONST_REAL(n),
                        CHF_CONST_FRA1(levelSTS[dit],0),
                        CHF_CONST_FRA1(levelBTS[dit],0),
                        CHF_CONST_REAL(eps),
                        CHF_CONST_INT(manufacture),
                        CHF_CONST_REAL(ell),
                        CHF_CONST_REAL(damageInit),
                        CHF_CONST_FRA1(iceVel[dit],0),
                        CHF_CONST_REAL(a_time),
                        CHF_CONST_REAL(glthk),
                        CHF_CONST_INT(advect),
                        CHF_BOX(thisBox));

      // ice mask over the entire AMR level is iceMask -- iceMask on this patch is iceMask[dit]
      a_source[dit].mult(iceMask[dit], 0, 0, 1);

    }  // End loop over boxes in processor

  // Free memory
  if (constRelPtr != NULL)
    {
      delete constRelPtr;
    }
}   // End class


/// Set up initial conditions -- derived from physIBC
/**
 */
void
DamageIBC::initialize(LevelData<FArrayBox>& a_U)
{
  // shouldn't be here in this one
  MayDay::Error("Shouldn't be in DamageIBC::initialize");
}
  
///assemble a DamageIBC  object from ParmParse input, return pointer
DamageIBC* DamageIBC::parseDamageIBC(const char* a_prefix)
{
  DamageIBC* ptr = NULL;
  ParmParse muPP(a_prefix);
  std::string damageType = "zero";
  muPP.query("type",damageType );
  if (damageType == "zero")
    {
      ptr = static_cast<DamageIBC*>(new ZeroDamageIBC());
    }
  else if (damageType == "constant")
    {
      ptr = static_cast<DamageIBC*>(new ConstantDamageIBC());
    }
  else if (damageType == "LevelData")
    {
      //read a one level damage initial condition from an AMR Hierarchy, and  store it in a LevelData
      ParmParse ildPP("inputLevelData");
      std::string infile;
      ildPP.get("damageFile",infile);
      std::string damageName = "damage";
      ildPP.query("damageName",damageName);
      RefCountedPtr<LevelData<FArrayBox> > levelDamage (new LevelData<FArrayBox>());
      Vector<RefCountedPtr<LevelData<FArrayBox> > > vectDamage;
      vectDamage.push_back(levelDamage);
      Vector<std::string> names(1);
      names[0] = damageName;
      Real dx;
      readLevelData(vectDamage,dx,infile,names,1);
      RealVect levelDx = RealVect::Unit * dx;
      ptr = static_cast<DamageIBC*>
	(new LevelDataDamageIBC(levelDamage,levelDx));
      
      }
    else if (damageType == "MultiLevelData")
      {
	//read a multi level damage from an AMR Hierarchy, and  store it in a MultiLevelData of damage
	 ParmParse ildPP("inputLevelData");
	 std::string infile;
	 ildPP.get("damageFile",infile);
	 std::string damageName = "damage";
	 ildPP.query("damageName",damageName);
	 
	 Vector<Vector<RefCountedPtr<LevelData<FArrayBox> > > > vectDamage;
	 Vector<std::string> names(1);
	 names[0] = damageName;
	 Real dx;
	 Vector<int> ratio;
	 readMultiLevelData(vectDamage,dx,ratio,infile,names,1);
	 RealVect dxCrse = RealVect::Unit * dx;
	 ptr = static_cast<DamageIBC*>
	   (new MultiLevelDataDamageIBC(vectDamage[0],dxCrse,ratio));
	 
     }
    else if (damageType == "Nye")
      {
         // nothing much to do here...

     Real a_nyeFloorMaskMin = 0.99;
     muPP.query("nyeFloorMaskMin",a_nyeFloorMaskMin );
	 ptr = static_cast<DamageIBC*>(new NyeCrevasseDamageIBC(a_nyeFloorMaskMin));
      }

#if 0
    else if (damageType == "evolutionTest")
      {

	EvolutionTestMuCoefficientIBC* damageIBCptr = new EvolutionTestMuCoefficientIBC();
        ParmParse damagePP("damage");
        std::string initType = "constant";
        damagePP.query("initial_type",initType);     
        if (initType == "constant")
          {
            Real initialVal = 1.0;
            damagePP.query("initial_value", initialVal);
	    damageIBCptr->setInitType(initType);
          }
        else if (initType == "damageStripe")
          {
            Real initialVal = 1.0;
            damagePP.query("initial_value", initialVal);
	    damageIBCptr->setInitType(initType);
          }
        else 
          {
            MayDay::Error("undefined damage initialization in inputs");
          }
      }
#endif

#ifdef HAVE_PYTHON
    else if (damageType == "Python")
      {
	ParmParse pyPP("PythonDamageIBC");
	std::string module;
	pyPP.get("module",module);
	std::string funcName = "damage";
	pyPP.query("function",funcName);
	ptr =  static_cast<DamageIBC*>
	  (new PythonInterface::PythonDamageIBC(module, funcName));
      }
#endif
    else
      {
	MayDay::Error("undefined DamageIBC in inputs");
      }
  
  return ptr;
  
}


/// set damageSource term 
void
DamageIBC::setDamageSrc(DamageSrc* a_damageSrc)
{
  if (m_damageSrcPtr != NULL)
    {
      delete m_damageSrcPtr;
      m_damageSrcPtr = NULL;
    }
  m_damageSrcPtr = a_damageSrc->new_damageSrc();
}

/// get source term for mu coefficient (partial time derivative)
void
DamageIBC::getDamageSource(LevelData<FArrayBox>& a_damage,
                           const LevelSigmaCS& a_coordSys,
                           const AmrIce* a_amrIcePtr,
                           int a_level,
                           LevelData<FArrayBox>& levelSTS,
                           LevelData<FArrayBox>& levelBTS,
                           Real a_time,
                           Real a_dt,
                           Real eps)
{
  // if not defined, set source term to zero
  if (m_damageSrcPtr == NULL)
    {
      DataIterator dit = a_damage.dataIterator();
      for (dit.begin(); dit.ok(); ++dit)
        {
          a_damage[dit].setVal(0.0);
        }      
    } 
  else
    {
      m_damageSrcPtr->getDamageSource(a_damage, a_coordSys,
                                      a_amrIcePtr, a_level, 
                                      levelSTS, levelBTS,
                                      a_time, a_dt, eps);
    }
}




/// Set boundary fluxes
/**
   default implementation has Dirichlet and Neumann BCs
*/
void
DamageIBC::primBC(FArrayBox&            a_WGdnv,
                  const FArrayBox&      a_Wextrap,
                  const FArrayBox&      a_W,
                  const int&            a_dir,
                  const Side::LoHiSide& a_side,
                  const Real&           a_time)
{
  // (DFM -- 2/11/18): this is copied directly from MarineIBC.cpp
  
  // do nothing in periodic case
  if (!m_domain.isPeriodic(a_dir))
    {    
      int lohisign;
      Box tmp = a_WGdnv.box();
      
      // Determine which side and thus shifting directions
      lohisign = sign(a_side);
      tmp.shiftHalf(a_dir,lohisign);
      
      // (DFM - 5/28/10) this little dance with the ghostBox is a bit 
      // of a kluge to handle the case where a_WGdnv has more than one layer   
      // of ghosting, in which case just testing agains tmp isn't 
      // sufficient to determine whether you're up against the domain edge
      Box ghostBox;
      if (a_side == Side::Lo)
        {
          ghostBox = adjCellLo(m_domain.domainBox(),a_dir, 1);
        }
      else
        {
          ghostBox = adjCellHi(m_domain.domainBox(),a_dir, 1);
        }
      ghostBox &= tmp;

      // Is there a domain boundary next to this grid
      if (!ghostBox.isEmpty() && !m_domain.contains(tmp))
        {
          tmp &= m_domain;
          
          Box boundaryBox;
          
          if (a_side == Side::Lo)
            {
              boundaryBox = bdryLo(tmp,a_dir);
            }
          else
            {
              boundaryBox = bdryHi(tmp,a_dir);
            }
          
          // Set the boundary values
	  //          a_WGdnv.setVal(m_thickness, boundaryBox, 0, 1);
	  BoxIterator bit(boundaryBox);
	  for (bit.begin(); bit.ok(); ++bit){
	    const IntVect& i = bit();
	    a_WGdnv(i,0) = std::max(0.0,a_Wextrap(i,0));
	  }

        }
    }
  
}



/////////////////////////////////////////////////////////////////////
/// ZeroDamageIBC
/////////////////////////////////////////////////////////////////////


DamageIBC* ZeroDamageIBC::new_damageIBC() const
{
  ZeroDamageIBC* ptr = new ZeroDamageIBC();
  if (m_damageSrcPtr != NULL)
    {
      ptr->setDamageSrc(m_damageSrcPtr);
    }
  return static_cast<DamageIBC*>(ptr);

}


void ZeroDamageIBC::setDamage(LevelData<FArrayBox>& a_damage,
                              const LevelSigmaCS& a_coordSys,
                              const AmrIce* a_amrIcePtr,
                              int a_level,
                              Real a_time,
                              Real a_dt)
{
  for (DataIterator dit = a_damage.dataIterator(); dit.ok(); ++dit)
    {
      a_damage[dit].setVal(0.0);
    }
}


DamageIBC* ConstantDamageIBC::new_damageIBC() const
{
  ConstantDamageIBC* ptr = new ConstantDamageIBC();
  if (m_damageSrcPtr != NULL)
    {
      ptr->setDamageSrc(m_damageSrcPtr);
    }
  return static_cast<DamageIBC*>(ptr);

}


void ConstantDamageIBC::setDamage(LevelData<FArrayBox>& a_damage,
                              const LevelSigmaCS& a_coordSys,
                              const AmrIce* a_amrIcePtr,
                              int a_level,
                              Real a_time,
                              Real a_dt)
{
  // Read in an initial constant damage value
  ParmParse dPP("damage");
  Real damageInit = 0.0;
  dPP.query("initial_value", damageInit);

  // ice thickness -- set damage to zero where there's no ice.
  const LevelData<FArrayBox>& iceThickness = a_coordSys.getH();
  Real thicknessEps = 1e-8;
  for (DataIterator dit = a_damage.dataIterator(); dit.ok(); ++dit)
    {
      a_damage[dit].setVal(damageInit);

      // set damage to zero where there is no ice.
      Box testBox = a_damage[dit].box();
      testBox &= iceThickness[dit].box();
      BoxIterator bit(testBox);
      for (bit.begin(); bit.ok(); ++bit)
        {
          IntVect iv = bit();
          if (iceThickness[dit](iv,0) < thicknessEps)
            {
              a_damage[dit](iv,0) = 0.0;
            }
        }
    }
}


DamageIBC* AxbyDamageIBC::new_damageIBC() const
{

  AxbyDamageIBC* newPtr = new AxbyDamageIBC(m_a, m_x,m_b, m_y);
  newPtr->setDamageSrc(m_damageSrcPtr);
  return static_cast<DamageIBC*>(newPtr);
}

AxbyDamageIBC::AxbyDamageIBC
(const Real& a_a, DamageIBC* a_x, 
 const Real& a_b, DamageIBC* a_y)
{

  m_a = a_a;
  m_b = a_b;
  
  CH_assert(a_x != NULL);
  CH_assert(a_y != NULL);
  m_x = a_x->new_damageIBC();
  m_y = a_y->new_damageIBC();
  CH_assert(m_x != NULL);
  CH_assert(m_y != NULL);

}

AxbyDamageIBC::~AxbyDamageIBC()
{
  if (m_x != NULL)
    {
      delete m_x; m_x = NULL;
    }
  if (m_y != NULL)
    {
      delete m_y; m_y = NULL;
    }
}

void AxbyDamageIBC::setDamage(LevelData<FArrayBox>& a_cellMuCoef,
                              const LevelSigmaCS& a_coordSys,
                              const AmrIce* a_amrIcePtr,
                              int a_level,
                              Real a_time,
                              Real a_dt)
{
  
  LevelData<FArrayBox> y_mu(a_cellMuCoef.disjointBoxLayout(),1,a_cellMuCoef.ghostVect());
  m_x->setDamage(a_cellMuCoef, a_coordSys, a_amrIcePtr, a_level, a_time, a_dt);
  m_y->setDamage(y_mu, a_coordSys, a_amrIcePtr, a_level, a_time, a_dt);
  for (DataIterator dit(a_cellMuCoef.disjointBoxLayout()); dit.ok(); ++dit)
    {
      a_cellMuCoef[dit].axby(a_cellMuCoef[dit],y_mu[dit],m_a,m_b);
    }

}



DamageIBC* LevelDataDamageIBC::new_damageIBC() const
{
  LevelDataDamageIBC* newPtr = new LevelDataDamageIBC(m_damage, m_dx);
  newPtr->setDamageSrc(m_damageSrcPtr);
  return static_cast<DamageIBC*>(newPtr);

}
void LevelDataDamageIBC::setDamage(LevelData<FArrayBox>& a_cellMuCoef,
                                   const LevelSigmaCS& a_coordSys,
                                   const AmrIce* a_amrIcePtr,
                                   int a_level,
                                   Real a_time,
                                   Real a_dt)
{

  for (DataIterator dit = a_cellMuCoef.dataIterator(); dit.ok(); ++dit)
    {
      a_cellMuCoef[dit].setVal(1.0);
      
    }

  FillFromReference(a_cellMuCoef, *m_damage, a_coordSys.dx(),m_dx,m_verbose);
  
   for (int dir = 0; dir < SpaceDim; ++dir)
    {
      const ProblemDomain domain = a_cellMuCoef.disjointBoxLayout().physDomain();
      if (!(domain.isPeriodic(dir)))
	{
	  ReflectGhostCells(a_cellMuCoef, domain, dir, Side::Lo);
	  ReflectGhostCells(a_cellMuCoef, domain, dir, Side::Hi);
	}
    }
}

DamageIBC* MultiLevelDataDamageIBC::new_damageIBC() const
{
  MultiLevelDataDamageIBC* newPtr = new MultiLevelDataDamageIBC(m_damage, m_dxCrse, m_ratio);
  newPtr->setDamageSrc(m_damageSrcPtr);
  return static_cast<DamageIBC*>(newPtr);

}


void MultiLevelDataDamageIBC::setDamage(LevelData<FArrayBox>& a_cellMuCoef,
                                        const LevelSigmaCS& a_coordSys,
                                        const AmrIce* a_amrIcePtr,
                                        int a_level,
                                        Real a_time,
                                        Real a_dt) 
{     
  setDamage(a_cellMuCoef,a_coordSys, a_amrIcePtr, a_level, 
            a_coordSys.dx(),a_time,a_dt);   
}

void MultiLevelDataDamageIBC::setDamage(LevelData<FArrayBox>& a_cellMuCoef,
                                        const LevelSigmaCS& a_coordSys,
                                        const AmrIce* a_amrIcePtr,
                                        int a_level,
                                        RealVect a_dx,
                                        Real a_time,
                                        Real a_dt)
{
  
  Vector<RealVect> refDx (m_damage.size(), -1.0*RealVect::Unit);
  refDx[0] = m_dxCrse;
  for (int lev=1; lev<refDx.size(); lev++)
    {
      refDx[lev] = refDx[lev-1]/m_ratio[lev-1];
    }

  flattenCellData(a_cellMuCoef,
                  a_dx,
                  m_damage,
                  refDx,
                  m_verbose);
  

  for (int dir = 0; dir < SpaceDim; ++dir)
    {
      const ProblemDomain domain = a_cellMuCoef.disjointBoxLayout().physDomain();
      if (!(domain.isPeriodic(dir)))
	{
	  ReflectGhostCells(a_cellMuCoef, domain, dir, Side::Lo);
	  ReflectGhostCells(a_cellMuCoef, domain, dir, Side::Hi);
	}
    }

  
}


/////////////////////////////////////////////////////////////////////
/// EvolutionTestMuCoefficentIBC
/////////////////////////////////////////////////////////////////////


DamageIBC* EvolutionTestDamageIBC::new_damageIBC() const
{
  EvolutionTestDamageIBC* ptr = new EvolutionTestDamageIBC();
  if (m_damageSrcPtr != NULL)
    {
      ptr->setDamageSrc(m_damageSrcPtr);
    }
  ptr->m_initType = m_initType;
  return static_cast<DamageIBC*>(ptr);

}


void EvolutionTestDamageIBC::setDamage(LevelData<FArrayBox>& a_cellMuCoef,
                                       const LevelSigmaCS& a_coordSys,
                                       const AmrIce* a_amrIcePtr,
                                       int a_level,
                                       Real a_time,
                                       Real a_dt)
{
  if (m_initType == "constant")
    {
      ParmParse damagepp("damage");
      Real initialVal = 1.0;
      damagepp.query("initial_value", initialVal);      
  
      for (DataIterator dit = a_cellMuCoef.dataIterator(); dit.ok(); ++dit)
	{
	  a_cellMuCoef[dit].setVal(initialVal);
	}
    }
  else if (m_initType == "damageStripe")
    {
      ParmParse damagepp("damage");
      Real outer_value = 1.0;
      damagepp.query("outer_value", outer_value);
      
      Real stripe_value = 1.0;
      damagepp.query("stripe_value", stripe_value);

      RealVect stripeLo;
      Vector<Real> stripeLoVect(SpaceDim);
      damagepp.getarr("stripe_lo", stripeLoVect, 0, SpaceDim);
      stripeLo = RealVect(D_DECL(stripeLoVect[0], stripeLoVect[1], stripeLoVect[2]));

      RealVect stripeHi;
      Vector<Real> stripeHiVect(SpaceDim);
      damagepp.getarr("stripe_hi", stripeHiVect, 0, SpaceDim);
      stripeHi = RealVect(D_DECL(stripeHiVect[0], stripeHiVect[1], stripeHiVect[2]));
      
      RealVect dx = a_coordSys.dx();
      
      for (DataIterator dit = a_cellMuCoef.dataIterator(); dit.ok(); ++dit)
	{
	  FArrayBox& thisDamage = a_cellMuCoef[dit];
	  BoxIterator bit(thisDamage.box());
	  for (bit.begin(); bit.ok(); ++bit)
	    {
	      IntVect iv = bit();
	      // this is a bit inexact 
	      RealVect loc = iv;
	      loc *= dx;
	      if ((loc >= stripeLo) && (loc <= stripeHi))
		{
		  thisDamage(iv,0) = stripe_value;
		}
	      else
		{
		  thisDamage(iv,0) = outer_value;
		}
	    }	  
	}
    }  
  else
    {
      MayDay::Error("EvolutionTestDamageIBC -- bad initialization type");
    }

}

/////////////////////////////////////////////////////////////////////
/// ZeroDamageIBC
/////////////////////////////////////////////////////////////////////


DamageIBC* NyeCrevasseDamageIBC::new_damageIBC() const
{
  NyeCrevasseDamageIBC* ptr = new NyeCrevasseDamageIBC(m_nyeFloorMaskMin);
  if (m_damageSrcPtr != NULL)
    {
      ptr->setDamageSrc(m_damageSrcPtr);
    }
  return static_cast<DamageIBC*>(ptr);

}


void NyeCrevasseDamageIBC::setDamage(LevelData<FArrayBox>& a_damage,
				     const LevelSigmaCS& a_coordSys,
				     const AmrIce* a_amrIcePtr,
				     int a_level,
				     Real a_time,
				     Real a_dt)

{
  // set damage to zero, then pass into modifyDamage, which computes the Nye value as a floor
  DataIterator dit = a_damage.dataIterator();
  for (dit.begin(); dit.ok(); ++dit)
    {
      a_damage[dit].setVal(0.0);
    }
  
  modifyDamage(a_damage, a_coordSys, a_amrIcePtr, a_level, a_time, a_dt);
}


// sets damage to be the min of the existing damage and the Nye crevasse depth
void NyeCrevasseDamageIBC::modifyDamage(LevelData<FArrayBox>& a_damage,
                                        const LevelSigmaCS& a_coordSys,
                                        const AmrIce* a_amrIcePtr,
                                        int a_level,
                                        Real a_time,
                                        Real a_dt)
{
  Real dx = a_amrIcePtr->amrDx()[a_level];
  const DisjointBoxLayout levelGrids = a_amrIcePtr->amrGrids()[a_level];
  const ProblemDomain& domain = levelGrids.physDomain();
  
  // gather what we need for this level

  // ice thickness...
  const LevelData<FArrayBox>& iceThickness = a_coordSys.getH();
  // effective ice thickness is the cell-averaged value divided by the ice area fraction
  LevelData<FArrayBox> effectiveH(iceThickness.getBoxes(), 1, iceThickness.ghostVect());
  a_amrIcePtr->computeEffectiveIceThickness(effectiveH, a_level);

  // ice fraction mask
  const LevelData<FArrayBox>& iceMask = *a_amrIcePtr->iceMask(a_level);

  // bottom topography
  const LevelData<FArrayBox>& topography = a_coordSys.getTopography();

  // densities and sea level
  Real iceDensity = a_coordSys.iceDensity();
  Real waterDensity = a_coordSys.waterDensity();
  Real seaLevel = a_coordSys.seaLevel();
  Real gravity = a_coordSys.gravity();
  
  // ice velocities...
  // assume that ghost-cell values for velocity have been set.
  // (otherwise we'll need to do coarse-fine interpolation, etc)
  const LevelData<FArrayBox>& iceVel = *a_amrIcePtr->velocity(a_level);
  //  undamaged ice viscosity -- use one less than velocity ghost
  IntVect muGhost = iceVel.ghostVect();
  muGhost -= IntVect::Unit;
  LevelData<FArrayBox> mu(levelGrids, 1, muGhost);

  ConstitutiveRelation* constRelPtr = a_amrIcePtr->getConstitutiveRelation();

  // need to cast away const-ness for getA
  AmrIce* nonConstAmrIcePtr = const_cast<AmrIce*>(a_amrIcePtr);

  const LevelData<FArrayBox>& A = nonConstAmrIcePtr->getA(a_level);

#if 0
  // need a face-centered A for computeFaceMu
  LevelData<FluxBox> A_face(A.getBoxes(), A.nComp(), A.ghostVect());
  CellToEdge(A,A_face);
#endif
  
  // non-const only because we will need to set coarse-fine BC's, but still
  // need to explicitly cast away the const-ness
  LevelData<FArrayBox>& nonConstVel = *(const_cast<LevelData<FArrayBox>*>(&iceVel));

  // coarse-fine boundary-condition stuff -- need coarser level if it exists
  LevelData<FArrayBox>* crseVelPtr = NULL;
  // nRefCrse will be refinement ratio to next coarser-level, if we're on a refined level
  int nRefCrse = -1;
  if (a_level > 0)
    {
      crseVelPtr  = const_cast<LevelData<FArrayBox>*>(a_amrIcePtr->velocity(a_level-1));
      nRefCrse = a_amrIcePtr->refRatios()[a_level-1];
    }

  // will need velocity gradients
  LevelData<FArrayBox> gradU(levelGrids, SpaceDim*SpaceDim, muGhost);

  // for now, compute gradU the easy (but slightly inefficient) way using the
  // ConstitutiveRelation function which computes the strain rate invariant while
  // also returning the velocity gradients. The alternative is to simply compute
  // the gradients. We can also eventually factor the gradient computation into
  // a separate function
  // note that I'm using the storage I've already allocated for mu as a temporary

  if (a_level > 0)
    {
      // may need to set coarse-fine boundary conditions on velocity.
      // this class does quadratic interpolation between coarse- and fine-level data
      // to fill ghost cells on fine levels at coarse-fine interfaces
      QuadCFInterp interpolator(nonConstVel.getBoxes(), &crseVelPtr->getBoxes(),
				dx, nRefCrse, SpaceDim, domain);
      interpolator.coarseFineInterp(nonConstVel, *crseVelPtr);
    }
				
  // modify velocity field to extend into first empty cell adjacent to calving fronts
  //const LevelData<BaseFab<int> >& floatingMask = a_coordSys.getFloatingMask();
  
  LevelData<FArrayBox> tempVel(nonConstVel.getBoxes(), nonConstVel.nComp(),
                               nonConstVel.ghostVect());


  DamageUtils::extendVelocityAtCalvingFronts(tempVel, nonConstVel,
                                             iceThickness);
 
  // Call computeStrainRateInvariant strictly to extract gradU, which is computed in this
  // function as a byproduct
  //  constRelPtr->computeStrainRateInvariant(mu,gradU,nonConstVel,crseVelPtr,
  //nRefCrse, a_coordSys, muGhost);

  constRelPtr->computeStrainRateInvariant(mu, gradU, tempVel, crseVelPtr,
                                          nRefCrse, a_coordSys, muGhost);  
					  

  // now compute the viscosity. Lots of redundant computation here (gradU, etc).
  //constRelPtr->computeMu(mu, nonConstVel, crseVelPtr, nRefCrse, A,
  //a_coordSys, domain, muGhost);

  constRelPtr->computeMu(mu, tempVel, crseVelPtr, nRefCrse, A,
			 a_coordSys, domain, muGhost);  
  
  // set up to compute on a box-by-box basis...
  
  // locate specific components of the velocity gradients in the multicomponent gradU arrays.
  // the derivComponent function is in LevelMappedDerivatives.H
  int dudxComp = derivComponent(0,0);
  int dudyComp = derivComponent(1,0);
  int dvdxComp = derivComponent(0,1);
  int dvdyComp = derivComponent(1,1);

  // now loop over individual boxes on this processor
  DataIterator dit = levelGrids.dataIterator();
  for (dit.begin(); dit.ok(); ++dit)
    {
      // valid region box for this patch
      const Box& thisBox = levelGrids[dit];

      // this is copied extensively from DamageConsitutiveRelation.cpp in the public branch
      // working with strain rates e here
      // first compute e + I*tr(e)
      FArrayBox ee(thisBox, SpaceDim*SpaceDim);

      // this is a call to a fortran subroutine using the ChomboFortran macros
      // which automates dimensionality (2D, 3D, etc) and the C++/fortran interface
      FORT_UPLUSUT(CHF_FRA(ee), 
		    CHF_CONST_FRA(gradU[dit]),
		    CHF_INT(dudxComp),
		    CHF_INT(dudyComp),
		    CHF_INT(dvdxComp),
		    CHF_INT(dvdyComp),
		    CHF_BOX(thisBox));
      
      //2.0* (2.0e + 2.0*I*tr(e))
//      ee *= 2.0;
      
      //now compute principal strain rate components
      FArrayBox lambda(thisBox, SpaceDim);
      FORT_SYMTEIGEN(CHF_FRA(lambda), 
		     CHF_CONST_FRA(ee),
		     CHF_INT(dudxComp),
		     CHF_INT(dudyComp),
		     CHF_INT(dvdxComp),
		     CHF_INT(dvdyComp),
		     CHF_BOX(thisBox));
      
      
      //convert from principal strain to principal stress components
//      lambda.mult(mu[dit],0,0,1); // only need the first principal stress, so only multiply the first component 
      
      //vertical integration (FIXME what do in future 3D problems?)
      // (DFM 5/3/18) -- this version uses vertically-averaged stresses
      //lambda.mult(iceThickness[dit],0,0,1);
  
      Real eps = 1.0e-10; // minimum denominator
      
      FArrayBox thckab(thisBox,1);
      FORT_THICKNESSOVERFLOTATION(CHF_FRA1(thckab,0),
				  CHF_CONST_FRA1(effectiveH[dit],0),
				  CHF_CONST_FRA1(topography[dit],0),
				  CHF_CONST_REAL(iceDensity),
				  CHF_CONST_REAL(waterDensity),
				  CHF_CONST_REAL(seaLevel),
				  CHF_BOX(thisBox));
  
      Real maxDamage = DAMAGE_MAX_VAL;
      FArrayBox damageTemp(a_damage[dit].box(), a_damage.nComp());

      damageTemp.setVal(0.0);

//      FORT_NYECREVASSEDEPTHTP(CHF_FRA1(damageTemp,0), 
//                              CHF_CONST_FRA1(depthw,0),
//                              CHF_CONST_FRA1(effectiveH[dit],0),
//                              CHF_CONST_FRA1(lambda,0),
//                              CHF_CONST_FRA1(thckab,0),
//                              CHF_CONST_REAL(iceDensity),
//                              CHF_CONST_REAL(waterDensity),
//                              CHF_CONST_REAL(gravity),
//                              CHF_CONST_REAL(eps),
//                              CHF_CONST_REAL(maxDamage),
 
      // finally -- we just computed the pointwise value. Need to convert it to the 
      // cell averaged value by multiplying by the ice area fraction (which is the fraction of the
      // cell covered by ice)

      // (this wasn't correct...)
      // We just computed the vertically-integrated value, so divide by thickness to 
      // get actual crevasse depths
      // this is a function from FArrayBox.H in the Chombo library, with arguments 
      // divide(src, srcComp, destComp, numComp)
      // it divides the 0th component (in Chombo, as in most c++, indexing is i=0..n-1) of damage 
      // by the 0th component of iceThickness, and only does the one component.
      //a_damage[dit].divide(iceThickness[dit],0,0,1);

      // this calls the alternate implementation, which doesn't seem to work correctly, which is why 
      // it's commented out.
      FORT_NYEDAMAGE(CHF_FRA1(damageTemp,0), 
                     CHF_CONST_FRA1(effectiveH[dit],0),
                     CHF_CONST_FRA(lambda),
                     CHF_CONST_FRA1(mu[dit],0),
                     CHF_CONST_FRA1(thckab,0),
                     CHF_CONST_REAL(iceDensity),
                     CHF_CONST_REAL(waterDensity),
                     CHF_CONST_REAL(gravity),
                     CHF_CONST_REAL(eps),
                     CHF_CONST_REAL(maxDamage),
                     CHF_BOX(thisBox));

      // ice mask over the entire AMR level is iceMask -- iceMask on this patch is iceMask[dit]
      damageTemp.mult(iceMask[dit], 0, 0, 1);

      // finally, compute max of a_damage and damageTemp (Nye value)
      // This iterator will loop over all of the cells in damage
      //BoxIterator bit(a_damage[dit].box());
      BoxIterator bit(iceMask[dit].box());
      for (bit.begin(); bit.ok(); ++bit)
        {
          IntVect iv = bit();
          // only use Nye floor in non-partial cells
          Real maskEps = 0.99;
          if (iceMask[dit](iv,0) > m_nyeFloorMaskMin)
            {
              a_damage[dit](iv,0) = Max(a_damage[dit](iv,0), damageTemp(iv,0));
            }
          a_damage[dit](iv,0) = Min(maxDamage, a_damage[dit](iv,0));
        }
    } // end loop over boxes on this processor
  
  
  if (constRelPtr != NULL)
    {
      delete constRelPtr;
    }
}



#include "NamespaceFooter.H"
