#ifdef CH_LANG_CC
/*
*      _______              __
*     / ___/ /  ___  __ _  / /  ___
*    / /__/ _ \/ _ \/  V \/ _ \/ _ \
*    \___/_//_/\___/_/_/_/_.__/\___/
*    Please refer to Copyright.txt, in Chombo's root directory.
*/
#endif

#include "IceTongueIBC.H"
#include "ParmParse.H"
#include "BoxIterator.H"
#include "ExtrapBCF_F.H"
#include "PetscCompGridVTO.H"
#include "IceConstants.H"
#include "ReflectGhostCells.H"
#include "ExtrapGhostCells.H"

#include "NamespaceHeader.H"



// inhomogeneous bc value pointwise function. Might make this a class with a persistent state if calling ParmParse is too costly
Real IceTongueBCvel(RealVect& a_loc, int icomp)
{
  // accessing ParmParse in a pointwise function might be slow. Then again, it might not. It's also the simplest thing to do...
  ParmParse ppIT("iceTongue");
  Real wallWidth = 0.0;
  ppIT.query("wallWidth", wallWidth);


  ParmParse ppCT("confinedTongue");
  Real glVel = 0.0;
  ppCT.query("glvel", glVel);

  ParmParse ppMain("main");
  Vector<Real> domSize(SpaceDim);
  ppMain.getarr("domain_size", domSize, 0, SpaceDim);
  
  Real xlo = wallWidth;
  Real xhi = domSize[1]-wallWidth;
  Real xm = (xhi +xlo)/2.0;
  Real A = (glVel/((xm-xlo)*(xm-xhi)));
  Real B = -1.0*A*(xlo+xhi);
  Real C = A*xlo*xhi;
  Real m = 3.0;
  ppIT.query("exponent", m);

  Real bcVel;
  // x-vel only
  if (icomp == 0)
    {
      // quadratic velocity profile at inflow -- assume this is inflow at x=0 face
      bcVel = max(A*a_loc[1]*a_loc[1] + B*a_loc[1] + C, 0.);
      bcVel = max(glVel*(1-pow(abs((a_loc[1]-xm)/(0.5*(xhi-xlo))),m)), 0.);
      if (m == 0.) {
        bcVel = glVel;
        }
    }     
  else
    {
      bcVel = 0.0;
    }
  return bcVel;
}


void zeroBCValueTongue(Real* pos,
                       int* dir,
                       Side::LoHiSide* side,
                       Real* a_values)
{
  // first set all values to zero
  a_values[0] = 0.0;
  a_values[1] = 0.0;
}

void constantBCValueTongue(Real* pos,
                           int* dir,
                           Side::LoHiSide* side,
                           Real* a_values)
{
  // Function corresponding specifically to the confinedTongue test case.
  // Read in the constant velocity value from the input file.
  ParmParse ctPP("confinedTongue");
  Real glvel;
  ctPP.query("glvel",glvel);

  // Set the x values to the specified constant
  a_values[0] = glvel;
  a_values[1] = 0.0;
}

void TongueVelBC(FArrayBox& a_state,
                 const Box& a_valid,
                 const ProblemDomain& a_domain,
                 Real a_dx,
                 bool a_homogeneous)
{
  if(!a_domain.domainBox().contains(a_state.box()))
    {
      Box valid = a_valid;
      for(int dir=0; dir<CH_SPACEDIM; ++dir)
        {
          // don't do anything if periodic
          if (!a_domain.isPeriodic(dir))
            {

              // boundary conditions are Dirichlet on low side,
              // Neumann on high side for dir == 0, and Neumann for dir == 1
              Box ghostBoxLo = adjCellBox(valid, dir, Side::Lo, 1);
              Box ghostBoxHi = adjCellBox(valid, dir, Side::Hi, 1);


              //valid.grow(1);
              //valid.grow(dir,-1);

              if(!a_domain.domainBox().contains(ghostBoxLo))
                {
                  // want to set corners if possible, so grow ghostBox in the 
                  // transverse directions
                  ghostBoxLo.grow(1);
                  ghostBoxLo.grow(dir,-1);


		  if (dir == 0)
		    {
                      // If the confinedTongue test geometry is specified, set the BC value in
                      // the input file. Otherwise, set it to zero.
                      ParmParse mPP("IceTongue");
                      std::string geometry = "temp";
                      mPP.query("geometry",geometry);
                      if (geometry == "confinedTongue")
                        {
		          DiriBC(a_state,
			         valid,
			         a_dx,
			         a_homogeneous,
			         constantBCValueTongue,
			         dir,
			         Side::Lo);
                        }
                      else
                        {
		          DiriBC(a_state,
			         valid,
			         a_dx,
			         a_homogeneous,
			         zeroBCValueTongue,
			         dir,
			         Side::Lo);
                        }
		    } 
		  else 
		    {
		      Interval NeumInterval(0,SpaceDim-1);
		      NeumBC(a_state,
			     valid,
			     a_dx,
			     a_homogeneous,
			     zeroBCValueTongue,
			     dir,
			     Side::Lo,
			     NeumInterval);

		    }
                }

              if(!a_domain.domainBox().contains(ghostBoxHi))
                {
                  // want to set corners if possible, so grow ghostBox in the 
                  // transverse directions
                  ghostBoxHi.grow(1);
                  ghostBoxHi.grow(dir,-1);

		  Interval NeumInterval(0,SpaceDim-1);
		  NeumBC(a_state,
                          valid,
                          a_dx,
                          a_homogeneous,
                          zeroBCValueTongue,
                          dir,
                          Side::Hi,
                          NeumInterval);

                }

            } // end if is not periodic in ith direction
        }
    }
}


// CompGridVTOBC
void 
CompGridVTOBCspecific::createCoefs()
{  
  m_isDefined=true;
  // is this needed ?
  m_Rcoefs[0] = -1.;
}

// 
void 
CompGridVTOBCspecific::operator()( FArrayBox&           a_state,
                                   const Box&           a_valid,
                                   const ProblemDomain& a_domain,
                                   Real                 a_dx,
                                   bool                 a_homogeneous)
{
  const Box& domainBox = a_domain.domainBox();
  for (int idir = 0; idir < SpaceDim; idir++)
    {
      if (!a_domain.isPeriodic(idir))
        {
          for (SideIterator sit; sit.ok(); ++sit)
            {
              Side::LoHiSide side = sit();              
              if (a_valid.sideEnd(side)[idir] == domainBox.sideEnd(side)[idir])
                {
                  // Dirichlet BC
                  int isign = sign(side);
                  Box toRegion = adjCellBox(a_valid, idir, side, 1);
                  // include corner cells if possible by growing toRegion in transverse direction
                  toRegion.grow(1);
                  toRegion.grow(idir, -1);
                  toRegion &= a_state.box();
                  for (BoxIterator bit(toRegion); bit.ok(); ++bit)
                    {
                      IntVect ivTo = bit();                     
                      IntVect ivClose = ivTo - isign*BASISV(idir);
                      for (int ighost=0;ighost<m_nGhosts[0];ighost++,ivTo += isign*BASISV(idir))
                        {
                          //for (int icomp = 0; icomp < a_state.nComp(); icomp++) a_state(ivTo, icomp) = 0.0;
                          IntVect ivFrom = ivClose;
                          
                          // hardwire to linear BCs for now
                          for (int icomp = 0; icomp < a_state.nComp() ; icomp++)
                            {
                              if (m_bcDiriAnalytic[idir][side][icomp])
                                {
                                  RealVect loc = a_dx*ivFrom;
                                  Real bcVal = 0.0;
                                  if (!a_homogeneous)
                                    {
                                      bcVal = IceTongueBCvel(loc, icomp);
                                    }
                                  // linear
                                  a_state(ivTo, icomp) = 2.0*bcVal  - a_state(ivFrom, icomp);
                                }
                              else if (m_bcDiri[idir][side][icomp]) 
                                {
                                  // homogeneous BC value
                                  a_state(ivTo, icomp) = (-1.0)*a_state(ivFrom, icomp);
                                }
                              else 
                                {
                                  a_state(ivTo, icomp) = (1.0)*a_state(ivFrom, icomp);
                                }
                            }   
                        }
                    } // end loop over cells
                } // if ends match
            } // end loop over sides
        } // if not periodic in this direction
    } // end loop over directions    
}




// Indicate that define() hasn't been called
// set default thickness at domain edge to be zero
IceTongueIBC::IceTongueIBC() 
{
  m_isBCsetUp = false;
  m_paramsSet = false;
  m_isDefined = false;
}

IceTongueIBC::~IceTongueIBC()
{
}


/// Define the object
/**
   Set the problem domain index space and the grid spacing for this
   initial and boundary condition object. Just calls base-class define
*/
void
IceTongueIBC::define(const ProblemDomain& a_domain,
                      const Real&          a_dx)
{
  PhysIBC::define(a_domain, a_dx);
}

void
IceTongueIBC::setParameters(RefCountedPtr<RealFunction<RealVect > > a_thicknessFunction,
                            RefCountedPtr<RealFunction<RealVect > > a_bedrockFunction,
                            Vector<RefCountedPtr<RealFunction<RealVect > > > a_velBCFunctionLo,
                            Vector<RefCountedPtr<RealFunction<RealVect > > > a_velBCFunctionHi,                            
                            const Real& a_seaLevel)
{
  Vector< RefCountedPtr<RealFunction<RealVect > > > bedrockFuncVect(1, a_bedrockFunction);
  
  setParameters(a_thicknessFunction, bedrockFuncVect, a_velBCFunctionLo, a_velBCFunctionHi, a_seaLevel);

}

void
IceTongueIBC::setParameters(RefCountedPtr<RealFunction<RealVect > > a_thicknessFunction,
                            Vector<RefCountedPtr<RealFunction<RealVect > > > a_bedrockFunction,
                            Vector<RefCountedPtr<RealFunction<RealVect > > > a_velBCFunctionLo,
                            Vector<RefCountedPtr<RealFunction<RealVect > > > a_velBCFunctionHi,
                            const Real& a_seaLevel)
{
  m_bedrockFunction = a_bedrockFunction;
  m_thicknessFunction = a_thicknessFunction;
  m_velBCFunctionLo = a_velBCFunctionLo;
  m_velBCFunctionHi = a_velBCFunctionHi;
  m_seaLevel = a_seaLevel;

  ParmParse ppBC("bc");
  // finally, do we modify mask values along domain edges?
  m_setGroundedMaskLo.resize(SpaceDim,0);
  m_setGroundedMaskHi.resize(SpaceDim,0);
  ppBC.queryarr("set_grounded_mask_lo", m_setGroundedMaskLo, 0, SpaceDim);
  ppBC.queryarr("set_grounded_mask_hi", m_setGroundedMaskHi, 0, SpaceDim);
  
  m_paramsSet = true;

}


/// Factory method - this object is its own factory
/**
   Return a pointer to a new PhysIBC object with m_isDefined = false (i.e.,
   its define() must be called before it is used).
*/
IceThicknessIBC* 
IceTongueIBC::new_thicknessIBC()
{
  IceTongueIBC* retval = new IceTongueIBC();

  retval->m_thicknessFunction = m_thicknessFunction;
  retval->m_bedrockFunction = m_bedrockFunction;
  retval->m_velBCFunctionLo = m_velBCFunctionLo;
  retval->m_velBCFunctionHi = m_velBCFunctionHi;    
  retval->m_seaLevel = m_seaLevel;
  retval->m_paramsSet = true;
  retval->m_isDefined = m_isDefined;
  retval->m_velBCs = m_velBCs;
  retval->m_isBCsetUp = m_isBCsetUp;

  retval->m_setGroundedMaskLo = m_setGroundedMaskLo;
  retval->m_setGroundedMaskHi = m_setGroundedMaskHi;
  
  return static_cast<IceThicknessIBC*>(retval);
}

/// Set up initial conditions
/**
 */
void
IceTongueIBC::initialize(LevelData<FArrayBox>& a_U)
{
  /// shouldn't be here...
  MayDay::Error("IceTongueIBC::initialize not implemented");
}

/// Set boundary fluxes
/**
 */
void 
IceTongueIBC::primBC(FArrayBox&            a_WGdnv,
                     const FArrayBox&      a_Wextrap,
                     const FArrayBox&      a_W,
                     const int&            a_dir,
                     const Side::LoHiSide& a_side,
                     const Real&           a_time)
{
  // do nothing in periodic case
  if (!m_domain.isPeriodic(a_dir))
    {    
      int lohisign;
      Box tmp = a_WGdnv.box();
      
      // Determine which side and thus shifting directions
      lohisign = sign(a_side);
      tmp.shiftHalf(a_dir,lohisign);
      
      // (DFM - 5/28/10) this little dance with the ghostBox is a bit 
      // of a kluge to handle the case where a_WGdnv has more than one layer   
      // of ghosting, in which case just testing agains tmp isn't 
      // sufficient to determine whether you're up against the domain edge
      Box ghostBox;
      if (a_side == Side::Lo)
        {
          ghostBox = adjCellLo(m_domain.domainBox(),a_dir, 1);
        }
      else
        {
          ghostBox = adjCellHi(m_domain.domainBox(),a_dir, 1);
        }
      ghostBox &= tmp;

      // Is there a domain boundary next to this grid
      if (!ghostBox.isEmpty() && !m_domain.contains(tmp))
        {
          tmp &= m_domain;
          
          Box boundaryBox;
          
          if (a_side == Side::Lo)
            {
              boundaryBox = bdryLo(tmp,a_dir);
            }
          else
            {
              boundaryBox = bdryHi(tmp,a_dir);
            }
          
          // Set the boundary values
	  //          a_WGdnv.setVal(m_thickness, boundaryBox, 0, 1);
	  BoxIterator bit(boundaryBox);
	  for (bit.begin(); bit.ok(); ++bit){
	    const IntVect& i = bit();
	    a_WGdnv(i,0) = std::max(0.0,a_Wextrap(i,0));
	  }

        }
    }
  
}

/// Set boundary slopes
/**
   The boundary slopes in a_dW are already set to one sided difference
   approximations.  If this function doesn't change them they will be
   used for the slopes at the boundaries.
*/

void 
IceTongueIBC::setBdrySlopes(FArrayBox&       a_dW,
                            const FArrayBox& a_W,
                            const int&       a_dir,
                            const Real&      a_time)
{
  // one-sided differences sounds fine with me, so do nothing...
}

/// Adjust boundary fluxes to account for artificial viscosity
/**
 */
void 
IceTongueIBC::artViscBC(FArrayBox&       a_F,
                        const FArrayBox& a_U,
                        const FArrayBox& a_divVel,
                        const int&       a_dir,
                        const Real&      a_time)
{
  // don't anticipate being here -- if we wind up here, need to
  // give it some thought
  MayDay::Error("IceTongueIBC::artViscBC not implemented");
}


/// return boundary condition for Ice velocity solve
/** eventually would like this to be a BCHolder
 */
RefCountedPtr<CompGridVTOBC>
IceTongueIBC::velocitySolveBC()
{
  
  if (!m_isBCsetUp)
    {
      setupBCs();
    }
  
  //  BCFunction* thisBC = dynamic_cast<BCFunction*>(&(*(m_velBCs)));
  return m_velBCs;
}

#if 0
/// if appropriate, modify velocity solve RHS in a problem-dependent way. 
/** 
    add a momemtum source s[dir] = 1/Dx * 0.5 *  ri/rw * (ri - rw) * g * H^2
    to the rhs[dir] at the high dir boundary (1D or 2D cases), or 
    s[dir] = - 1/Dx * ri/rw * (ri - rw) * g * H (3D case) , which is equvalent 
    to setting the momentum flux through the surface (with unit normal n)  
    T.n n = s n

    currently, dir = 0 only

*/
void
IceTongueIBC::modifyVelocityRHS(LevelData<FArrayBox>& a_rhs,
                                LevelSigmaCS& a_coords,
                                const ProblemDomain& a_domain,
                                Real a_time, Real a_dt)
{
  const DisjointBoxLayout& grids = a_coords.grids();
  const LevelData<FArrayBox>& H = a_coords.getH();    

  for (int dir=0; dir<1; dir++)
    {
     
      // incorrect for 3D, for now
      CH_assert(SpaceDim < 3);

      if (!a_domain.isPeriodic(dir))
        {
          // row of cells just inside domain
          Box edgeBox = adjCellHi(a_domain.domainBox(), dir, -1);
          const Real& Dx = a_coords.dx()[dir];
                  
          DataIterator dit = grids.dataIterator();
          for (dit.begin(); dit.ok(); ++dit)
            {              
              Box intersectBox(grids[dit]);
              intersectBox &= edgeBox;
              if (!intersectBox.isEmpty())
                {
                  // for now, use cell-centered values
                  // (probably want to revisit this later)
		  
                  const FArrayBox& thisH = H[dit];
		  Real f = 0.5 * a_coords.gravity()*a_coords.iceDensity()/a_coords.waterDensity() * 
		    (a_coords.iceDensity() - a_coords.waterDensity()) / Dx;

		  for (BoxIterator bit(intersectBox); bit.ok(); ++bit){

		    a_rhs[dit](bit(),dir) = f *  std::pow(thisH(bit()),2); 
		  }
                } // end if this box abuts non-periodic high domain boundary
            } // end loop over grids
	} // end if not periodic in this direction  
    } // end loop over directions
}
#endif
/// set non-periodic ghost cells for thickness & topography, 
/** reflection */
void
IceTongueIBC::setGeometryBCs(LevelSigmaCS& a_coords,
                             const ProblemDomain& a_domain,
                             const RealVect& a_dx,
                             Real a_time, Real a_dt)
{
  for (int dir = 0; dir < SpaceDim; ++dir)
    {
      ReflectGhostCells(a_coords.getH(), a_domain, dir, Side::Lo);
      ReflectGhostCells(a_coords.getH(), a_domain, dir, Side::Hi);
      ReflectGhostCells(a_coords.getTopography(), a_domain, dir, Side::Lo);
      ReflectGhostCells(a_coords.getTopography(), a_domain, dir, Side::Hi);
    }

}


/// modify the ice-flotation mask in a problem dependent way
/** 
    For some confined-shelf problems, may want to set mask to be "grounded" at inflow edge
    even though ice is not actually grounded.
*/
void
IceTongueIBC::modifyFlotationMask(LevelData<BaseFab<int> >& a_mask,
                                  LevelSigmaCS& a_coords,
                                  const ProblemDomain& a_domain) const
{
  const DisjointBoxLayout& grids = a_mask.getBoxes();
  for (int dir=0; dir<SpaceDim; dir++)
    {
      // lo
      if (m_setGroundedMaskLo[dir] != 0)
        {
          Box testBox = adjCellLo(a_domain.domainBox(),dir, -1);
          DataIterator dit = grids.dataIterator();
          for (dit.begin(); dit.ok(); ++dit)
            {
              Box intersectionBox = grids[dit];
              intersectionBox &= testBox;
              if (!intersectionBox.isEmpty())
                {
                  a_mask[dit].setVal(GROUNDEDMASKVAL,intersectionBox, 0);
                }
            }          
        }
      // hi
      if (m_setGroundedMaskHi[dir] != 0)
        {
          Box testBox = adjCellHi(a_domain.domainBox(),dir, -1);
          
          DataIterator dit = grids.dataIterator();
          for (dit.begin(); dit.ok(); ++dit)
            {
              Box intersectionBox = grids[dit];
              intersectionBox &= testBox;
              if (!intersectionBox.isEmpty())
                {
                  a_mask[dit].setVal(GROUNDEDMASKVAL,intersectionBox, 0);
                }              
            }          
        }
    }      
}


/// set non-periodic ghost cells for surface height z_s. 
/** reflection */
void
IceTongueIBC::setSurfaceHeightBCs(LevelData<FArrayBox>& a_zSurface,
                                  LevelSigmaCS& a_coords,
                                  const ProblemDomain& a_domain,
                                  const RealVect& a_dx,
                                  Real a_time, Real a_dt)
{

  for (int dir = 0; dir < SpaceDim; ++dir)
    {
      ReflectGhostCells(a_zSurface, a_domain, dir, Side::Lo);
      ReflectGhostCells(a_zSurface, a_domain, dir, Side::Hi);
    }
}

/// set up topography, etc at regrid time
void
IceTongueIBC::regridIceGeometry(LevelSigmaCS& a_coords,
                                const RealVect& a_dx,
                                const RealVect& a_domainSize,
                                const Real& a_time,
                                const LevelSigmaCS* a_crseCoords,
                                const int a_refRatio)
 {
   CH_assert(m_paramsSet);
   const DisjointBoxLayout& grids = a_coords.grids();
   DataIterator dit = grids.dataIterator();
   const RealVect& dx = a_coords.dx();
   LevelData<FArrayBox>& levelZb = a_coords.getTopography();
    for (dit.begin(); dit.ok(); ++dit)
    { 
      FArrayBox& zB = levelZb[dit];
      zB.setVal(0.0);
      BoxIterator bit(zB.box());
      for (bit.begin(); bit.ok(); ++bit)
        {
          IntVect iv = bit();
          RealVect x(iv);
          x += 0.5*RealVect::Unit;
          x *= dx;
          for (int i=0; i<m_bedrockFunction.size(); i++)
            {
              zB(iv,0) += (*(m_bedrockFunction[i]))(x);
            }
        } 
    } // end loop over boxes
 }


/// set up initial ice state  
void
IceTongueIBC::initializeIceGeometry(LevelSigmaCS& a_coords,
                                    const RealVect& a_dx,
                                    const RealVect& a_domainSize,
                                    const Real& a_time,
                                    const LevelSigmaCS* a_crseCoords,
                                    const int a_refRatio)
{

  CH_assert(m_paramsSet);
  a_coords.setSeaLevel(m_seaLevel);
      
  const DisjointBoxLayout& grids = a_coords.grids();

  DataIterator dit = grids.dataIterator();
  const RealVect& dx = a_coords.dx();

  const LevelData<FArrayBox>& levelZbRef = a_coords.getTopography();
  LevelData<FArrayBox>& levelH = a_coords.getH();
  LevelData<FArrayBox> levelZb(grids, 1, levelZbRef.ghostVect());

  for (dit.begin(); dit.ok(); ++dit)
    { 
      FArrayBox& zB = levelZb[dit];
      FArrayBox& H = levelH[dit];
      
      zB.setVal(0.0);

      BoxIterator bit(zB.box());
      for (bit.begin(); bit.ok(); ++bit)
        {
          IntVect iv = bit();
          RealVect x(iv);
          x += 0.5*RealVect::Unit;
          x *= dx;

          for (int i=0; i<m_bedrockFunction.size(); i++)
            {              
              zB(iv,0) += (*m_bedrockFunction[i])(x);
            }

	   if (SpaceDim == 2){
	     //a little perturbations to encourage instabilities to happen away 
	     //from the edges only meaningful on periodic (in y) domains
	     //zB(iv,0) += 1.0 * sin(2.0 * M_PI * x[1] / a_domainSize[1]);
	   }

	   H(iv,0) = (*m_thicknessFunction)(x);
        } 
              
    } // end loop over boxes

  a_coords.setTopography(levelZb);
  //a_coords.recomputeGeometry();
}

void 
IceTongueIBC::setupBCs()
{
  int dirichletBCs = true;
  int freeShearBCs = true;
  ParmParse ppBC("bc");
  Vector<int> loBCvect(SpaceDim);
  Vector<int> hiBCvect(SpaceDim);
  ppBC.getarr("lo_bc", loBCvect, 0, SpaceDim);
  ppBC.getarr("hi_bc", hiBCvect, 0, SpaceDim);
  bool new_bc = false;
  ppBC.query("new_bc", new_bc);

  if (new_bc)
    {
      m_velBCs = RefCountedPtr<BCFunction>(dynamic_cast<BCFunction*>(new CompGridVTOBCspecific));
      // now specifically set bcs (default is dirichlet)
      for (int dir=0; dir<SpaceDim; dir++)
        {
          // default value
          for (int comp=0; comp<SpaceDim; comp++)
            {
              m_bcAnalyticDiri[dir][0][comp] = false;
              m_bcAnalyticDiri[dir][1][comp] = false;
            }
          // first do low-side...
          // dirichlet case
          if (loBCvect[dir] == 0)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][0][comp] = true;
                }
            }
          // neumann case
          else if (loBCvect[dir] == 1)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][0][comp] = false;
                }
            }
          // slip-wall case -- Dirichlet in normal direction, free-slip otherwise
          else if (loBCvect[dir] == 2)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][0][comp] = false;
                }
              m_velBCs->m_bcDiri[dir][0][dir] = true;
            }
          // special prescribed inflow BC case -- prescribed Dirichlet in normal direction, homgeneous Dirichlet otherwise
          else if (loBCvect[dir] == 3)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][0][comp] = true;
                  CompGridVTOBCspecific*  specificBC = dynamic_cast<CompGridVTOBCspecific*>(m_velBCs.getRefToThePointer());
                  if (specificBC)
                    {
                      specificBC->m_bcDiriAnalytic[dir][0][comp] = true;
                    }
                  m_bcAnalyticDiri[dir][0][comp] = true;
                }
            }          
          else
            {
              MayDay::Error("Unknown BC type in IceTongueIBC::setupBCs");
            }

          // then do high side...
          // dirichlet case
          if (hiBCvect[dir] == 0)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_bcAnalyticDiri[dir][1][comp] = true;
                }
            }
          // neumann case
          else if (hiBCvect[dir] == 1)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][1][comp] = false;
                }
            }
          // slip-wall case -- Dirichlet in normal direction, free-slip otherwise
          else if (hiBCvect[dir] == 2)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][1][comp] = false;
                }
              m_velBCs->m_bcDiri[dir][1][dir] = true;
            }
          // special prescribed inflow BC case -- prescribed Dirichlet in normal direction, homgeneous Dirichlet otherwise
          else if (hiBCvect[dir] == 3)
            {
              for (int comp=0; comp<SpaceDim; comp++)
                {
                  m_velBCs->m_bcDiri[dir][1][comp] = true;
                  m_bcAnalyticDiri[dir][1][comp] = true;
                }
            }                    
          else
            {
              MayDay::Error("Unknown BC type in IceTongueIBC::setupBCs");
            }

        } // end loop over directions    
    } // end if new BCs
  else
    {
      m_velBCs = RefCountedPtr<CompGridVTOBC>(new IceBCFuncWrapper(TongueVelBC));
    }

  m_isBCsetUp = true;
}
      

// static helper function to parse velocity BC functions
void IceTongueIBC::parseVelBCFunctions(Vector<RefCountedPtr<RealFunction<RealVect> > >& a_bcFuncs, 
                                       const Vector<std::string>& a_bcNames,
                                       Side::LoHiSide a_side)
{
  for (int dir=0; dir<SpaceDim; dir++)
    {
      if (a_bcNames[dir] == "zeroVel")
        {
          
        }
      else if (a_bcNames[dir] == "testFunc")
        {

        }
    }
  
}


#include "NamespaceFooter.H"
