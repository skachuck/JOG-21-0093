#ifdef CH_LANG_CC
/*
*      _______              __
*     / ___/ /  ___  __ _  / /  ___
*    / /__/ _ \/ _ \/  V \/ _ \/ _ \
*    \___/_//_/\___/_/_/_/_.__/\___/
*    Please refer to Copyright.txt, in Chombo's root directory.
*/
#endif

#include "PicardSolver.H"
#include "RelaxSolver.H"
#include "NoOpSolver.H"
#ifdef NWOVT
#include "NWOViscousTensorOp.H"
#else
#include "ViscousTensorOp.H"
#endif
#include "ParmParse.H"
#include "QuadCFInterp.H"
#include "CornerCopier.H"
#include "CoarseAverage.H"
#include "CoarseAverageFace.H"
#include "ExtrapBCF_F.H"
#include "IceConstants.H"

#ifdef CH_USE_EB
#include "LSquares.H"
#include "Notation.H"
#endif

#include "AMRIO.H"
#include "NamespaceHeader.H"

PicardSolver::PicardSolver()
{
  // default constructor leaves things in an undefined state
  setDefaultValues();
  //m_opFactoryPtr = NULL;
  m_bc = NULL;
  m_mlOpPtr = NULL;
  m_biCGStabSolverPtr = NULL;
  m_GMRESSolverPtr = NULL;
  m_MGSolverPtr = NULL;
#ifdef CH_USE_PETSC
  m_petscSolver = NULL;
#endif
  m_bottomSolverPtr = NULL;
  m_isOpDefined = false;
  m_isSolverDefined = false;
  m_isDefined = false;
  m_vtopSafety = VTOP_DEFAULT_SAFETY;
}

PicardSolver::~PicardSolver() 
{
  if (m_biCGStabSolverPtr != NULL)
    {
      delete m_biCGStabSolverPtr;
      m_biCGStabSolverPtr = NULL;
    }

  if (m_GMRESSolverPtr != NULL)
    {
      delete m_GMRESSolverPtr;
      m_GMRESSolverPtr = NULL;
    }
#ifdef CH_USE_PETSC
  if (m_petscSolver != NULL)
    {
      delete m_petscSolver;
      m_petscSolver = NULL;
    }
#endif

  if(m_mlOpPtr != NULL)
    {
      delete m_mlOpPtr;
      m_mlOpPtr = NULL;
    }

  if (m_MGSolverPtr != NULL)
    {
      delete m_MGSolverPtr;
      m_MGSolverPtr = NULL;
    }
  
  if (m_bottomSolverPtr != NULL)
    {
      delete m_bottomSolverPtr;
      m_bottomSolverPtr = NULL;
    }

  if (m_bc != NULL)
    {
      delete m_bc;
      m_bc = NULL;
    }
}

void 
PicardSolver::define(const ProblemDomain& a_coarseDomain,
                     ConstitutiveRelation* a_constRelPtr,
		     BasalFrictionRelation* a_basalFrictionRelPtr,
                     const Vector<DisjointBoxLayout>& a_vectGrids,
                     const Vector<int>& a_vectRefRatio,
                     const RealVect& a_dxCrse,
                     IceThicknessIBC* a_bc,
                     int a_numLevels)
{
  m_coarseDomain = a_coarseDomain;
  m_domains.resize(a_numLevels);
  m_domains[0] = a_coarseDomain;
  for (int lev = 1; lev < a_numLevels; ++lev)
    {
      //m_dxs[lev] = m_dxs[lev-1] / m_refRatios[lev-1];
      m_domains[lev] = m_domains[lev-1];
      m_domains[lev].refine(a_vectRefRatio[lev-1]);
      //m_grids[lev] = a_grids[lev];
      
    }


  m_constRelPtr = a_constRelPtr;
  m_basalFrictionRelPtr = a_basalFrictionRelPtr;
  m_vectGrids = a_vectGrids;
  m_vectRefRatio = a_vectRefRatio;
  m_dxCrse = a_dxCrse;
  m_bc = a_bc->new_thicknessIBC();
  m_numLevels = a_numLevels;  
  
  m_vectMu.resize(m_numLevels);
  m_vectLambda.resize(m_numLevels);
  m_vectBeta.resize(m_numLevels);
  m_vectC.resize(m_numLevels);

  for (int lev=0; lev<m_numLevels; lev++)
    {
      m_vectMu[lev] = RefCountedPtr<LevelData<FluxBox> >(new LevelData<FluxBox>(m_vectGrids[lev], 
                                                                                1, 
                                                                                IntVect::Unit) );


      m_vectLambda[lev] = RefCountedPtr<LevelData<FluxBox> >(new LevelData<FluxBox>(m_vectGrids[lev], 
                                                                                    1, 
                                                                                    IntVect::Zero) );

      // beta only has one component...
      m_vectBeta[lev] = RefCountedPtr<LevelData<FArrayBox> >(new LevelData<FArrayBox>(m_vectGrids[lev], 
                                                                                      1, 
                                                                                      IntVect::Zero));

      // C only has one component...
      m_vectC[lev] = RefCountedPtr<LevelData<FArrayBox> >(new LevelData<FArrayBox>(m_vectGrids[lev],
									       1, 
									       IntVect::Zero));

    
  
    }



  // get this from ParmParse for now)
  ParmParse picardPP("picardSolver");
  picardPP.query("writeResidualPlots", m_writeResidToPlotFile);

  picardPP.query("absoluteTolerance", m_absolute_tolerance);

  picardPP.query("max_picard_iterations",m_max_iter);


  //defineOpFactory();

  //defineLinearSolver();
}
 
/// solve for isothermal ice
/** beta scales sliding coefficient C -- acoef in terms of the ViscousTensorOp
 */
int PicardSolver::solve(Vector<LevelData<FArrayBox>* >       & a_horizontalVel,
                        Real                                 & a_initialResidualNorm, 
                        Real                                 & a_finalResidualNorm,
                        const Real                             a_convergenceMetric,
                        const Vector<LevelData<FArrayBox>*  >& a_rhs,
                        const Vector<LevelData<FArrayBox>*  >& a_beta,
                        const Vector<LevelData<FArrayBox>*  >& a_beta0, // not used
                        const Vector<LevelData<FArrayBox>*  >& a_A,
                        const Vector<LevelData<FluxBox>  *  >& a_muCoef,
                        Vector<RefCountedPtr<LevelSigmaCS > >& a_coordSys,
                        Real                                   a_time,
                        int                                    a_lbase, 
                        int                                    a_maxLevel)
{

  int returnCode = 0;

#ifndef CH_USE_ICE_MF
  bool initVelToZero = false;
#endif

  // initial implementation -- redefine solver for every Picard
  // iteration. not ideal, but a good place to start. Eventually grab
  // coefficients from operators and reset in existing solver
  //cell face A, needed to compute mu
  Vector<LevelData<FluxBox>* > faceA(a_maxLevel+1, NULL);
  for (int lev = 0; lev < a_maxLevel + 1; ++lev)
    {
      faceA[lev] = new LevelData<FluxBox>(m_vectGrids[lev], 
                                          a_A[lev]->nComp(), 
                                          IntVect::Zero);
      CellToEdge(*a_A[lev] , *faceA[lev]);
    }
 
  // copy beta into local storage (also not terribly efficient; we'll fix that later as well)
  for (int lev=0; lev<= a_maxLevel; lev++)
    {
      LevelData<FArrayBox>& localBeta = *m_vectBeta[lev];
      LevelData<FArrayBox>& argBeta = *a_beta[lev];
      CH_assert(localBeta.nComp() == argBeta.nComp());

      DataIterator dit = localBeta.dataIterator();
      for (dit.begin(); dit.ok(); ++dit)
        {
          localBeta[dit].copy(argBeta[dit]);
        }
    }


  computeMu(a_horizontalVel, 
            faceA, 
            a_coordSys, 
            a_time);
  
  Real& residNorm    = a_finalResidualNorm;
  Real& initialResid = a_initialResidualNorm;
  int numIter        = 0;
  Real convergenceMetric = 1.0;

  if (m_isSolverDefined)
    {
      // simplest thing to do here is to clear the solvers; come back later and implement solver re-use
      clearLinearSolvers();
    }
  
  defineLinearSolver();
  
  m_MGSolverPtr->init(a_horizontalVel, a_rhs, a_maxLevel, a_lbase);
  
  if (initVelToZero)
    {
      for (int lev=0; lev<=a_maxLevel; lev++)
        {
          DataIterator dit = a_horizontalVel[lev]->dataIterator();
          for (dit.begin(); dit.ok(); ++dit)
            {
              (*a_horizontalVel[lev])[dit].setVal(0.0);
              }
        }
    }
        
  // create local storage for AMR residual to make it easy to write the AMR residual to a plotfile if needed
  Vector<LevelData<FArrayBox>* > amrResid(a_maxLevel+1, NULL);
  Vector<LevelData<FArrayBox>* > plotData(a_maxLevel+1, NULL);
  
  Vector<string> vectName(4);
  vectName[0] = "x-residual";
  vectName[1] = "y-residual";
  vectName[2] = "x-RHS";
  vectName[3] = "y-RHS";
  
  Interval residComps(0,1);
  Interval rhsComps(2,3);
  Real bogusDt = 0;
  
  int numLevels = a_maxLevel +1;
  
  if (m_writeResidToPlotFile)
    {
      for (int lev=0; lev<=a_maxLevel; lev++)
        {
          IntVect residGhost = IntVect::Zero;
          amrResid[lev] = new LevelData<FArrayBox>(a_rhs[lev]->getBoxes(),
                                                   a_rhs[lev]->nComp(),
                                                   residGhost);
          
          plotData[lev] = new LevelData<FArrayBox>(a_rhs[lev]->getBoxes(),
                                                   2*a_rhs[lev]->nComp(),
                                                   residGhost);
        }
      
      // Compute initial residual
      // Note that whichever solver we're using, we've got the AMRMultigrid solver, so can use that to compute the residual
      initialResid = m_MGSolverPtr->computeAMRResidual(amrResid,
                                                       a_horizontalVel, 
                                                       a_rhs, 
                                                       a_maxLevel, 
                                                       a_lbase);
      for (int lev=0; lev < plotData.size(); lev++)
        {
          amrResid[lev]->copyTo(amrResid[lev]->interval(),
                                *(plotData[lev]),
                                residComps);
          
          a_rhs[lev]->copyTo(a_rhs[lev]->interval(),
                             *(plotData[lev]),
                             rhsComps);
        }
      
      string filename = "picardResidual";
      char suffix[100];
      sprintf(suffix,"%06d.%dd.hdf5", numIter, SpaceDim);
      filename.append(suffix);
#ifdef CH_USE_HDF5
      WriteAMRHierarchyHDF5(filename, m_vectGrids, plotData, vectName, 
                            m_coarseDomain.domainBox(), m_dxCrse[0], 
                            bogusDt, a_time, 
                            m_vectRefRatio, 
                            numLevels);
#endif
    } 
    else
      {
        
        initialResid = m_MGSolverPtr->computeAMRResidual(a_horizontalVel, 
                                                         a_rhs, 
                                                         a_maxLevel, 
                                                         a_lbase);
      }
    
  residNorm = initialResid;
  convergenceMetric = (a_convergenceMetric > 0.0)?a_convergenceMetric:initialResid;
  CH_assert(residNorm < HUGE_NORM);


  if (m_verbosity >= 3)
    {
      pout() << "Picard iteration 0 max(resid) = "
             << initialResid << endl;
    }
  
  bool done = false;  
  if (residNorm < m_solver_tolerance*convergenceMetric) 
    {
      // this case will only be true if the convergence metric
      // is passed in from outside -- prevents the solver
      // from doing any work if the initial residual is small enough
      done = true;
    }
  else if (residNorm < m_absolute_tolerance) 
    {
      done = true;
    }
  else 
    {
      while (!done)
        {
          // do linear solve
          if (m_solver_type == multigrid)
            {
              // may eventually want to switch to solveNoInit
              bool zeroPhi = false;
                
              //if (numIter == 0) zeroPhi = true;
              m_MGSolverPtr->solveNoInit(a_horizontalVel, 
                                         a_rhs,
                                         a_maxLevel, 
                                         a_lbase, 
                                         zeroPhi);
            }
          else 
            {
              // in case horizontalVel has more levels than we're 
              // currently solving for (common for the case where
              // we're not refined all the way to the maximum allowable
              // level), create local Vectors with only the levels we're
              // solving for so that the MultilevelLinearOp and BiCGStab 
              // don't get confused. Kind of a kluge, but a fairly harmless
              // one, I think (DFM, 7/12/10)
              Vector<LevelData<FArrayBox>*> localVel(a_maxLevel+1, NULL);
              Vector<LevelData<FArrayBox>*> localRHS(a_maxLevel+1, NULL);
              for (int lev=0; lev<= a_maxLevel; lev++)
                {
                  localVel[lev] = a_horizontalVel[lev];
                  localRHS[lev] = a_rhs[lev];
                }
                
              if (m_solver_type == BiCGStab)
                {
                  m_biCGStabSolverPtr->solve(localVel, localRHS);
                }
              else if (m_solver_type == GMRES)
                {
                  m_GMRESSolverPtr->solve(localVel, localRHS);
                }
              else if (m_solver_type == petsc)
                {
#ifdef CH_USE_PETSC
		  // finish define here as we have grids
		  Real opAlpha, opBeta;
		  RefCountedPtr<ConstDiriBC> bcfunc = RefCountedPtr<ConstDiriBC>(new ConstDiriBC(1,m_petscSolver->m_petscCompMat.getGhostVect()));
		  BCHolder bc(bcfunc);
		  getOperatorScaleFactors(opAlpha, opBeta);
		  m_petscSolver->m_petscCompMat.define(m_coarseDomain,m_vectGrids,m_vectRefRatio,bc,m_dxCrse,a_maxLevel,0); // generic AMR setup
		  m_petscSolver->m_petscCompMat.defineCoefs(opAlpha,opBeta,m_vectMu,m_vectLambda,m_vectC);
		  // solve
                  m_petscSolver->solve(localVel, localRHS);
#endif
                }
              
#ifdef CH_USE_ICE_MF
#if    CH_SPACEDIM == 1
              else if (m_solver_type == multiFluidSolver)
                {
                  // indexing macro
                  int newTime = 1;
                  
                  // allocate matrix
                  Real** EBMatrix;
                                    
                  // domain info
                  Box domainBox  = m_domains[a_maxLevel].domainBox();
                  int xDir = 0;
                  
                  // dimensions of matrix
                  int rows = LARGEINTVAL;
                  int cols = LARGEINTVAL;
                  
                  if (m_gPtOnFace[newTime] == 0)
                    {
                      // interface not on grid line
                      rows = domainBox.size()[xDir] + 1;
                      cols = rows;
                    }
                  else
                    {
                      // interface lies on grid line
                      rows = domainBox.size()[xDir];
                      cols = rows;
                    }

                  // allocArray initializes EBmatrix to 0.0
                  LSquares matrixUtility;
                  matrixUtility.allocArray(rows,cols,EBMatrix);
                  Vector<Real> vectorVel(rows);
                  Vector<Real> vectorRhs(rows);

                  bool okay = MultiFluidOp1D(EBMatrix                  ,
                                             a_beta                    ,
                                             a_beta0                   ,
                                             a_A                       ,
                                             a_muCoef                  ,
                                             m_vectMu                  ,
                                             a_time                    ,
                                             a_lbase                   ,  
                                             a_maxLevel                ,
                                             m_vectGrids[a_maxLevel]   ,
                                             m_coarseDomain.domainBox(),
                                             m_dxCrse[0]               ,
                                             m_gPtIv                   ,
                                             m_kappa                   ,
                                             m_gPtOnFace[newTime]      );
#if 0
                  matrixUtility.output(rows      ,
                                       rows      ,
                                       EBMatrix  ,
                                       "EBMatrix");
#endif
                  if (!okay)
                    {
                      MayDay::Abort("Matrix building failed.");
                    }

                  residNorm         = LARGEREALVAL;
                  Real oldResidNorm = LARGEREALVAL;
                  Real tolerance = 1.0e-8;
                  int iterationNumber = -1;
                                    
                  while (residNorm > tolerance && iterationNumber<100)
                    {
                      iterationNumber += 1;
                      okay = InvertMultiFluidOp1D(a_horizontalVel     ,
                                                  m_velMulti          ,
                                                  vectorVel           ,
                                                  vectorRhs           ,
                                                  EBMatrix            ,
                                                  rows                ,
                                                  a_rhs               ,
                                                  a_maxLevel          ,
                                                  m_gPtIv             ,
                                                  m_kappa             ,
                                                  m_dxCrse[0]         ,
                                                  m_gPtOnFace[newTime]);
                      if (!okay)
                        {
                          MayDay::Abort("Matrix inversion failed");
                        }

                      // recompute mu
                      computeMu(a_horizontalVel, 
                                faceA          , 
                                a_coordSys     ,  
                                a_time         );
                      
                      okay = MultiFluidOp1D(EBMatrix                  ,
                                            a_beta                    ,
                                            a_beta0                   ,
                                            a_A                       ,
                                            a_muCoef                  ,
                                            m_vectMu                  ,
                                            a_time                    ,
                                            a_lbase                   , 
                                            a_maxLevel                ,
                                            m_vectGrids[a_maxLevel]   ,
                                            m_coarseDomain.domainBox(),
                                            m_dxCrse[0]               ,
                                            m_gPtIv                   ,
                                            m_kappa                   ,
                                            m_gPtOnFace[newTime]      );

#if 0
                      matrixUtility.output(rows      ,
                                           rows      ,
                                           EBMatrix  ,
                                           "EBMatrix");
#endif
                      if (!okay)
                        {
                          MayDay::Abort("Matrix building failed.");
                        }

                      // used for stopping criterion
                      residNorm = computeResidualNorm(EBMatrix       ,
                                                      vectorVel      ,
                                                      vectorRhs      ,
                                                      iterationNumber);

                      Real rate = (residNorm/oldResidNorm);
                      pout()<<endl<<"new/old = "<<rate<<endl; 
                      
                      oldResidNorm = residNorm;
                    }
                  
                  pout()<<endl<<"Number of Picard iterations = "<<iterationNumber<<endl; 
                  
                  // free matrix memory
                  matrixUtility.freeArray(rows    ,
                                          cols    ,
                                          EBMatrix);
                
                }
#endif 
#endif
              else
                {
                  MayDay::Error("Invalid solver type");
                }
            }

          Real oldResidNorm = residNorm;

          {
            // compute new residual -- take advantage of the fact that 
            // mg solver is using the RefCountedPtr's of the coefficients, so 
            // we can just call computeAMRResidual w/o recomputing anything
            m_MGSolverPtr->m_convergenceMetric = initialResid;
              
              
            if (m_writeResidToPlotFile)
              {
                  
                residNorm = m_MGSolverPtr->computeAMRResidual(amrResid,
                                                              a_horizontalVel, 
                                                              a_rhs, 
                                                              a_maxLevel, 
                                                              a_lbase);
                CH_assert(residNorm < 1e+10);
                  
                string filename = "picardResidual";
                char suffix[100];
                sprintf(suffix,"%06d.%dd.hdf5", numIter+1, SpaceDim);
                filename.append(suffix);
                  
                for (int lev=0; lev < plotData.size(); lev++)
                  {
                    amrResid[lev]->copyTo(amrResid[lev]->interval(),
                                          *(plotData[lev]),
                                          residComps);
                      
                    a_rhs[lev]->copyTo(a_rhs[lev]->interval(),
                                       *(plotData[lev]),
                                       rhsComps);
                  }
                  
#ifdef CH_USE_HDF5
                WriteAMRHierarchyHDF5(filename, m_vectGrids, plotData, vectName, 
                                      m_coarseDomain.domainBox(), m_dxCrse[0], 
                                      bogusDt, a_time, 
                                      m_vectRefRatio, 
                                      numLevels);
#endif
              }
            else
              {          
                residNorm = m_MGSolverPtr->computeAMRResidual(a_horizontalVel, 
                                                              a_rhs, 
                                                              a_maxLevel, 
                                                              a_lbase);
              }
            
          }

          Real rate = oldResidNorm/residNorm;
            
          ++numIter;
          if (m_verbosity >= 3)
            {
              pout() << "Picard iteration " << numIter 
                     << " max(resid) = " << residNorm
                     << " ------- Rate = " << rate <<  endl;
            }
            
          if (residNorm < m_solver_tolerance*convergenceMetric) 
            {
              done = true;
              returnCode = 0;
            }
          else if (residNorm < m_absolute_tolerance) 
            {
              done = true;
              returnCode = 0;
            }
          else if (numIter > m_max_iter) 
            {
              done = true;
              if (m_verbosity >= 3)
                {
                  pout() << "Picard Solver reached max number of iterations"
                         << endl;
                }
              returnCode = 1;
            }
          
          if (!done)
            {
              // re-initialize solver with new coefficients
              // for the moment, delete existing solver and re-initialize
              // -- we'll eventually do this more intelligently
              clearLinearSolvers();
              
              defineLinearSolver();
              m_MGSolverPtr->init(a_horizontalVel, a_rhs, a_maxLevel, a_lbase);
            }
        }
      
      if (m_verbosity >= 1)
        {
          if (residNorm < m_solver_tolerance*initialResid || residNorm < m_absolute_tolerance)
            {
              pout() << "PicardSolver converged -- final norm(resid) = "
                     << residNorm << " after " << numIter << " iterations"
                     << endl;
            }
          else 
            {
              pout() << "PicardSolver NOT CONVERGED -- final norm(resid) = "
                     << residNorm << " after " << numIter << " iterations"
                     << endl;          
            }
        } // end if verbosity >= 1

      
    } // end if initial residual not zero

  // clean up temporary storage
  for (int lev=0; lev<amrResid.size(); lev++)
    {

      if (amrResid[lev] != NULL)
        {
          delete amrResid[lev];
          amrResid[lev] = NULL;
        }
    }

  for (int lev=0; lev<faceA.size(); lev++)
    {
      if (faceA[lev] != NULL)
	{
	  delete faceA[lev];
	  faceA[lev] = NULL;
	}
    }

  return returnCode;
}



void PicardSolver::setDefaultValues()
{
  m_solver_tolerance = 1.0e-10;
  m_absolute_tolerance = 5e-10;
  m_max_iter = 200;

  m_solver_type = multigrid;
  m_bottom_solver_type = BiCGStab;
  //m_solver_type = BiCGStab;
  //m_solver_type = GMRES;
  // use isothermal ice temp from Pattyn(2003)
  m_constThetaVal = 238.15;
  m_linearsolver_tolerance = 1e-5;

  m_writeResidToPlotFile = false;
}
 
void
PicardSolver::defineLinearSolver()
{
  // for now, make this definable from ParmParse
  ParmParse picardPP("picardSolver");
   
  if (!m_isOpDefined) {
    picardPP.query("vtopSafety", m_vtopSafety);
    defineOpFactory(); 
  }
    
  if (picardPP.contains("linearSolver"))
    {
      std::string solverTypeString;
      picardPP.get("linearSolver", solverTypeString);
      if (solverTypeString == "multigrid")
        {
          m_solver_type = multigrid;
        }
      else if (solverTypeString == "BiCGStab")
        {
          m_solver_type = BiCGStab;
        }
      else if (solverTypeString == "GMRES")
        {
          m_solver_type = GMRES;
        }
      else if (solverTypeString == "petsc")
        {
#ifdef CH_USE_PETSC
          m_solver_type = petsc;
#else
          // go to MG if petsc not compiled in (this is to simplfy
          // petsc vs. MG comparison by allowing us to use the same 
          // inputs file)
          m_solver_type = multigrid;
#endif
        }
      
      else 
        {
          MayDay::Error("PicardSolver -- unknown linear solver type");
        }
    }
  
  if (picardPP.contains("mgBottomSolver"))
    {
      std::string solverTypeString;
      picardPP.get("mgBottomSolver", solverTypeString);
      if (solverTypeString == "BiCGStab")
        {
          m_bottom_solver_type = BiCGStab;
        }
      else if (solverTypeString == "relaxSolver")
        {
          m_bottom_solver_type = relaxSolver;
        }
      else if (solverTypeString == "noOpSolver")
        {
          m_bottom_solver_type = noOpSolver;
        }
      else 
        {
          MayDay::Error("PicardSolver -- unknown bottom solver type");
        }
    }

  // default has already been set
  picardPP.query("linearsolver_tolerance", m_linearsolver_tolerance);

  // default is to coarsen as much as possible
  int maxMGdepth = -1;
  picardPP.query("maxMGdepth", maxMGdepth);

  // need this for multigrid (where it's the primary linear solver)
  // or for BiCGStab (where it's the preconditioner)
  CH_assert(m_MGSolverPtr == NULL);
  m_MGSolverPtr = new AMRMultiGrid<LevelData<FArrayBox> >;
  m_MGSolverPtr->m_maxDepth = maxMGdepth;
  m_MGSolverPtr->m_verbosity = m_verbosity - 2;

  CH_assert(m_bottomSolverPtr == NULL);

  if (m_bottom_solver_type == BiCGStab)
    {
      BiCGStabSolver<LevelData<FArrayBox> >* biCGStabPtr = new BiCGStabSolver<LevelData<FArrayBox> >;
      biCGStabPtr->m_verbosity = (m_verbosity - 3);
      m_bottomSolverPtr = biCGStabPtr;
    }
  else if (m_bottom_solver_type == relaxSolver)
    {
      RelaxSolver<LevelData<FArrayBox> >* relaxSolverPtr = new RelaxSolver<LevelData<FArrayBox> >;
      relaxSolverPtr->m_verbosity = (m_verbosity - 3);
      int numMGSmooth = 16;
      picardPP.query("numMGSmooth", numMGSmooth);
      relaxSolverPtr->m_imax = numMGSmooth;
      m_bottomSolverPtr = relaxSolverPtr;
    }
  else if (m_bottom_solver_type == noOpSolver)
    {
      NoOpSolver<LevelData<FArrayBox> >* noOpSolverPtr = new NoOpSolver<LevelData<FArrayBox> >;
      m_bottomSolverPtr = noOpSolverPtr;
    }
      
  defineMGSolver(*m_MGSolverPtr, m_bottomSolverPtr);

  CH_assert(m_mlOpPtr == NULL);
  if (m_solver_type == multigrid)
    {
      // don't need to do anything else
    }
  else if (m_solver_type == BiCGStab)
    {

      CH_assert(m_biCGStabSolverPtr == NULL);
      m_biCGStabSolverPtr = new BiCGStabSolver<Vector<LevelData<FArrayBox>* > >;

      m_mlOpPtr = defineBiCGStabSolver(*m_biCGStabSolverPtr, *m_MGSolverPtr);
      
    }
  else if (m_solver_type == GMRES)
    {

      CH_assert(m_GMRESSolverPtr == NULL);
      m_GMRESSolverPtr = new GMRESSolver<Vector<LevelData<FArrayBox>* > >;

      m_mlOpPtr = defineGMRESSolver(*m_GMRESSolverPtr, *m_MGSolverPtr);
      
    }
#ifdef CH_USE_PETSC
  else if (m_solver_type == petsc)
    {
      if( !m_petscSolver )
	{
	  m_petscSolver = new PetscAMRSolver;
	  m_petscSolver->m_petscCompMat.setVerbose(m_verbosity-1);
	}
    }
#endif
  else
    {
      MayDay::Error("invalid solver type");
    }  

  m_isSolverDefined = true;
}



void PicardSolver::clearLinearSolvers()
{
  if (m_MGSolverPtr != NULL)
    {
      delete m_MGSolverPtr;
      m_MGSolverPtr = NULL;
    }
  
  if (m_bottomSolverPtr != NULL)
    {
      delete m_bottomSolverPtr;
      m_bottomSolverPtr = NULL;
    }
  
  if (m_mlOpPtr != NULL)
    {
      delete m_mlOpPtr;
      m_mlOpPtr = NULL;
    }
  
  if (m_biCGStabSolverPtr != NULL)
    {
      delete m_biCGStabSolverPtr;
      m_biCGStabSolverPtr = NULL;
    }

  if (m_GMRESSolverPtr != NULL)
    {
      delete m_GMRESSolverPtr;
      m_GMRESSolverPtr = NULL;
    }
  
  m_isSolverDefined = false;
}



void
PicardSolver::defineMGSolver(AMRMultiGrid<LevelData<FArrayBox> >& a_mgSolver,
                             LinearSolver<LevelData<FArrayBox> >* a_bottomSolverPtr)
{
  int numMGSmooth = 16;
  ParmParse pp2("picardSolver");
  pp2.query("numMGSmooth", numMGSmooth);
  // switched to "numMGSmooth" for compatibility with JFNK, etc, 
  // keeping num_smooth around for backward compatibility
  pp2.query("num_smooth", numMGSmooth);  

  // set default to be arithmetic averaging of viscosity
  int mgAverageType = CoarseAverageFace::arithmetic;
  pp2.query("mgCoefficientAverageType", mgAverageType);
#ifdef NWOVT
  NWOViscousTensorOpFactory::s_coefficientAverageType = mgAverageType;
#else
    ViscousTensorOpFactory::s_coefficientAverageType = mgAverageType;
#endif

    
  // set default to be linear prolongation in multigrid
#ifdef NWOVT
  int mgProlongType = NWOViscousTensorOp::linearInterp;
  pp2.query("mgProlongType", mgProlongType);
  NWOViscousTensorOp::s_prolongType = mgProlongType;
#else
  int mgProlongType = ViscousTensorOp::linearInterp;
  pp2.query("mgProlongType", mgProlongType);
  ViscousTensorOp::s_prolongType = mgProlongType;
#endif
  
  // for symmetry with the BiCGStab case
  int max_iter = 15;
  pp2.query("max_iterations", max_iter);

  a_mgSolver.m_iterMax = max_iter;
  a_mgSolver.m_pre = numMGSmooth;
  a_mgSolver.m_post = numMGSmooth;
  a_mgSolver.m_bottom = numMGSmooth;

  a_mgSolver.define(m_coarseDomain,
                    *m_opFactoryPtr,
                    a_bottomSolverPtr,
                    m_numLevels);
  int numMG = 1;
  pp2.query("numMGCycle", numMG);
  a_mgSolver.setMGCycle(numMG);

  pp2.query("linearsolver_tolerance", m_linearsolver_tolerance);
  a_mgSolver.m_eps = m_linearsolver_tolerance;
}
 
/// define BiCGStab solver
/** returns pointer to the MultilevelLinearOp used by the solver. 
    As things stand now, we'll need to manage that one ourselves.
*/
MultilevelIceVelOp*  
PicardSolver::defineBiCGStabSolver(BiCGStabSolver<Vector<LevelData<FArrayBox>* > >& a_solver,
                                   AMRMultiGrid<LevelData<FArrayBox> >& a_mgSolver)
{
  int lBase = 0;
  CH_assert(m_opFactoryPtr != NULL);

  MultilevelIceVelOp* mlOpPtr = new MultilevelIceVelOp();
  MultilevelIceVelOp& mlOp = *mlOpPtr;

  ParmParse pp2("picardSolver");

  int numMGIter = 1;
  // num_mg is deprecated, numMGIter is better for agreement with JFNKSolver
  pp2.query("num_mg", numMGIter);
  pp2.query("numMGIter", numMGIter);

  mlOp.m_num_mg_iterations = numMGIter;
  int numMGSmooth = 4;
  pp2.query("num_smooth", numMGSmooth);
  mlOp.m_num_mg_smooth = numMGSmooth;
  int preCondSolverDepth = -1;
  pp2.query("preCondSolverDepth", preCondSolverDepth);
  mlOp.m_preCondSolverDepth = preCondSolverDepth;
  
  Real tolerance = 1.0e-7;
  pp2.query("tolerance", tolerance);
  
  int max_iter = 10;
  pp2.query("max_iterations", max_iter);
  
  Vector<RealVect> vectDx(m_numLevels);
  Vector<ProblemDomain> vectDomain(m_numLevels);
  vectDx[0] = m_dxCrse;
  vectDomain[0] = m_coarseDomain;

  // do this in case m_vectGrids has more (undefined) levels
  // than m_numLevels, which confuses the MultilevelLinearOp
  Vector<DisjointBoxLayout> localVectGrids(m_numLevels);
  localVectGrids[0] = m_vectGrids[0];

  for (int lev=1; lev<m_numLevels; lev++)
    {
      int nRef = m_vectRefRatio[lev-1];
      vectDx[lev] = vectDx[lev-1]/nRef;
      vectDomain[lev] = vectDomain[lev-1];
      vectDomain[lev].refine(nRef);
      localVectGrids[lev] = m_vectGrids[lev];
    }


  
  mlOp.define(localVectGrids, m_vectRefRatio, vectDomain,
              vectDx, m_opFactoryPtr, lBase);
  bool homogeneousBC = false;
  a_solver.define(mlOpPtr, homogeneousBC);
  a_solver.m_verbosity = m_verbosity-1;
  a_solver.m_normType = 0;
  a_solver.m_eps = tolerance;
  a_solver.m_imax = max_iter;
  
  return mlOpPtr;
}


/// define GMRES solver
/** returns pointer to the MultilevelLinearOp used by the solver. 
    As things stand now, we'll need to manage that one ourselves.
*/
MultilevelIceVelOp*  
PicardSolver::defineGMRESSolver(GMRESSolver<Vector<LevelData<FArrayBox>* > >& a_solver,
                                AMRMultiGrid<LevelData<FArrayBox> >& a_mgSolver)
{
  int lBase = 0;
  CH_assert(m_opFactoryPtr != NULL);

  MultilevelIceVelOp* mlOpPtr = new MultilevelIceVelOp();
  MultilevelIceVelOp& mlOp = *mlOpPtr;

  ParmParse pp2("picardSolver");

  int numMGIter = 1;
  pp2.query("num_mg", numMGIter);

  mlOp.m_num_mg_iterations = numMGIter;
  int numMGSmooth = 4;
  pp2.query("num_smooth", numMGSmooth);
  mlOp.m_num_mg_smooth = numMGSmooth;
  int preCondSolverDepth = -1;
  pp2.query("preCondSolverDepth", preCondSolverDepth);
  mlOp.m_preCondSolverDepth = preCondSolverDepth;
  
  Real tolerance = 1.0e-7;
  pp2.query("tolerance", tolerance);
  
  int max_iter = 10;
  pp2.query("max_iterations", max_iter);
  
  Vector<RealVect> vectDx(m_numLevels);
  Vector<ProblemDomain> vectDomain(m_numLevels);
  vectDx[0] = m_dxCrse;
  vectDomain[0] = m_coarseDomain;

  // do this in case m_vectGrids has more (undefined) levels
  // than m_numLevels, which confuses the MultilevelLinearOp
  Vector<DisjointBoxLayout> localVectGrids(m_numLevels);
  localVectGrids[0] = m_vectGrids[0];

  for (int lev=1; lev<m_numLevels; lev++)
    {
      int nRef = m_vectRefRatio[lev-1];
      vectDx[lev] = vectDx[lev-1]/nRef;
      vectDomain[lev] = vectDomain[lev-1];
      vectDomain[lev].refine(nRef);
      localVectGrids[lev] = m_vectGrids[lev];
    }


  
  mlOp.define(localVectGrids, m_vectRefRatio, vectDomain,
              vectDx, m_opFactoryPtr, lBase);
  bool homogeneousBC = false;
  a_solver.define(mlOpPtr, homogeneousBC);
  a_solver.m_verbosity = m_verbosity-1;
  //  a_solver.m_normType = 0;
  a_solver.m_eps = tolerance;
  a_solver.m_imax = max_iter;
  // maxnorm for consistency
  a_solver.m_normType = 0;
  
  return mlOpPtr;
}



void PicardSolver::defineOpFactory()
{
  if (SpaceDim <= 2)
    {
      CH_assert(m_opFactoryPtr == NULL);
     
      Real alpha, beta;
      getOperatorScaleFactors(alpha, beta);

      // for the moment, at least, this only works for dx = dy:
      if (SpaceDim > 1)
        CH_assert(m_dxCrse[0] == m_dxCrse[1]);
      
     

      BCHolder velSolveBC(m_bc->velocitySolveBC());
#ifdef NWOVT
      m_opFactoryPtr = 
        RefCountedPtr<AMRLevelOpFactory<LevelData<FArrayBox> > >
	(new NWOViscousTensorOpFactory(m_vectGrids, m_vectMu, m_vectLambda, m_vectC, alpha, 
				    beta, m_vectRefRatio, m_coarseDomain, m_dxCrse[0], velSolveBC, m_vtopSafety) );
#else
      m_opFactoryPtr = 
        RefCountedPtr<AMRLevelOpFactory<LevelData<FArrayBox> > >
	(new ViscousTensorOpFactory(m_vectGrids, m_vectMu, m_vectLambda, m_vectC, alpha, 
				    beta, m_vectRefRatio, m_coarseDomain, m_dxCrse[0], velSolveBC, m_vtopSafety) );
#endif
    }
  else 
    {
      MayDay::Error("PicardSolver::defineOpFactory not implemented for dim = SpaceDim");
    }
  m_isOpDefined = true;
}

void
PicardSolver::getOperatorScaleFactors(Real& a_alpha, Real& a_beta) const
{
  // in 2d, we can use the existing Chombo ViscousTensorOp
  a_alpha = -1.0;
  //alpha = 0.0;
  // beta = 0.5 for similarity with algorithm doc...
  //Real beta = 0.5;
  // beta = 1.0 for smiliarity with Pattyn etc
  a_beta = 1.0; 
}
 
// isothermal version -- for the ViscousTensorOp, lambda = 2*mu
void 
PicardSolver::computeMu(Vector<LevelData<FArrayBox>*        >& a_horizontalVel,
			Vector<LevelData<FluxBox>*          >& a_A, 
                        Vector<RefCountedPtr<LevelSigmaCS > >& a_coordSys,
                        Real                                   a_time)
{
  Vector<LevelData<FArrayBox>* >& avgDownVel = a_horizontalVel;
    
  ProblemDomain levelDomain = m_coarseDomain;
  for (int lev=0; lev<m_numLevels; lev++)
    {
      const DisjointBoxLayout& levelGrids   = m_vectGrids  [lev];
      const LevelSigmaCS     & levelCS      = *a_coordSys  [lev];

      LevelData      <FArrayBox>& levelVel  = *avgDownVel  [lev];
      LevelData      <FArrayBox>& levelC    = *m_vectC     [lev];
      const LevelData<FArrayBox>& levelBeta = *m_vectBeta  [lev];

      LevelData<FluxBox>& levelMu           = *m_vectMu    [lev];
      LevelData<FluxBox>& levelA            = *a_A         [lev];
      LevelData<FluxBox>& levelLambda       = *m_vectLambda[lev];
      
      // if there is a finer level, average-down the current velocity field
      if (lev < (m_numLevels -1) )
        {
          LevelData<FArrayBox>& finerVel = *avgDownVel[lev+1];

          CoarseAverage averager(finerVel.getBoxes(),
                                 levelGrids,
                                 finerVel.nComp(),
                                 m_vectRefRatio[lev]);

          averager.averageToCoarse(levelVel, finerVel);
        }

      // just in case, add an exchange here
       levelVel.exchange();

      // first set BC's on vel
      m_bc->velocityGhostBC(levelVel,
                            levelCS,
                            levelDomain, a_time);

      // this is a bit of a strange way to do this, but we're avoiding an 
      // assertion in the case where we don't have any grids on this level
      // (in which case we don't care what dx is anyway)
      Real dxLevel = levelCS.dx()[0];

      if (lev > 0) 
        {
          QuadCFInterp qcfi(levelGrids, 
                            &m_vectGrids[lev-1],
                            dxLevel, 
                            m_vectRefRatio[lev-1], 
                            2, 
                            levelDomain);

          qcfi.coarseFineInterp(levelVel, *avgDownVel[lev-1]);
        }

      //slc : qcfi.coarseFineInterp fills the edges of lev > 0 cells
      //but not the corners. We need them filled to compute the
      //rate-of-strain invariant, so here is a bodge for now
      DataIterator dit = levelGrids.dataIterator();
      if (SpaceDim == 2)
      	{
      	  for (dit.begin(); dit.ok(); ++dit)
      	    {
      	      Box sbox = levelVel[dit].box();
      	      sbox.grow(-1);
      	      FORT_EXTRAPCORNER2D(CHF_FRA(levelVel[dit]),
      				  CHF_BOX(sbox));
      	    }
	  
      	}

      // actually need to use a cornerCopier, too...
      CornerCopier cornerCopier(levelGrids, levelGrids, 
                                levelDomain,levelVel.ghostVect(),
                                true);
      levelVel.exchange(cornerCopier);      

      // constant temperature...
      LevelData<FluxBox> theta(levelGrids, 1, IntVect::Unit);   
      LevelData<FArrayBox> cellTheta(levelGrids, 1, IntVect::Unit);         
      for (dit.begin(); dit.ok(); ++dit)
        {
          theta[dit].setVal(m_constThetaVal);
          cellTheta[dit].setVal(m_constThetaVal);          
        }

      LevelData<FArrayBox>* crseVelPtr = NULL;
      int nRefCrse = -1;

      if (lev > 0)
        {
          crseVelPtr = a_horizontalVel[lev-1];
          nRefCrse = m_vectRefRatio[lev-1];
        }

      IntVect muGhost = IntVect::Zero;
      (*m_constRelPtr).computeFaceMu(levelMu,
                                     levelVel,
                                     crseVelPtr,
                                     nRefCrse,
                                     levelA,
                                     levelCS,
				     m_domains[lev],
                                     muGhost);
      levelMu.exchange();
      // now multiply by ice thickness H
      const LevelData<FluxBox>& faceH = levelCS.getFaceH();
      
      for (dit.begin(); dit.ok(); ++dit)
        {
          for (int dir=0; dir<SpaceDim; dir++)
            {
              levelMu[dit][dir].mult(faceH[dit][dir],
                                     levelMu[dit][dir].box(),
                                     0,
                                     0,
                                     1);
	    }
	            
          // lambda = 2*mu
          FluxBox& lambda = levelLambda[dit];
          for (int dir=0; dir<SpaceDim; dir++)
            {
              lambda[dir].copy(levelMu[dit][dir]);
              lambda[dir] *= 2.0;
            }
	  
	  // also update alpha (or C)
          const Box& gridBox = levelGrids[dit];
	  m_basalFrictionRelPtr->computeAlpha(levelC                             [dit], 
                                              levelVel                           [dit], 
                                              levelBeta                          [dit],
                                              levelCS, 
					      dit,
                                              gridBox);

        }

      if (lev != m_numLevels-1)
        {
          levelDomain.refine(m_vectRefRatio[lev]);
        }
    }
}
#ifdef CH_USE_ICE_MF 
#if    CH_SPACEDIM == 1 
Real PicardSolver::computeResidualNorm(Real**                                 a_EBMatrix,
                                       const Vector<Real>                   & a_vectorVel,
                                       const Vector<Real>                   & a_vectorRhs,
                                       const int                            & a_iterationNumber)
{ 
  int rows = a_vectorVel.size();
  
  // Apply the operator 
  LSquares matrixUtility;
  Vector<Real>  Ax(rows);
  matrixUtility.AtimesX(a_EBMatrix,
                        a_vectorVel,
                        rows,
                        Ax);
  
  // calculate residual
  Vector<Real> residual(rows);
  setResidual1D(residual,Ax,a_vectorRhs);
  
  Real maxNorm;
  int maxAchieved;
  Real L1Norm;
  Real L2Norm;
  
  // calculate norm of residual
  residualNorm1D(maxNorm,maxAchieved,L1Norm,L2Norm,residual,m_dxCrse[0]);
   
  
  
  pout()<<"maxNorm = "<<maxNorm<<endl;
  pout()<<"L1Norm  = "<<L1Norm<<endl;
  pout()<<"L2Norm  = "<<L2Norm<<endl;
  pout()<<endl;
  
  pout()<<"Iteration number "<<a_iterationNumber<<endl;
  pout()<<"Maximum value achieved at cell "<<maxAchieved<<endl;
  pout()<<endl;
  // used for stopping criterion
  return(maxNorm);
}

int PicardSolver::InvertMultiFluidOp1D(Vector<LevelData<FArrayBox>* >       & a_horizontalVel,
                                       Vector<Real>                         & a_velMulti     ,
                                       Vector<Real>                         & a_vectorVel    ,
                                       Vector<Real>                         & a_vectorRhs    ,
                                       Real **                                a_EBMatrix     ,
                                       const int                            & a_EBMAtrixRows ,
                                       const Vector<LevelData<FArrayBox>* > & a_rhs          ,
                                       const int                            & a_maxLevel     ,
                                       const IntVect                        & a_gPtIv        ,
                                       const Real                           & a_kappa        ,
                                       const Real                           & a_dx           ,
                                       const int                            & a_gPtOnFace    )
{
   // allocate matrix
  Real** EBMatrixCopy;
  
  // domain info
  DisjointBoxLayout dbl = m_vectGrids[a_maxLevel];
  Box domainBox         = m_domains  [a_maxLevel].domainBox();
  int xDir = 0;
  
  int rows = LARGEREALVAL;
  int cols = LARGEREALVAL;

  if (a_gPtOnFace == 0)
    {
      // interface not on grid line
      rows = domainBox.size()[xDir] + 1;
      cols = rows;
    }
  else
    {
      // interface lies on grid line
      rows = domainBox.size()[xDir];
      cols = rows;
    }
   
  // allocArray initializes EBmatrix to 0.0
  LSquares matrixUtility;
  matrixUtility.allocArray(rows,cols,EBMatrixCopy);
  for (int irow = 0; irow < rows; ++irow)
    {
      for (int icol = 0; icol < cols; ++icol)
        {
          EBMatrixCopy[irow][icol] = a_EBMatrix[irow][icol];
        }
    }
   
  // cell-centered rhs
  const LevelData<FArrayBox>* finestLevelRhs  = a_rhs   [a_maxLevel];
  const LevelData<FArrayBox>& rhsLD           = (*finestLevelRhs);
  setVector(a_vectorRhs,
            rhsLD,
            a_gPtIv,
            a_kappa,
            a_dx);

  //debug statement
#if 0
  outputVector(a_rhs,
               a_gPtIv,
               a_kappa,
               a_dx);
#endif

  // multiply rhs by -1.0, because of diference with main code over sign convention
  Vector<Real> rhsCopy(a_vectorRhs.size());
  for (int irow = 0; irow < a_vectorRhs.size(); ++ irow)
    {
      a_vectorRhs[irow] *= -1.0;
      rhsCopy[irow]      = a_vectorRhs[irow];
    }
  
  //temporary option while investigating calving pressure.
  bool useCalvingPressure = true;

  ParmParse pp;
  pp.query("useCalvingPressure",useCalvingPressure);  
  
  if(!useCalvingPressure)
    {
      rhsCopy    [rhsCopy.size() -1] = 0.0;
      a_vectorRhs[rhsCopy.size() -1] = 0.0;
    }
  
  // gaussian elimination with partial pivoting
  matrixUtility.gaussElim(EBMatrixCopy,rhsCopy);
     
  // solve for unknown velocity and copy unknown onto vel
  matrixUtility.backSolve(EBMatrixCopy,rhsCopy,a_EBMAtrixRows,a_vectorVel);
 
 // free matrix memory
  matrixUtility.freeArray(rows,cols,EBMatrixCopy);

 // unknown velocity for the matrix equation
  LevelData<FArrayBox>* finestLevelVel = a_horizontalVel[a_maxLevel];

  //assign unknown to velocity in a dataiterator, boxiterator
  for (DataIterator dit = dbl.dataIterator(); dit.ok(); ++dit)
    {
      // cell-centered data
      FArrayBox& finestLevelVelFab  = (*finestLevelVel)[dit()];
      
      // box iterate
      Box dblBox = dbl[dit()];
      for (BoxIterator bit(dblBox); bit.ok(); ++bit)
        {
          // IntVect
          const IntVect& iv = bit();
          
          if (a_gPtOnFace == 0)
            {
              // assign finestLevelVelFab
              if (iv[0] < a_gPtIv[0])
                {
                  finestLevelVelFab(iv,0) = a_vectorVel[iv[0]];
                }
              else if (iv[0] == a_gPtIv[0])
                {

                  // kappa weighted velocity in regular data holder
                  finestLevelVelFab(iv) = a_kappa*a_vectorVel[iv[0]] + (1.0 - a_kappa)*a_vectorVel[iv[0] + 1];

                  // store multi-cell data for advective calculation
                  int loCell = 0;
                  int hiCell = 1;
                  m_velMulti[loCell] = a_vectorVel[iv[0]    ];
                  m_velMulti[hiCell] = a_vectorVel[iv[0] + 1];
                }
              else if (iv[0] > a_gPtIv[0])
                {
                  finestLevelVelFab(iv,0) = a_vectorVel[iv[0] + 1];
                }
            }
          else if( (a_gPtOnFace == -1) || (a_gPtOnFace == 1) )
            {
               finestLevelVelFab(iv,0) = a_vectorVel[iv[0]];
            }
          else
            {
              MayDay::Abort("check gPtOnFace");
            }
        }

         // store multi-cell data for advective calculation
      if (a_gPtOnFace == 0)
        {
          // both hi and lo active
          int loCell = 0;
          int hiCell = 1;
          m_velMulti[loCell] = a_vectorVel[a_gPtIv[0]    ];
          m_velMulti[hiCell] = a_vectorVel[a_gPtIv[0] + 1];
        }
      else if (a_gPtOnFace == -1)
        {
          //lo cell not active
          int loCell = 0;
          int hiCell = 1;
          m_velMulti[loCell] = LARGEREALVAL           ;
          m_velMulti[hiCell] = a_vectorVel[a_gPtIv[0]];
        }
      else if (a_gPtOnFace == 1)
        {
          //hi cell not active
          int loCell = 0;
          int hiCell = 1;
          m_velMulti[loCell] = a_vectorVel[a_gPtIv[0]];
          m_velMulti[hiCell] = LARGEREALVAL           ;
        }
    }
  
#if 1
  pout()<<"velocity vector"<<endl;
  outputVector(a_horizontalVel,
               a_gPtIv,
               a_kappa,
               a_dx);
#endif
  return true;
}

int PicardSolver::checkWork(Vector<LevelData<FArrayBox>* >       & a_horizontalVel,
                            Real **                                a_EBMatrix,
                            const int                            & a_EBMAtrixRows,
                            const Vector<LevelData<FArrayBox>* > & a_rhs,
                            const int                            & a_maxLevel,
                            const IntVect                        & a_gPtIv,
                            const Real                           & a_kappa)
{
  
  LSquares matrixUtility;
  const LevelData<FArrayBox>* finestLevelRhs  = a_rhs          [a_maxLevel];

  // domain info
  DisjointBoxLayout dbl = m_vectGrids[a_maxLevel];
  Box domainBox         = m_domains  [a_maxLevel].domainBox();

  int xDir = 0;
  int rows = domainBox.size()[xDir] + 1;

  // rhs for the matrix equation
  Vector<Real> rhs;
  rhs.resize(rows);

 // unknown velocity for the matrix equation
  Vector<Real> unknown;
  unknown.resize(rows);
  
  // create a vector rhs
  for (DataIterator dit = dbl.dataIterator(); dit.ok(); ++dit)
    {
      // cell-centered data
      const FArrayBox& rhsFab = (*finestLevelRhs)[dit()];
                         
      // box iterate
      Box dblBox = dbl[dit()];
      
      for (BoxIterator bit(dblBox); bit.ok(); ++bit)
        {
          // IntVect
          const IntVect& iv = bit();
          const int irow    = iv[0];

          // assign rhs
          if (iv[0] < a_gPtIv[0])
            {
              rhs[irow]     = rhsFab(iv,0);
            }
          else if (iv[0] == a_gPtIv[0])
            {
              Real loCentroidFrac = 0.5*a_kappa;
              Real hiCentroidFrac = a_kappa + 0.5*(1.0 - a_kappa); 
              rhs[irow]     = (1.0 - loCentroidFrac)*rhsFab(iv,0) + loCentroidFrac*rhsFab(iv + BASISV(xDir),0);
              rhs[irow + 1] = (1.0 - hiCentroidFrac)*rhsFab(iv,0) + hiCentroidFrac*rhsFab(iv + BASISV(xDir),0);
            }
          else
            {
              rhs[irow + 1] = rhsFab(iv);
            }
        }
    }
  
  // save rhs
  Vector<Real> originalRhs(rhs.size());
  for (int irow = 0; irow < rhs.size(); ++ irow)
    {
      originalRhs[irow] = rhs[irow];
    }
  
  // gaussian elimination with partial pivoting
   matrixUtility.gaussElim(a_EBMatrix,rhs);
  
  // solve for unknown velocity and copy unknown onto vel
   matrixUtility.backSolve(a_EBMatrix,rhs,a_EBMAtrixRows,unknown);
   for (int irow = 0; irow < rhs.size(); ++ irow)
     {
       if (irow < 10)
         {
           pout()<<"velocity["<<irow<<"] = "<<unknown[irow]<<endl;
         }
       

       if (irow > 45 && irow < 55)
         {
           pout()<<"velocity["<<irow<<"] = "<<unknown[irow]<<endl;
         }
       if (irow > 118)
         {
           pout()<<"velocity["<<irow<<"] = "<<unknown[irow]<<endl;
         }
     }
   // recover rhs
   Vector<Real>  Ax(rows);
   matrixUtility.AtimesX(a_EBMatrix,
                         unknown,
                         rows,
                         Ax);

   //compare A*velocity to original rhs
  Vector<Real> residual(rhs.size());
  for (int irow = 0; irow < rhs.size(); ++ irow)
    {
      residual[irow] = originalRhs[irow] - Ax[irow];
    }

#if 0
  for (int irow = 0; irow < rows; ++irow)
    {
      pout()<<"Ax      ["<<irow<<"]="<<Ax      [irow]<<endl;
      pout()<<"rhs     ["<<irow<<"]="<<rhs     [irow]<<endl;
      pout()<<"residual["<<irow<<"]="<<residual[irow]<<endl;
      pout()<<endl;
    }
#endif     
  
#if 0  
  matrixUtility.output(rhs.size(),
                       rhs.size(),
                       a_EBMatrix,
                       "matrix");
#endif
  return true;
}

int PicardSolver::MultiFluidOp1D(Real**                                             & a_EBMatrix ,   
                                 const Vector<LevelData              <FArrayBox>* > & a_beta     ,
                                 const Vector<LevelData              <FArrayBox>* > & a_beta0    ,
                                 const Vector<LevelData              <FArrayBox>* > & a_A        ,
                                 const Vector<LevelData              <FluxBox>* >   & a_muCoef   ,
                                 const Vector<RefCountedPtr<LevelData<FluxBox> > >  & a_mu       ,
                                 const Real                                         & a_time     ,
                                 const int                                          & a_lbase    , 
                                 const int                                          & a_maxLevel ,
                                 const DisjointBoxLayout                            & a_dbl      ,
                                 const Box                                          & a_domainBox,
                                 const Real                                         & a_dx       ,
                                 const IntVect                                      & a_gPtIv    ,
                                 const Real                                         & a_kappa    ,
                                 const int                                          & a_gPtOnFace)
{
  
  const LevelData<FArrayBox>* finestLevelBeta = a_beta[a_maxLevel];
  
  // location of interface
  Real gPt = LARGEREALVAL;
  Real loKappa = a_kappa;
  Real hiKappa = 1.0 - loKappa;
  if (a_gPtOnFace == -1)
    {
      // gPt on lo face
      gPt = a_dx*a_gPtIv[0];

      // move regface by dx to the left for multi cell calculation
      loKappa = 1.0;
    }
  else if (a_gPtOnFace == 1)
    {
      //gPt on hi face
      gPt = a_dx*(a_gPtIv[0] + 1);
      
      // move regface by dx to the right for multi cell calculation
      hiKappa = 1.0;
    }
  else if (a_gPtOnFace == 0)
    {
      // gPt not on a face
      gPt = a_dx*(a_gPtIv[0] + a_kappa);
    }

  // mu and muCoef are face-centered
  const LevelData<FluxBox>* finestLevelMuCoef = a_muCoef[a_maxLevel]; 
  const LevelData<FluxBox>* finestLevelMu     = a_mu    [a_maxLevel];
  
  // dx
  Real dx2 = a_dx*a_dx;
  
  // indexing macros
  int xDir       = 0;
  int zerothComp = 0;

  for (DataIterator dit = a_dbl.dataIterator(); dit.ok(); ++dit)
    {
      // cell-centered data
      const FArrayBox& finestLevelBetaFab = (*finestLevelBeta )[dit()];
      
      // face-centered data
      const FluxBox& finestLevelMuCoefFab = (*finestLevelMuCoef)[dit()];
      const FluxBox& finestLevelMuFab     = (*finestLevelMu)    [dit()];
      
      // box iterate
      Box dblBox = a_dbl[dit()];
      for (BoxIterator bit(dblBox); bit.ok(); ++bit)
        {
          // IntVect
          const IntVect& iv = bit();
          
          // matrix elements
          int irow = iv[0];
              
          // typical interior cells
          Real diagonalElement = LARGEREALVAL;
          Real hiSideElement   = LARGEREALVAL;
          Real loSideElement   = LARGEREALVAL;
          
          // gPtIv
          Vector<Real> gPtDiagonal   (2);
          Vector<Real> partnerCell   (2);
          Vector<Real> singleOffsetHi(2);
          Vector<Real> singleOffsetLo(2);
          Vector<Real> doubleOffsetHi(2);
          Vector<Real> doubleOffsetLo(2);
              
          // friction
          Real beta   = finestLevelBetaFab(iv,zerothComp);
          Real betaHi = beta;
          Real betaLo = beta;
          
          if (iv[0] != a_domainBox.bigEnd()[0])
            {
              betaHi = finestLevelBetaFab (iv + BASISV(xDir),zerothComp);
            }
          if (iv[0] != a_domainBox.smallEnd()[0])
            {
              betaLo = finestLevelBetaFab (iv - BASISV(xDir),zerothComp);
            }
              
          // coefficient of viscosity
          Real muCoef   = finestLevelMuCoefFab[xDir](iv,zerothComp);
          Real muCoefLo = muCoef;
          Real muCoefHi = muCoef;
          
          // debugging concern about box boundaries. Remember that I added a ghostCell to mu
          muCoefHi = finestLevelMuCoefFab[xDir](iv + BASISV(xDir),zerothComp);
          
          // viscosity
          Real mu   = finestLevelMuFab[xDir](iv,zerothComp);
          Real muLo = mu;
          Real muHi = mu;
          
          // debugging concern about box boundaries. Remember that I added a ghostCell to mu
          muHi = finestLevelMuFab[xDir](iv + BASISV(xDir),zerothComp);
          
          // effective viscosity
          Real totalMuLo = muCoefLo*muLo;
          Real totalMuHi = muCoefHi*muHi;
          
          // common factor in matrix elements                          
          Real preFactor = 4.0/dx2;
          
          // special cases for domain cells, gPtIv, and adjacent cells
          if ( (iv[0] != a_gPtIv[0]) && (iv[0] != a_domainBox.smallEnd()[0])&& (iv[0] != a_domainBox.bigEnd()[0]) )
            {
              // neither the hi nor the lo are in the gPtIv
              if( (iv[0] + 1 != a_gPtIv[0]) && (iv[0] - 1 != a_gPtIv[0]) )
                {
                  // diagonal
                  diagonalElement = beta + preFactor*(totalMuHi+totalMuLo);
                      
                  // hi side
                  hiSideElement   = -preFactor*totalMuHi;
                      
                  // lo side
                  loSideElement   = -preFactor*totalMuLo;
                }
              else if (iv[0] + 1 == a_gPtIv[0])
                {
                  // interface on hi face of cell
                  if (a_gPtOnFace == 1)
                    {
                      // diagonal
                      diagonalElement = beta + preFactor*(totalMuHi+totalMuLo);
                          
                      // hi side
                      hiSideElement   = -preFactor*totalMuHi;
                          
                      // lo side
                      loSideElement   = -preFactor*totalMuLo;
                    }
                  else if ( a_gPtOnFace == 0 )
                    {
                      // calculation of viscosity
                      Real totalMuExtrap = LARGEREALVAL;
                      Real regFace       = a_dx*(iv[0] + 1);
                          
                      // extrapolate mu to a (lo) face of the gPtIv
                      Vector<Real>xValues   (3);
                      Vector<Real>viscValues(3);
                      for (int ival = 1; ival <= 3; ++ival)
                        {
                          // xValues are the three faces to the left of regFace
                          xValues   [3 - ival] = regFace - ival*a_dx;
                          viscValues[3 - ival] = finestLevelMuFab[xDir](iv + (1 - ival)*BASISV(xDir),zerothComp);
                        }
                          
                      // lohi and gPt included temporarily to support the possibility of running the truncation error test
                      int loHi = 0;
                          
                      // extrapolate viscosity to lo face of interface cell
                      totalMuExtrap = extrapViscosity(regFace,
                                                      xValues,
                                                      viscValues,
                                                      loHi,
                                                      gPt);
                          
                      // quadratic interpolation of velocity derivative stencil for the face that borders the gPtIv
                      int loSide = 0;
                      int diag   = 1;
                      int hiSide = 2;
                      
                      // x-locations of interpolation values
                      Vector<Real> ptsLo(3);
                      ptsLo[loSide] = regFace - 1.5*a_dx                 ;
                      ptsLo[diag  ] = regFace - 0.5*a_dx                 ;
                      ptsLo[hiSide] = regFace + 0.5*a_dx*a_kappa; 
                          
                      Vector<Real> weightsLo(3);
                      quadInterpDerivWeights(weightsLo,
                                             ptsLo,
                                             regFace);          
                          
                      Real outerTerm = -4.0/a_dx;
                          
                      // diagonal
                      diagonalElement = beta + outerTerm*(weightsLo[diag  ]*totalMuExtrap - totalMuLo/a_dx);
                          
                      // lo side
                      loSideElement   =        outerTerm*(weightsLo[loSide]*totalMuExtrap + totalMuLo/a_dx);
                          
                      // hi side in gPtIv
                      hiSideElement   =        outerTerm*(weightsLo[hiSide]*totalMuExtrap                  );      
                    }
                  else 
                    {
                      // this cell not part of the calculation
                    }
                }
                  
              else if (iv[0] - 1 == a_gPtIv[0])
                {
                  // interface on lo face of cell
                  if (a_gPtOnFace == -1)
                    {
                      // diagonal
                      diagonalElement = beta + preFactor*(totalMuHi+totalMuLo);
                          
                      // hi side
                      hiSideElement   = -preFactor*totalMuHi;
                          
                      // lo side
                      loSideElement   = -preFactor*totalMuLo;
                    }
                  else if (a_gPtOnFace == 0)
                    {
                      // viscosity
                      Real totalMuExtrap = LARGEREALVAL;
                      Real regFace       = a_dx*iv[0];
                      
                      // extrapolate mu to the hi face of the gPtIv
                      Vector<Real>xValues   (3);
                      Vector<Real>viscValues(3);
                      for (int ival = 1; ival <= 3; ++ival)
                        {
                          xValues   [ival - 1] = regFace + ival*a_dx;
                          viscValues[ival - 1] = finestLevelMuFab[xDir](iv + ival*BASISV(xDir),zerothComp);
                        }
                          
                      // lohi and gPt included temporarily to support the possibility of running the truncation error test
                      int loHi = 0;
                          
                      // extrapolate viscosity to lo face of interface cell
                      totalMuExtrap = extrapViscosity(regFace,
                                                      xValues,
                                                      viscValues,
                                                      loHi,
                                                      gPt);
                          
                      // quadratic interpolation of velocity derivative stencil for the face that borders the gPtIv
                      int loSide = 0;
                      int diag   = 1;
                      int hiSide = 2;
                          
                      // location of the derivative
                      Real interpPtHi = iv[0]*a_dx;
                          
                      // x-locations of interpolation values
                      Vector<Real> ptsHi(3);
                      ptsHi[loSide] = interpPtHi - 0.5* a_dx*(1.0 - a_kappa);
                      ptsHi[diag  ] = interpPtHi + 0.5* a_dx;
                      ptsHi[hiSide] = interpPtHi + 1.5* a_dx; 
                          
                      Vector<Real> weightsHi(3);
                      quadInterpDerivWeights(weightsHi,
                                             ptsHi,
                                             regFace);          
                          
                      Real outerTerm = -4.0/a_dx;
                          
                      // diagonal
                      diagonalElement = beta + outerTerm*(-totalMuHi/a_dx - weightsHi[diag  ]*totalMuExtrap);
                          
                      // lo side
                      loSideElement   =        outerTerm*(                - weightsHi[loSide]*totalMuExtrap);   
                          
                      // hi side in gPtIv 
                      hiSideElement   =        outerTerm*( totalMuHi/a_dx - weightsHi[hiSide]*totalMuExtrap);                                              
                    }
                  else
                    {
                      // this cell not part of the calculation
                    }
                }
            }
              
          else if(iv[0] == a_domainBox.smallEnd()[0])
            {
              // u = 0
              CH_assert(iv[0] != a_gPtIv[0]);
                  
              // diagonal
              diagonalElement = beta + preFactor*(totalMuHi + 2.0*totalMuLo);
                  
              // hi side
              hiSideElement   = -preFactor*totalMuHi;
                  
              // lo side
              loSideElement   = 0.0;
            }
          else if (iv[0] == a_domainBox.bigEnd()[0])
            {
              // du/dx = 0
              CH_assert(iv[0] != a_gPtIv[0]);
                      
              // diagonal
              diagonalElement = beta + preFactor*totalMuLo;
                  
              // lo side
              loSideElement   =      - preFactor*totalMuLo; 
                  
              // lo side
              hiSideElement   = 0.0;
            }
          else
            {
              // stencil weights
              Vector<Real> interfaceDeriv;
              Vector<Real> regFaceDeriv  ;
                      
              // data centering for the divergence of the stress
              Real regFace   = LARGEREALVAL;
              Real interface = LARGEREALVAL;
              if (a_gPtOnFace == 0)
                {
                  interface = a_dx*(iv[0] + loKappa);
                } 
              else if (a_gPtOnFace == -1)
                {
                  interface = a_dx*iv[0];
                }
              else if (a_gPtOnFace == 1)
                {
                  interface = a_dx*(iv[0] + 1);
                }

              // viscosity at the gPt
              Real totalMuBdLo = LARGEREALVAL;
              Real totalMuBdHi = LARGEREALVAL;
                  
              // viscosity at the regular face
              Real totalMuRegFace = LARGEREALVAL;
                  
              // stencil weights
              Real outerTermLo = LARGEREALVAL;              
              Real outerTermHi = LARGEREALVAL;
                  
              // indexing macros
              int loCellTwo   = 0;
              int loCellOne   = 1;
              int interfaceLo = 2;
              int interfaceHi = 3;
              int hiCellOne   = 4;
              int hiCellTwo   = 5;
                  
              // stencil locations
              Vector<Real> pts(6);
              pts[interfaceLo] = interface - 0.5*a_dx*       loKappa ;
              pts[loCellOne  ] = interface -     a_dx*(0.5 + loKappa);
              pts[loCellTwo  ] = interface -     a_dx*(1.5 + loKappa);
              pts[interfaceHi] = interface + 0.5*a_dx*       hiKappa ;
              pts[hiCellOne  ] = interface +     a_dx*(0.5 + hiKappa);
              pts[hiCellTwo  ] = interface +     a_dx*(1.5 + hiKappa);
                  
              // regular face on the lo side of the interface
              regFace = a_dx*iv[0];
              if (a_gPtOnFace == -1)
                {
                  // if interface is on lo side of cell, use the (full) adjacent cell as a control volume
                  regFace -= a_dx;
                }

              // extrapolate mu to a (lo) face of the gPtIv
              Vector<Real> xValuesLo   (3);
              Vector<Real> viscValuesLo(3);
              for (int ival = 1; ival <= 3; ++ival)
                {
                  xValuesLo   [3 - ival] = regFace - ival*a_dx;
                  viscValuesLo[3 - ival] = finestLevelMuFab[xDir](iv - ival*BASISV(xDir),zerothComp);
                }
                  
              // lohi and gPt included temporarily to support the possibility of running the truncation error test
              int loHi = -1;
                  
              // extrapolate mu to lo face of interface cell
              totalMuBdLo = extrapViscosity(interface,
                                            xValuesLo,
                                            viscValuesLo,
                                            loHi,
                                            gPt);
                  
              // viscosity on the hi side of the interface
              Vector<Real> xValuesHi   (3);
              Vector<Real> viscValuesHi(3);
              regFace = a_dx*(iv[0] + 1);
             
              for (int ival = 1; ival<= 3; ++ival)
                {
                  xValuesHi   [ival -1] = regFace + ival*a_dx;
                  viscValuesHi[ival -1] = finestLevelMuFab[xDir](iv + 1+ ival*BASISV(xDir),zerothComp);
                }
                  
              // lohi and gPt included temporarily to support the possibility of running the truncation error test
              loHi = 1;
              totalMuBdHi = extrapViscosity(interface,
                                            xValuesHi,
                                            viscValuesHi,
                                            loHi,
                                            gPt);
              bool loSideCalc;
                                    
              // calculation for lo vof of multicell
              loSideCalc = true;
              regFace    = a_dx*(iv[0]);
              if (a_gPtOnFace == -1)
                {
                  // if interface coincides with lo side of cell, regFace is the next lower full face
                  regFace -= a_dx;
                }

              loHi = 0;
              totalMuRegFace  = extrapViscosity(regFace,
                                                xValuesLo,
                                                viscValuesLo,
                                                loHi,
                                                gPt);
              makeOneRow(interfaceDeriv,
                         regFaceDeriv  ,
                         outerTermLo   ,
                         outerTermHi   ,
                         totalMuBdLo   ,
                         totalMuBdHi   ,
                         totalMuRegFace,
                         regFace       ,
                         interface     ,
                         a_dx          ,
                         loKappa       ,
                         hiKappa       ,
                         loSideCalc    ,
                         gPt           ,
                         a_gPtOnFace   );
              
              if (a_gPtOnFace == 0) 
                {
                  gPtDiagonal   [0] = betaLo + outerTermLo*(interfaceDeriv[interfaceLo] - regFaceDeriv[interfaceLo]); 
                  
                  singleOffsetHi[0] =          outerTermLo*(interfaceDeriv[hiCellOne  ] - regFaceDeriv[hiCellOne  ]);
                  singleOffsetLo[0] =          outerTermLo*(interfaceDeriv[loCellOne  ] - regFaceDeriv[loCellOne  ]);
                  
                  doubleOffsetHi[0] =          outerTermLo*(interfaceDeriv[hiCellTwo  ] - regFaceDeriv[hiCellTwo  ]);
                  doubleOffsetLo[0] =          outerTermLo*(interfaceDeriv[loCellTwo  ] - regFaceDeriv[loCellTwo  ]);
                }
              else if (a_gPtOnFace == -1 || a_gPtOnFace == 1)
                {
                  gPtDiagonal   [0] = betaLo + outerTermLo*(interfaceDeriv[interfaceLo] - regFaceDeriv[interfaceLo]); 
                  partnerCell   [0] =          outerTermLo* interfaceDeriv[interfaceHi]                             ; 
                  singleOffsetHi[0] =          outerTermLo*(interfaceDeriv[hiCellOne  ] - regFaceDeriv[hiCellOne  ]);
                  singleOffsetLo[0] =          outerTermLo*(interfaceDeriv[loCellOne  ] - regFaceDeriv[loCellOne  ]);
                }
              else
                {
                  MayDay::Abort("Check gPtOnFace");
                }
#if 0
              // check this row when u(x) = sin(x)
              Vector<Real> sinXLo;
              makeX(sinXLo   ,
                    interface,
                    loKappa  ,
                    hiKappa  ,
                    a_dx     );

              computeOneRow(interfaceDeriv,
                            regFaceDeriv  ,
                            sinXLo        ,
                            interface     ,
                            regFace       ,
                            loSideCalc    ,
                            totalMuBdLo   ,
                            totalMuBdHi   ,
                            totalMuRegFace,
                            gPt           );
#endif
              // calculation for hi vof of multicell 
              loSideCalc = false;
              regFace = a_dx*(iv[0] + 1);
              if (a_gPtOnFace == 1)
                {
                  // if interface is on hi side of cell, add dx
                  regFace += a_dx;
                }

              loHi = 0;
              totalMuRegFace = extrapViscosity(regFace,
                                               xValuesHi,
                                               viscValuesHi,
                                               loHi,
                                               gPt);
              makeOneRow(interfaceDeriv,
                         regFaceDeriv  ,
                         outerTermLo   ,
                         outerTermHi   ,
                         totalMuBdLo   ,
                         totalMuBdHi   ,
                         totalMuRegFace,
                         regFace       ,
                         interface     , 
                         a_dx          ,
                         loKappa       ,
                         hiKappa       , 
                         loSideCalc    ,
                         gPt           ,
                         a_gPtOnFace   );
              if (a_gPtOnFace == 0) 
                {
                  gPtDiagonal   [1] = betaHi + outerTermHi*(regFaceDeriv[interfaceHi] - interfaceDeriv[interfaceHi]);
                  
                  singleOffsetHi[1] =          outerTermHi*(regFaceDeriv[hiCellOne  ] - interfaceDeriv[hiCellOne  ]);
                  singleOffsetLo[1] =          outerTermHi*(regFaceDeriv[loCellOne  ] - interfaceDeriv[loCellOne  ]);
                  
                  doubleOffsetHi[1] =          outerTermHi*(regFaceDeriv[hiCellTwo  ] - interfaceDeriv[hiCellTwo  ]);
                  doubleOffsetLo[1] =          outerTermHi*(regFaceDeriv[loCellTwo  ] - interfaceDeriv[loCellTwo  ]);
                }
              else if( (a_gPtOnFace == -1)|| (a_gPtOnFace == 1) )
                {
                  gPtDiagonal   [1] = betaHi + outerTermHi*(regFaceDeriv[interfaceHi] - interfaceDeriv[interfaceHi]);
                  partnerCell   [1] =          outerTermHi*                           - interfaceDeriv[interfaceLo] ;                              ;
                  singleOffsetHi[1] =          outerTermHi*(regFaceDeriv[hiCellOne  ] - interfaceDeriv[hiCellOne  ]);
                  singleOffsetLo[1] =          outerTermHi*(regFaceDeriv[loCellOne  ] - interfaceDeriv[loCellOne  ]);
                }
              else
                {
                  MayDay::Abort("Check gPtOnFace");
                }
#if 0              
              // check this row when u(x) = sin(x)
              Vector<Real> sinXHi;
              makeX(sinXHi   ,
                    interface,
                    loKappa  ,
                    hiKappa  ,
                    a_dx     );

              computeOneRow(interfaceDeriv,
                            regFaceDeriv  ,
                            sinXHi        ,
                            interface     ,
                            regFace       ,
                            loSideCalc    ,
                            totalMuBdLo   ,
                            totalMuBdHi   ,
                            totalMuRegFace,
                            gPt           );
#endif
                }
          
          if (a_gPtOnFace == 0)
            {      
              // assign matrix elements
              if (iv[0] < a_gPtIv[0])
                {
                  a_EBMatrix[irow][irow    ] = diagonalElement;
                  a_EBMatrix[irow][irow + 1] = hiSideElement;
                  
                  // check for low end of domain
                  if (irow > a_domainBox.smallEnd()[0])
                    {
                      a_EBMatrix[irow][irow - 1] = loSideElement;
                    }
                }
              else if (iv[0] ==  a_gPtIv[0])
                {
                  // interface not on grid line
                  a_EBMatrix[irow][irow    ] = gPtDiagonal   [0];
                  a_EBMatrix[irow][irow + 2] = singleOffsetHi[0];
                  a_EBMatrix[irow][irow - 1] = singleOffsetLo[0];
                  a_EBMatrix[irow][irow + 3] = doubleOffsetHi[0];
                  a_EBMatrix[irow][irow - 2] = doubleOffsetLo[0];
                  
                  a_EBMatrix[irow + 1][irow     + 1] = gPtDiagonal   [1];
                  a_EBMatrix[irow + 1][irow + 1 + 1] = singleOffsetHi[1];
                  a_EBMatrix[irow + 1][irow - 2 + 1] = singleOffsetLo[1];
                  a_EBMatrix[irow + 1][irow + 2 + 1] = doubleOffsetHi[1];
                  a_EBMatrix[irow + 1][irow - 3 + 1] = doubleOffsetLo[1];
                }
              else if (iv[0] >  a_gPtIv[0])
                {
                  // interface not on grid line
                  a_EBMatrix    [irow + 1][irow + 1    ] = diagonalElement;
                  
                  // check for hi end of domain
                  if (irow < a_domainBox.bigEnd()[0])
                    {
                      a_EBMatrix[irow + 1][irow + 1 + 1] = hiSideElement;
                    }
                  
                  a_EBMatrix    [irow + 1][irow - 1 + 1] = loSideElement;
                }
              else
                {
                  MayDay::Abort("check gPtIv");
                }
            }
          else if (a_gPtOnFace == -1)
            {
              if (iv[0] < a_gPtIv[0] - 1)
                {
                  a_EBMatrix[irow][irow    ] = diagonalElement;
                  a_EBMatrix[irow][irow + 1] = hiSideElement;
                  
                  // check for low end of domain
                  if (irow > a_domainBox.smallEnd()[0])
                    {
                      a_EBMatrix[irow][irow - 1] = loSideElement;
                    }
                }
              else if (iv[0] ==  a_gPtIv[0] - 1)
                {
                  // do nothing; this is an interface cell handled in the next else-if
                }
              else if (iv[0] ==  a_gPtIv[0])
                {
                  // multifluid calculation in the full cell to the left of gPtIv
                  a_EBMatrix[irow - 1][irow - 1    ] = gPtDiagonal   [0];
                  a_EBMatrix[irow - 1][irow - 1 + 1] = partnerCell   [0];
                  a_EBMatrix[irow - 1][irow - 1 + 2] = singleOffsetHi[0];
                  a_EBMatrix[irow - 1][irow - 1 - 1] = singleOffsetLo[0];
                                  
                  // multifluid calculation in gPtIv, a full cell
                  a_EBMatrix[irow][irow    ] = gPtDiagonal   [1];
                  a_EBMatrix[irow][irow -1 ] = partnerCell   [1];
                  a_EBMatrix[irow][irow + 1] = singleOffsetHi[1];
                  a_EBMatrix[irow][irow - 2] = singleOffsetLo[1];
                }
              else if (iv[0] >  a_gPtIv[0])
                {
                  // no increment to irow, because no multi-valued cell
                  a_EBMatrix    [irow][irow]     = diagonalElement;
                  
                  // check for hi end of domain
                  if (irow < a_domainBox.bigEnd()[0])
                    {
                      a_EBMatrix[irow][irow + 1] = hiSideElement;
                    }
                  
                  a_EBMatrix    [irow][irow - 1] = loSideElement;
                }
            }
          else if (a_gPtOnFace == 1)
            {
              if (iv[0] < a_gPtIv[0])
                {
                  a_EBMatrix[irow][irow    ] = diagonalElement;
                  a_EBMatrix[irow][irow + 1] = hiSideElement;
                  
                  // check for low end of domain
                  if (irow > a_domainBox.smallEnd()[0])
                    {
                      a_EBMatrix[irow][irow - 1] = loSideElement;
                    }
                }
              else if (iv[0] ==  a_gPtIv[0])
                {
                  // multifluid calculation in gPtIv, a full cell
                  a_EBMatrix[irow][irow    ] = gPtDiagonal   [0];
                  a_EBMatrix[irow][irow + 1] = partnerCell   [0];
                  a_EBMatrix[irow][irow + 2] = singleOffsetHi[0];
                  a_EBMatrix[irow][irow - 1] = singleOffsetLo[0];
                  
                
                  // multifluid calculation in the full cell to the right of gPtIv
                  a_EBMatrix[irow + 1][irow + 1    ] = gPtDiagonal   [1];
                  a_EBMatrix[irow + 1][irow + 1 - 1] = partnerCell   [1];
                  a_EBMatrix[irow + 1][irow + 1 + 1] = singleOffsetHi[1];
                  a_EBMatrix[irow + 1][irow + 1 - 2] = singleOffsetLo[1];
                }
              else if (iv[0] == a_gPtIv[0] + 1)
                {
                  // do nothing; this is an interface cell handled in the previous else-if
                }
              else if (iv[0] >  a_gPtIv[0] + 1)
                {
                  // interface not on grid line
                  a_EBMatrix    [irow][irow]  = diagonalElement;
                  
                  // check for hi end of domain
                  if (irow < a_domainBox.bigEnd()[0])
                    {
                      a_EBMatrix[irow][irow + 1] = hiSideElement;
                    }
                  
                  a_EBMatrix    [irow][irow - 1] = loSideElement;
                }
            }
          else
            {
              MayDay::Abort("check gPtOnFace");
            }
        }
    }
  return true;
}

void PicardSolver::makeOneRow(Vector<Real> & a_interfaceDeriv,
                              Vector<Real> & a_regFaceDeriv  ,
                              Real         & a_outerTermLo   ,
                              Real         & a_outerTermHi   ,
                              const Real   & a_totalMuBdLo   ,
                              const Real   & a_totalMuBdHi   ,
                              const Real   & a_totalMuRegFace,
                              const Real   & a_regFacePt     ,
                              const Real   & a_interfacePt   ,
                              const Real   & a_dx            ,
                              const Real   & a_loKappa       ,
                              const Real   & a_hiKappa       ,
                              const bool   & a_loSideCalc    ,
                              const Real   & a_gPt           ,
                              const int    & a_gPtOnFace     )
{
  a_interfaceDeriv.resize(6);
  a_regFaceDeriv  .resize(6);

  int loCellTwo   = 0;
  int loCellOne   = 1;
  int interfaceLo = 2;
  int interfaceHi = 3;
  int hiCellOne   = 4;
  int hiCellTwo   = 5;

  Vector<Real> pts(6);
  pts[interfaceLo] = a_interfacePt - 0.5*a_dx*       a_loKappa ;
  pts[loCellOne  ] = a_interfacePt -     a_dx*(0.5 + a_loKappa);
  pts[loCellTwo  ] = a_interfacePt -     a_dx*(1.5 + a_loKappa);
  pts[interfaceHi] = a_interfacePt + 0.5*a_dx*       a_hiKappa ;
  pts[hiCellOne  ] = a_interfacePt +     a_dx*(0.5 + a_hiKappa);
  pts[hiCellTwo  ] = a_interfacePt +     a_dx*(1.5 + a_hiKappa);
  
  for (int index = 0; index<6; ++index)
    {
      // init to zero because not all the entries are active 
      a_interfaceDeriv[index] = 0.0;
      a_regFaceDeriv  [index] = 0.0;
    }

  // weights for the derivative at the regular face
  Vector<Real> weights(3);
  Vector<Real> quadPts(3);
  if (a_loSideCalc)
    {
      quadPts[0] = pts[loCellTwo  ];
      quadPts[1] = pts[loCellOne  ];
      quadPts[2] = pts[interfaceLo];
    }
  else
    {
      quadPts[0] = pts[interfaceHi];
      quadPts[1] = pts[hiCellOne  ];
      quadPts[2] = pts[hiCellTwo  ];
    }
  
  quadInterpDerivWeights(weights,
                         quadPts,
                         a_regFacePt);

  if (a_loSideCalc)
    {
      a_regFaceDeriv[loCellTwo  ] = a_totalMuRegFace*weights[0];
      a_regFaceDeriv[loCellOne  ] = a_totalMuRegFace*weights[1];
      a_regFaceDeriv[interfaceLo] = a_totalMuRegFace*weights[2];
    }
  else
    {
      a_regFaceDeriv[interfaceHi] = a_totalMuRegFace*weights[0];
      a_regFaceDeriv[hiCellOne  ] = a_totalMuRegFace*weights[1];
      a_regFaceDeriv[hiCellTwo  ] = a_totalMuRegFace*weights[2];
    }
  
  // weights for the interface derivative
  Real loDist = a_dx*a_loKappa;
  Real hiDist = a_dx*a_hiKappa;

  Real hiD1 = LARGEREALVAL;
  Real loD1 = LARGEREALVAL;

  if (a_gPtOnFace == 0)
    {
      // don't use the value at the cut cell centroid
      hiD1 = 0.5*a_dx + hiDist;
      loD1 = 0.5*a_dx + loDist;
    }
  else if ( (a_gPtOnFace == -1)||(a_gPtOnFace == 1) )
    {
      // use the nearest cell-center to the interface
      hiD1 = 0.5*a_dx;
      loD1 = 0.5*a_dx;
    }
  else
    {
      MayDay::Abort("Check gPtOnFace");
    }
  
  Real hiD2 = a_dx + hiD1;
  Real loD2 = a_dx + loD1;

  // R.K. Crockett 2010 JCP:/partial /partial u|_Bd = (1/(d2-d1))*(d2/d1 - d1/d2)*u_Bd + (1/(d2-d1))*((d1/d2)*u_2 - (d2/d1)*u_1)
  // this normal points toward the fluid (on both sides)
  Real hi1 = (hiD2/hiD1)/(hiD2 - hiD1); 
  Real hi2 = (hiD1/hiD2)/(hiD2 - hiD1);
  
  Real lo1 = (loD2/loD1)/(loD2 - loD1); 
  Real lo2 = (loD1/loD2)/(loD2 - loD1); 
  
  Real hiDiff = hi1 - hi2;
  Real loDiff = lo1 - lo2;
  
  Real denominator = a_totalMuBdHi*hiDiff + a_totalMuBdLo*loDiff;
  CH_assert(denominator != 0.0);

  a_outerTermLo = -4.0/loDist;
  a_outerTermHi = -4.0/hiDist;

  if (a_gPtOnFace == 0)
    {
      if (a_loSideCalc)
        {
          a_interfaceDeriv[interfaceLo] =  a_totalMuBdLo*0.0                                        ; 
          a_interfaceDeriv[hiCellOne  ] =  a_totalMuBdLo*        loDiff*a_totalMuBdHi*hi1/denominator ;
          a_interfaceDeriv[loCellOne  ] = -a_totalMuBdLo*(lo1 -  loDiff*a_totalMuBdLo*lo1/denominator);
          a_interfaceDeriv[interfaceHi] =  a_totalMuBdLo*0.0                                        ; 
          a_interfaceDeriv[hiCellTwo  ] = -a_totalMuBdLo*(       loDiff*a_totalMuBdHi*hi2/denominator);
          a_interfaceDeriv[loCellTwo  ] =  a_totalMuBdLo*(lo2 -  loDiff*a_totalMuBdLo*lo2/denominator);
        }
      else
        {
          a_interfaceDeriv[interfaceHi] =  -a_totalMuBdHi*0.0                                         ; 
          a_interfaceDeriv[hiCellOne  ] =   a_totalMuBdHi*(hi1 - hiDiff*a_totalMuBdHi*hi1/denominator);
          a_interfaceDeriv[loCellOne  ] =  -a_totalMuBdHi*(      hiDiff*a_totalMuBdLo*lo1/denominator);
          a_interfaceDeriv[interfaceLo] =  -a_totalMuBdHi*0.0                                        ; 
          a_interfaceDeriv[hiCellTwo  ] =  -a_totalMuBdHi*(hi2 - hiDiff*a_totalMuBdHi*hi2/denominator);
          a_interfaceDeriv[loCellTwo  ] =   a_totalMuBdHi*(      hiDiff*a_totalMuBdLo*lo2/denominator);
        }
    }
  else if ((a_gPtOnFace == -1) || (a_gPtOnFace == 1))
    {
      if (a_loSideCalc)
        {
          a_interfaceDeriv[interfaceLo] = -a_totalMuBdLo*(lo1 -  loDiff*a_totalMuBdLo*lo1/denominator);
          a_interfaceDeriv[hiCellOne  ] = -a_totalMuBdLo*(       loDiff*a_totalMuBdHi*hi2/denominator);
          a_interfaceDeriv[loCellOne  ] =  a_totalMuBdLo*(lo2 -  loDiff*a_totalMuBdLo*lo2/denominator);
          a_interfaceDeriv[interfaceHi] =  a_totalMuBdLo*        loDiff*a_totalMuBdHi*hi1/denominator ;
          a_interfaceDeriv[hiCellTwo  ] =  a_totalMuBdLo*0.0                                          ;        
          a_interfaceDeriv[loCellTwo  ] =  a_totalMuBdLo*0.0                                          ;
        }
      else
        {
          a_interfaceDeriv[interfaceHi] =   a_totalMuBdHi*(hi1 - hiDiff*a_totalMuBdHi*hi1/denominator);
          a_interfaceDeriv[hiCellOne  ] =  -a_totalMuBdHi*(hi2 - hiDiff*a_totalMuBdHi*hi2/denominator);
          a_interfaceDeriv[loCellOne  ] =   a_totalMuBdHi*(      hiDiff*a_totalMuBdLo*lo2/denominator);
          a_interfaceDeriv[interfaceLo] =  -a_totalMuBdHi*(      hiDiff*a_totalMuBdLo*lo1/denominator);
          a_interfaceDeriv[hiCellTwo  ] =  -a_totalMuBdHi*0.0                                         ;      
          a_interfaceDeriv[loCellTwo  ] =  -a_totalMuBdHi*0.0                                         ; 
        }
    }
  else
    {
      MayDay::Abort("Check gPtOnFace");
    }
}

void PicardSolver::makeX(Vector<Real> & a_x        ,
                         const Real   & a_interface,
                         const Real   & a_loKappa  ,
                         const Real   & a_hiKappa  ,
                         const Real   & a_dx       )
{
  a_x.resize(6);
  
  int loCellTwo   = 0;
  int loCellOne   = 1;
  int interfaceLo = 2;
  int interfaceHi = 3;
  int hiCellOne   = 4;
  int hiCellTwo   = 5;

  Vector<Real> pts(6);
  pts[interfaceLo  ] = a_interface - 0.5*a_dx*       a_loKappa ;
  pts[loCellOne    ] = a_interface -     a_dx*(0.5 + a_loKappa);
  pts[loCellTwo    ] = a_interface -     a_dx*(1.5 + a_loKappa);
  pts[interfaceHi  ] = a_interface + 0.5*a_dx*       a_hiKappa ;
  pts[hiCellOne    ] = a_interface +     a_dx*(0.5 + a_hiKappa);
  pts[hiCellTwo    ] = a_interface +     a_dx*(1.5 + a_hiKappa);
  
  for (int index = 0; index<6; ++index)
    {
      a_x[index] = sin(pts[index]);
    }
}

void PicardSolver::checkOneRow(Vector<Real> & a_interfaceDeriv,
                               Vector<Real> & a_regFaceDeriv  ,
                               Vector<Real> & a_x             ,
                               const Real   & a_regFacePt     ,
                               const Real   & a_interfacePt   ,
                               const Real   & a_dx            ,
                               const Real   & a_loKappa       ,
                               const Real   & a_hiKappa       ,
                               const bool   & a_loSideCalc    ,
                               const Real   & a_gPt           )
{
  a_interfaceDeriv.resize(6);
  a_regFaceDeriv  .resize(6);
  a_x             .resize(6);
  
  int loHi = -1;
  Real totalMuBdLo = computeViscosity(a_interfacePt,loHi,a_gPt);
  
  loHi = 1;
  Real totalMuBdHi = computeViscosity(a_interfacePt,loHi,a_gPt);

  // loHi meaningless here
  loHi = 0;
  Real totalMuRegFace = computeViscosity(a_regFacePt,loHi,a_gPt);

  int loCellTwo   = 0;
  int loCellOne   = 1;
  int interfaceLo = 2;
  int interfaceHi = 3;
  int hiCellOne   = 4;
  int hiCellTwo   = 5;

  Vector<Real> pts(6);
  pts[interfaceLo  ] = a_interfacePt - 0.5*a_dx*       a_loKappa ;
  pts[loCellOne    ] = a_interfacePt -     a_dx*(0.5 + a_loKappa);
  pts[loCellTwo    ] = a_interfacePt -     a_dx*(1.5 + a_loKappa);
  pts[interfaceHi  ] = a_interfacePt + 0.5*a_dx*       a_hiKappa ;
  pts[hiCellOne    ] = a_interfacePt +     a_dx*(0.5 + a_hiKappa);
  pts[hiCellTwo    ] = a_interfacePt +     a_dx*(1.5 + a_hiKappa);
  
  for (int index = 0; index<6; ++index)
    {
      a_x[index] = sin(pts[index]);
      
      // init to zero because not all the entries are active 
      a_interfaceDeriv[index] = 0.0;
      a_regFaceDeriv  [index] = 0.0;
    }

  // weights for the derivative at the regular face
  Vector<Real> weights(3);
  Vector<Real> quadPts(3);
  if (a_loSideCalc)
    {
      quadPts[0] = pts[loCellTwo  ];
      quadPts[1] = pts[loCellOne  ];
      quadPts[2] = pts[interfaceLo];
    }
  else
    {
      quadPts[0] = pts[interfaceHi];
      quadPts[1] = pts[hiCellOne  ];
      quadPts[2] = pts[hiCellTwo  ];
    }
  
  quadInterpDerivWeights(weights,
                         quadPts,
                         a_regFacePt);
  
  if (a_loSideCalc)
    {
      a_regFaceDeriv[loCellTwo  ] = totalMuRegFace*weights[0];
      a_regFaceDeriv[loCellOne  ] = totalMuRegFace*weights[1];
      a_regFaceDeriv[interfaceLo] = totalMuRegFace*weights[2];
    }
  else
    {
      a_regFaceDeriv[interfaceHi] = totalMuRegFace*weights[0];
      a_regFaceDeriv[hiCellOne  ] = totalMuRegFace*weights[1];
      a_regFaceDeriv[hiCellTwo  ] = totalMuRegFace*weights[2];
    }

  // weights for the interface derivative
  Real loDist = a_dx*a_loKappa;
  Real hiDist = a_dx*a_hiKappa;
  
  Real hiD1 = 0.5*a_dx + hiDist;
  Real hiD2 = a_dx + hiD1;
  
  Real loD1 = 0.5*a_dx + loDist;
  Real loD2 = a_dx + loD1;
  
  // R.K. Crockett 2010 JCP:/partial /partial u|_Bd = (1/(d2-d1))*(d2/d1 - d1/d2)*u_Bd + (1/(d2-d1))*((d1/d2)*u_2 - (d2/d1)*u_1)
  // this normal points toward the fluid (on both sides)
  Real hi1 = (hiD2/hiD1)/(hiD2 - hiD1); 
  Real hi2 = (hiD1/hiD2)/(hiD2 - hiD1);
  
  Real lo1 = (loD2/loD1)/(loD2 - loD1); 
  Real lo2 = (loD1/loD2)/(loD2 - loD1); 
  
  Real hiDiff = hi1 - hi2;
  Real loDiff = lo1 - lo2;
  
  Real denominator = totalMuBdHi*hiDiff + totalMuBdLo*loDiff;
  //Real outerTermLo = -4.0/loDist;
  //Real outerTermHi = -4.0/hiDist;
  
  if (a_loSideCalc)
    {
      a_interfaceDeriv[interfaceLo] =  totalMuBdLo*0.0                                        ; 
      a_interfaceDeriv[hiCellOne  ] =  totalMuBdLo*        loDiff*totalMuBdHi*hi1/denominator ;
      a_interfaceDeriv[loCellOne  ] = -totalMuBdLo*(lo1 -  loDiff*totalMuBdLo*lo1/denominator);
      a_interfaceDeriv[interfaceHi] =  totalMuBdLo*0.0                                        ; 
      a_interfaceDeriv[hiCellTwo  ] = -totalMuBdLo*(       loDiff*totalMuBdHi*hi2/denominator);
      a_interfaceDeriv[loCellTwo  ] =  totalMuBdLo*(lo2 -  loDiff*totalMuBdLo*lo2/denominator);
    }
  else
    {
      a_interfaceDeriv[interfaceHi] =  -totalMuBdHi*0.0                                         ; 
      a_interfaceDeriv[hiCellOne  ] =   totalMuBdHi*(hi1 - hiDiff*totalMuBdHi*hi1/denominator);
      a_interfaceDeriv[loCellOne  ] =  -totalMuBdHi*(      hiDiff*totalMuBdLo*lo1/denominator);
      a_interfaceDeriv[interfaceLo] =  -totalMuBdHi*0.0                                        ; 
      a_interfaceDeriv[hiCellTwo  ] =  -totalMuBdHi*(hi2 - hiDiff*totalMuBdHi*hi2/denominator);
      a_interfaceDeriv[loCellTwo  ] =   totalMuBdHi*(      hiDiff*totalMuBdLo*lo2/denominator);
    }
  
  computeOneRow(a_interfaceDeriv,
                a_regFaceDeriv,
                a_x,
                a_interfacePt,
                a_regFacePt,
                a_loSideCalc,
                totalMuBdLo,
                totalMuBdHi,
                totalMuRegFace,
                a_gPt);
    }

void PicardSolver::computeOneRow(const Vector<Real> & a_interfaceDeriv,
                                 const Vector<Real> & a_regFaceDeriv,
                                 const Vector<Real> & a_x,
                                 const Real         & a_interfacePt,
                                 const Real         & a_regFacePt,
                                 const bool         & a_loSideCalc,
                                 const Real         & a_totalMuBdLo,
                                 const Real         & a_totalMuBdHi,
                                 const Real         & a_totalMuRegFace,
                                 const Real         & a_gPt)
{
  Real interfaceVal = 0.0;
  Real regFaceVal   = 0.0;
  Real dist         = LARGEREALVAL;
  Real deriv        = LARGEREALVAL;
  
  Real centroid = 0.5*(a_interfacePt + a_regFacePt);
  int loHi = 0;
  Real totalMuCent = computeViscosity(centroid,loHi,a_gPt);
 
  for (int index = 0; index< a_x.size(); ++index)
    {
      interfaceVal += a_interfaceDeriv[index]*a_x[index];
      regFaceVal   += a_regFaceDeriv  [index]*a_x[index];
      pout()<< -4.0*a_x[index]*(a_interfaceDeriv[index] - a_regFaceDeriv[index])/(a_interfacePt - a_regFacePt)<<endl;
    } 
    
  dist  = a_interfacePt - a_regFacePt;
  deriv = (interfaceVal - regFaceVal)/dist;
    
  Real exactInterfaceVal;
  Real exactRegFaceVal  ;
  Real exact            ;
  if (a_loSideCalc)
    {
      exactInterfaceVal = a_totalMuBdLo   *cos(a_interfacePt);
      exactRegFaceVal   = a_totalMuRegFace*cos(a_regFacePt);
      exact             =   totalMuCent   *(-sin(centroid));
    }
  else
    {
      exactInterfaceVal = a_totalMuBdHi   *cos(a_interfacePt);
      exactRegFaceVal   = a_totalMuRegFace*cos(a_regFacePt);
      exact             =   totalMuCent   *(-sin(centroid));
    }
  if (a_loSideCalc)
    {
      pout()<< "(interfaceVal,exactInterfaceVal,diff): ("<<interfaceVal<<","<<exactInterfaceVal<<","<< interfaceVal - exactInterfaceVal<<")"<<endl;
      pout()<< "(regFaceVal,  exactRegFaceVal,  diff): ("<<regFaceVal  <<","<<exactRegFaceVal  <<","<< regFaceVal   - exactRegFaceVal  <<")"<<endl;
      pout()<< "(deriv,       exact,            diff): ("<<deriv       <<","<<exact            <<","<< deriv        - exact            <<")"<<endl;
      pout()<<""<<endl;
    }
  else
    {
      pout()<< "(interfaceVal,exactInterfaceVal,diff): ("<<interfaceVal<<","<<exactInterfaceVal<<","<< interfaceVal - exactInterfaceVal<<")"<<endl;
      pout()<< "(regFaceVal,  exactRegFaceVal,  diff): ("<<regFaceVal  <<","<<exactRegFaceVal  <<","<< regFaceVal   - exactRegFaceVal  <<")"<<endl;
      pout()<< "(deriv,       exact,            diff): ("<<deriv       <<","<<exact            <<","<< deriv        - exact            <<")"<<endl;
      pout()<<""<<endl;
    }

  int loCellTwo   = 0;
  int loCellOne   = 1;
  int interfaceLo = 2;
  int interfaceHi = 3;
  int hiCellOne   = 4;
  int hiCellTwo   = 5;
  

  pout()<<"-4.0*d/dx*(m*du/dx) at the interface"  <<endl;        
  if (a_loSideCalc)
    {
      pout()<<"lo side matrix elements "<<endl;
    }
  else
    {
      pout()<<"hi side matrix elements "<<endl;
    }
                                                         
  pout()<<"loCellTwo loCellOne interfaceLo interfaceHi hiCellOne hiCellTwo "       <<endl;
  pout()<<(-4.0/dist)*(a_interfaceDeriv[loCellTwo  ] - a_regFaceDeriv[loCellTwo  ])<<"  ,"
        <<(-4.0/dist)*(a_interfaceDeriv[loCellOne  ] - a_regFaceDeriv[loCellOne  ])<<"  ,"
        <<(-4.0/dist)*(a_interfaceDeriv[interfaceLo] - a_regFaceDeriv[interfaceLo])<<","
        <<(-4.0/dist)*(a_interfaceDeriv[interfaceHi] - a_regFaceDeriv[interfaceHi])<<","
        <<(-4.0/dist)*(a_interfaceDeriv[hiCellOne  ] - a_regFaceDeriv[hiCellOne  ])<<","
        <<(-4.0/dist)*(a_interfaceDeriv[hiCellTwo  ] - a_regFaceDeriv[hiCellTwo  ])<<endl;
  pout()<<endl;

}

void PicardSolver::checkOneSidedDeriv(const Real & a_interpPt,
                                      const Real & a_dx,
                                      const Real & a_kappa,
                                      const Real & a_gPt)
{
  int LdiagLo  = 0;
  int LloSide  = 1;
  int LloSide2 = 2;

  int LdiagHi  = 3;
  int LhiSide  = 4;
  int LhiSide2 = 5;
  
  int HdiagLo  = 0;
  int HloSide  = 1;
  int HloSide2 = 2;

  int HdiagHi  = 3;
  int HhiSide  = 4;
  int HhiSide2 = 5;
  

  Vector<Real> ptsLo(6);
  ptsLo[LdiagLo ] = a_interpPt - 0.5*a_dx*       a_kappa ;
  ptsLo[LloSide ] = a_interpPt -     a_dx*(0.5 + a_kappa);
  ptsLo[LloSide2] = a_interpPt -     a_dx*(1.5 + a_kappa);
  ptsLo[LdiagHi ] = a_interpPt + 0.5*a_dx*(1.0 - a_kappa);
  ptsLo[LhiSide ] = a_interpPt +     a_dx*(1.5 - a_kappa);
  ptsLo[LhiSide2] = a_interpPt +     a_dx*(2.5 - a_kappa);

  Vector<Real> ptsHi(6);
  ptsHi[HdiagLo ] = a_interpPt + 0.5*a_dx*(1.0 - a_kappa);
  ptsHi[HloSide ] = a_interpPt -     a_dx*(0.5 + a_kappa);
  ptsHi[HloSide2] = a_interpPt -     a_dx*(1.5 + a_kappa);
  ptsHi[HdiagHi ] = a_interpPt - 0.5*a_dx*(      a_kappa);
  ptsHi[HhiSide ] = a_interpPt +     a_dx*(1.5 - a_kappa);
  ptsHi[HhiSide2] = a_interpPt +     a_dx*(2.5 - a_kappa);

  Real exactLo;
  Real exactHi;

  Vector<Real> valLo(6);
  Vector<Real> valHi(6);
  if(false)
    {
      // arbitrary quadratic
      ParmParse pp;
      Vector <Real> coeff(3);
      pp.get("constTerm" ,coeff[0]);
      pp.get("linearTerm",coeff[1]);
      pp.get("quadTerm"  ,coeff[2]);
      
      // exact
      exactLo = 2.0*coeff[2]*a_interpPt + coeff[1];
      exactHi = 2.0*coeff[2]*a_interpPt + coeff[1];

      // interpolation values
      for (int iPt = 0; iPt<3; ++iPt)
        {
          valLo[iPt] = coeff[2]*ptsLo[iPt]*ptsLo[iPt] + coeff[1]*ptsLo[iPt] + coeff[0];
          
        }
    }
  else
    {
      // exact, using sin(x)
      exactLo = cos(a_interpPt); 
      exactHi = cos(a_interpPt); 
      // interpolation values
      for (int iPt = 0; iPt<6; ++iPt)
        {
          valLo[iPt] = sin(ptsLo[iPt]);
          valHi[iPt] = sin(ptsHi[iPt]);
        }
      
    }

  int loHi = -1;
  Real totalMuBdLo = computeViscosity(a_interpPt,loHi,a_gPt);
  
  loHi     = 1;
  Real totalMuBdHi = computeViscosity(a_interpPt,loHi,a_gPt);
  
  // multiply derivative by viscosity
  exactLo *= totalMuBdLo;
  exactHi *= totalMuBdHi;

  // matrix elements associated with the the gPt.
  Real loDist = a_dx*       a_kappa;
  Real hiDist = a_dx*(1.0 - a_kappa);
  
  Real hiD1 = 0.5*a_dx + hiDist;
  Real hiD2 = a_dx + hiD1;
  
  Real loD1 = 0.5*a_dx + loDist;
  Real loD2 = a_dx + loD1;
  
  // R.K. Crockett 2010 JCP:/partial /partial u|_Bd = (1/(d2-d1))*(d2/d1 - d1/d2)*u_Bd + (1/(d2-d1))*((d1/d2)*u_2 - (d2/d1)*u_1)
  // this normal points toward the fluid (on both sides)
  Real hi1 = (hiD2/hiD1)/(hiD2 - hiD1); 
  Real hi2 = (hiD1/hiD2)/(hiD2 - hiD1);
  
  Real lo1 = (loD2/loD1)/(loD2 - loD1); 
  Real lo2 = (loD1/loD2)/(loD2 - loD1); 
  
  Real hiDiff = hi1 - hi2;
  Real loDiff = lo1 - lo2;
  
  Real denominator = totalMuBdHi*hiDiff + totalMuBdLo*loDiff;
  //Real outerTermLo = -4.0/loDist;
  //Real outerTermHi = -4.0/hiDist;
  
  Vector<Real> weightsLo(6);
  weightsLo [LdiagLo ] =  totalMuBdLo*0.0                                        ; 
  weightsLo [LhiSide ] =  totalMuBdLo*        loDiff*totalMuBdHi*hi1/denominator ;
  weightsLo [LloSide ] = -totalMuBdLo*(lo1 -  loDiff*totalMuBdLo*lo1/denominator);
  weightsLo [LdiagHi ] =  totalMuBdLo*0.0                                        ; 
  weightsLo [LhiSide2] = -totalMuBdLo*(       loDiff*totalMuBdHi*hi2/denominator);
  weightsLo [LloSide2] =  totalMuBdLo*(lo2 - loDiff*totalMuBdLo*lo2/denominator);
  
  Vector<Real> weightsHi(6);
  weightsHi[HdiagHi ] =   totalMuBdHi*0.0                                         ; 
  weightsHi[HhiSide ] =  -totalMuBdHi*(hi1 - hiDiff*totalMuBdHi*hi1/denominator);
  weightsHi[HloSide ] =   totalMuBdHi*(      hiDiff*totalMuBdLo*lo1/denominator);
  weightsHi[HdiagLo ] =   totalMuBdHi*0.0                                        ; 
  weightsHi[HhiSide2] =   totalMuBdHi*(hi2 - hiDiff*totalMuBdHi*hi2/denominator);
  weightsHi[HloSide2] =  -totalMuBdHi*(      hiDiff*totalMuBdLo*lo2/denominator);
  
  // derivative at interface
  Real exactBdValEstLo = totalMuBdLo*(loDiff*sin(a_interpPt) - lo1*valLo[LloSide] + lo2*valLo[LloSide2]);
  Real exactBdValEstHi = totalMuBdHi*(hiDiff*sin(a_interpPt) - hi1*valHi[HhiSide] + hi2*valHi[HhiSide2]);
  Real derivEstimateLo = 0.0;
  Real derivEstimateHi = 0.0;
  for (int iPt = 0; iPt < 6; ++iPt)
    {
      derivEstimateLo += weightsLo[iPt]*valLo[iPt]; 
      derivEstimateHi += weightsHi[iPt]*valHi[iPt]; 
    }

  pout()<<"Error = exactLo - derivEstimateLo = "<<exactLo - derivEstimateLo<<endl;
  pout()<<"Error = exactHi - derivEstimateHi = "<<exactHi + derivEstimateHi<<endl;
  
  pout()<<"exactBdValEstLo               = "<<exactBdValEstLo<<endl;
  pout()<<"exactBdValEstHi               = "<<exactBdValEstHi<<endl;
  pout()<<"exactLo                         = "<<exactLo <<endl;
}

void PicardSolver::checkInterpWeights(const Vector<Real> & a_pt,
                                      const Real         & a_interpPt)
{
  Vector<Real> weight(3);
  quadInterpDerivWeights(weight,
                         a_pt,
                         a_interpPt);   

  Real exact;
  Vector<Real> val(3);
  if(false)
    {
      // arbitrary quadratic
      ParmParse pp;
      Vector <Real> coeff(3);
      pp.get("constTerm" ,coeff[0]);
      pp.get("linearTerm",coeff[1]);
      pp.get("quadTerm"  ,coeff[2]);
      
      // exact
      exact = 2.0*coeff[2]*a_interpPt + coeff[1];
      
      // interpolation values
      for (int iPt = 0; iPt<3; ++iPt)
        {
          val[iPt] = coeff[2]*a_pt[iPt]*a_pt[iPt] + coeff[1]*a_pt[iPt] + coeff[0];
        }
    }
  else
    {
      // exact, using sin(x)
      exact = cos(a_interpPt); 
      
      // interpolation values
      for (int iPt = 0; iPt<3; ++iPt)
        {
          val[iPt] = sin(a_pt[iPt]);
        }
      
    }

  Real estimate = 0.0;
  for (int iPt = 0; iPt < 3; ++iPt)
    {
      estimate += weight[iPt]*val[iPt]; 
    }
  pout()<<"Error = exact - estimate = "<<exact - estimate<<endl;
  
}

void PicardSolver::quadInterpDerivWeights(Vector<Real>       & a_weight,
                                          const Vector<Real> & a_pt,
                                          const Real         &a_interpPt)
{
  // f(x) = b0 + b1(x-x0) + b2(x-x0)(x-x1)

  // subsitute x0 to infer b0 = f(x0);

  // subsitute x1 to infer b1 = b1_1*f(x1) + b1_0*f(x0)
  Real b1_1  =  1.0/(a_pt[1] - a_pt[0]);
  Real b1_0  = -1.0/(a_pt[1] - a_pt[0]);           
  
  // subsitute x2 to infer b2 = b2_2*f(x2) + b2_1*f(x1) + b2_0*f(x0)
  Real b2_2  =  1.0/((a_pt[2] - a_pt[1])*(a_pt[2] - a_pt[0]));
  Real b2_1  = -1.0/((a_pt[2] - a_pt[1])*(a_pt[2] - a_pt[0])) - 1.0/((a_pt[1] - a_pt[0])*(a_pt[2] - a_pt[0]));
  Real b2_0  =  1.0/((a_pt[1] - a_pt[0])*(a_pt[2] - a_pt[0]));
 
  // f'(x) = b2*(2.0*x - pt[0] - pt[1]) + b1 
  Real b2Coef = 2.0*a_interpPt - a_pt[0] - a_pt[1];

  // weights
  a_weight[0] = b1_0 + b2_0*b2Coef;
  a_weight[1] = b1_1 + b2_1*b2Coef;
  a_weight[2] =        b2_2*b2Coef;
}

void PicardSolver::quadInterpCoeff(Vector<Real>       & a_coeff,
                                   const Vector<Real> & a_pt,
                                   const Vector<Real> & a_val)
{
  // scale viscosity values for better arithmetic
  Real avgVal = 0.0;
  for (int ival = 0; ival < a_val.size(); ++ival)
    {
      avgVal += a_val[ival];
    }
  Vector<Real> scaledVal(a_val.size());
  for (int ival = 0; ival < a_val.size(); ++ival)
    {
      scaledVal[ival] = a_val[ival]/avgVal;
    }
  // f(x) = b0 + b1(x-x0) + b2(x-x0)(x-x1)
  Real diff10 = a_pt[1] - a_pt[0];
  Real diff20 = a_pt[2] - a_pt[0];
  Real diff21 = a_pt[2] - a_pt[1];

  // substitute x0 to infer b0 = f(x0);
  a_coeff[0] = scaledVal[0];

  // substitute x1 to infer b1 = (f(x1) - b0)/(x1-x0);
  a_coeff[1] = (scaledVal[1] - a_coeff[0])/diff10;
  
  // substitute x1 to infer b2 = 
  //            (f(x2)    -    b0      -    b1     (x2-x0) )/(x2-x0)*(x2-x1)
  a_coeff[2] =  (scaledVal[2] - a_coeff[0] - a_coeff[1]*diff20 )/(diff20 *diff21);

  Real temp0 = scaledVal[0] -  (a_coeff[0] + a_coeff[1]*(a_pt[0] - a_pt[0]) + a_coeff[2]*(a_pt[0] - a_pt[0])*(a_pt[0] - a_pt[1]));
  Real temp1 = scaledVal[1] -  (a_coeff[0] + a_coeff[1]*(a_pt[1] - a_pt[0]) + a_coeff[2]*(a_pt[1] - a_pt[0])*(a_pt[1] - a_pt[1]));
  Real temp2 = scaledVal[2] -  (a_coeff[0] + a_coeff[1]*(a_pt[2] - a_pt[0]) + a_coeff[2]*(a_pt[2] - a_pt[0])*(a_pt[2] - a_pt[1]));
  
  pout()<<"temp0 = "<<temp0<<", temp1 = "<<temp1<<", temp2 = "<<temp2<<endl;
  CH_assert(temp0 <= 1.0e-5);
  CH_assert(temp1 <= 1.0e-5);
  CH_assert(temp2 <= 1.0e-5);
  for (int ival = 0; ival < a_val.size(); ++ival)
    {
      a_coeff[ival] *= avgVal;
    }
}

Real PicardSolver::extrapViscosity(Real               & a_interpPt,
                                   const Vector<Real> & a_xValues,
                                   const Vector<Real> & a_viscValues,
                                   const int          & a_loHi,
                                   const Real         & a_gPt)
{
  Real retval = 0.0;

  ParmParse pp;
  bool truncationErrorTest = false;
  pp.query("truncationErrorTest",truncationErrorTest);
  
  if (truncationErrorTest)
    {
      ParmParse pp;
      Real physHi;
      pp.get("physHi",physHi);
      
      Real kinkParameter;
      pp.get("kinkParameter",kinkParameter);
      Real kinkFactor = a_gPt/(a_gPt + kinkParameter*tan(a_gPt));
      
      if (a_loHi == 0)
        {
          if(a_interpPt< a_gPt)
            {
              retval = a_interpPt*(physHi - a_interpPt)*kinkFactor;
            }
          else
            {
              retval = a_interpPt*(physHi - a_interpPt);
            }
        }
      else if (a_loHi < 0)
        {
          retval = a_interpPt*(physHi - a_interpPt)*kinkFactor;
        }
      else
        {
          retval = a_interpPt*(physHi - a_interpPt);
        }
    }
  else
    {
      // f(x) = coeff[0] + coeff[1](x-x0) + coeff[2](x-x0)(x-x1), where f(xValues[i]) = viscValues[i], i = o,1,2
      Vector<Real> coeff(3);
      quadInterpCoeff(coeff,
                      a_xValues,
                      a_viscValues);
      
      // evaluate the viscosity with a quadratic
      retval = coeff[0] + coeff[1]*(a_interpPt - a_xValues[0]) + coeff[2]*(a_interpPt - a_xValues[0])*(a_interpPt - a_xValues[1]);
    }

  return retval;
}

Real PicardSolver::computeViscosity(const Real & a_loc,
                                    const int  & a_loHi,
                                    const Real & a_gPt)
{
  Real retval = LARGEREALVAL;
  
  ParmParse pp;
  Real physHi;
  pp.get("physHi",physHi);
  Real kinkParameter;
  pp.get("kinkParameter",kinkParameter);
  Real kinkFactor = a_gPt/(a_gPt + kinkParameter*tan(a_gPt));
  
  if (a_loHi == 0)
    {
      if(a_loc<a_gPt)
        {
          retval = a_loc*(physHi - a_loc)*kinkFactor;
        }
      else
        {
          retval = a_loc*(physHi - a_loc);
        }
    }
  else if (a_loHi < 0)
    {
      retval = a_loc*(physHi - a_loc)*kinkFactor;
    }
  else
    {
      retval = a_loc*(physHi - a_loc);
    }

  return retval;
}


void PicardSolver::setResidual1D(Vector<Real>       & a_residual,
                                 const Vector<Real> & a_Ax,
                                 const Vector<Real> & a_exactX)
{
  for (int iVal = 0; iVal < a_residual.size();++iVal)
    {
      a_residual[iVal] = a_Ax[iVal] - a_exactX[iVal];
    }
}

void PicardSolver::residualNorm1D(Real               & a_maxNorm,
                                  int                & a_maxNormAchieved,
                                  Real               & a_L1Norm,
                                  Real               & a_L2Norm,
                                  const Vector<Real> & a_residual,
                                  const Real         & a_deltaX)
{
  a_maxNorm = 0.0;
  a_L1Norm  = 0.0;
  a_L2Norm  = 0.0;

  for(int iRes = 0; iRes < a_residual.size();++ iRes)
    {
      if (Abs(a_residual[iRes]) > a_maxNorm)
        {
          a_maxNorm = Abs(a_residual[iRes]);
          a_maxNormAchieved = iRes;
        }

      a_L1Norm += Abs(a_residual[iRes])*a_deltaX;
      a_L2Norm += Abs(a_residual[iRes])*Abs(a_residual[iRes])*a_deltaX;
    }

  a_L1Norm  /= (a_residual.size()*a_deltaX);
  a_L2Norm  /= (a_residual.size()*a_deltaX);
  a_L2Norm = sqrt(a_L2Norm);
}
Real PicardSolver::linearExtrapolation(const Real & a_extrapP,
                                       const Real & a_pLo,
                                       const Real & a_valPLo,
                                       const Real & a_valPHi,
                                       const Real & a_distPLoPHi)
{
  Real slope = (a_valPHi - a_valPLo)/a_distPLoPHi;

  // equation of line through a_valPLo and a_valPHi evaluated at an increment of extrapP away from PLo
  Real retval = (a_extrapP-a_pLo)*slope + a_valPLo;

  return retval;
}

void PicardSolver::setVector(Vector<Real>               & a_vector,
                             const LevelData<FArrayBox> & a_levelData,
                             const IntVect              & a_gPtIv,
                             const Real                 & a_kappa,
                             const Real                 & a_dx)
{
  int maxLevel = 0;
  int xDir = 0;

  DisjointBoxLayout dbl = m_vectGrids[maxLevel];
  Box domainBox         = m_domains  [maxLevel].domainBox();
  
  for (DataIterator dit = dbl.dataIterator(); dit.ok(); ++dit)
    {
      const FArrayBox& fab = a_levelData[dit()];

      for (BoxIterator bit(dbl[dit()]); bit.ok(); ++bit)
        {
          // IntVect
          const IntVect& iv = bit();
          const int irow = iv[0];
           
          // assign rhs
          if (iv[0] < a_gPtIv[0])
            {
              a_vector[irow] = fab(iv,0);
            }
          else if (iv[0] == a_gPtIv[0])
            {
              if (a_kappa < 0.5)
                {
                  // loCentroid extrapolation info
                  IntVect loVofLoCentroid = iv - BASISV(xDir) - BASISV(xDir);
                  IntVect hiVofLoCentroid = iv - BASISV(xDir)               ;
                  Real extrapP            = a_dx*(iv[0] + 0.5*a_kappa); 
                  Real pLo                = a_dx*(iv[0] - 2 + 0.5);
                  Real valPLo             = fab(loVofLoCentroid,0);
                  Real valPHi             = fab(hiVofLoCentroid,0);
                  Real distPLoPHi         = a_dx;
                           
                  // hiCentroid interp info
                  Real loSideCoefHiCentroid =       0.5*a_kappa;
                  Real hiSideCoefHiCentroid = 1.0 - 0.5*a_kappa;
                  
                  IntVect loVofHiCentroid = iv               ;
                  IntVect hiVofHiCentroid = iv + BASISV(xDir); 
                                   
                  a_vector[irow    ] = linearExtrapolation(extrapP,pLo,valPLo,valPHi,distPLoPHi);
                  a_vector[irow + 1] = loSideCoefHiCentroid*fab(loVofHiCentroid,0) + hiSideCoefHiCentroid*fab(hiVofHiCentroid,0);
                }
              else
                {
                   // // loCentroid interp info
                  Real loSideCoefLoCentroid = 0.5*(1.0 + a_kappa); 
                  Real hiSideCoefLoCentroid = 0.5*(1.0 - a_kappa);
                                    
                  IntVect loVofLoCentroid = iv - BASISV(xDir);
                  IntVect hiVofLoCentroid = iv                ;
                                    
                  // hiCentroid extrapolation info
                  IntVect loVofHiCentroid = iv + BASISV(xDir)               ;
                  IntVect hiVofHiCentroid = iv + BASISV(xDir) + BASISV(xDir);             ;
                  Real extrapP            = a_dx*(iv[0] + 0.5*(1.0 + a_kappa)); 
                  Real pLo                = a_dx*(iv[0] + 1 + 0.5);
                  Real valPLo             = fab(loVofHiCentroid,0);
                  Real valPHi             = fab(hiVofHiCentroid,0);
                  Real distPLoPHi         = a_dx;
                               
                  a_vector[irow    ] = loSideCoefLoCentroid*fab(loVofLoCentroid,0) + hiSideCoefLoCentroid*fab(hiVofLoCentroid,0);
                  a_vector[irow + 1] = linearExtrapolation(extrapP,pLo,valPLo,valPHi,distPLoPHi);
                }
            }
          else
            {
              a_vector[irow + 1] = fab(iv);
            }
         }
    }
}
void PicardSolver::setVector(Vector<Real>               & a_vector,
                             const LevelData<FluxBox> & a_levelData,
                             const IntVect              & a_gPtIv,
                             const Real                 & a_kappa,
                             const Real                 & a_dx)
{
  int maxLevel = 0;
  int xDir = 0;

  DisjointBoxLayout dbl = m_vectGrids[maxLevel];
  Box domainBox         = m_domains  [maxLevel].domainBox();
  
  for (DataIterator dit = dbl.dataIterator(); dit.ok(); ++dit)
    {
      const FluxBox& fab = a_levelData[dit()];

      for (BoxIterator bit(dbl[dit()]); bit.ok(); ++bit)
        {
          // IntVect
          const IntVect& iv = bit();
          const int irow = iv[0];
           
          // assign rhs
          if (iv[0] < a_gPtIv[0])
            {
              a_vector[irow] = fab[xDir](iv,0);
            }
          else if (iv[0] == a_gPtIv[0])
            {
              if (a_kappa < 0.5)
                {
                  // loCentroid extrapolation info
                  IntVect loVofLoCentroid = iv - BASISV(xDir) - BASISV(xDir);
                  IntVect hiVofLoCentroid = iv - BASISV(xDir)               ;
                  Real extrapP            = a_dx*(iv[0] + 0.5*a_kappa); 
                  Real pLo                = a_dx*(iv[0] - 2 + 0.5);
                  Real valPLo             = fab[xDir](loVofLoCentroid,0);
                  Real valPHi             = fab[xDir](hiVofLoCentroid,0);
                  Real distPLoPHi         = a_dx;
                           
                  // hiCentroid interp info
                  Real loSideCoefHiCentroid =       0.5*a_kappa;
                  Real hiSideCoefHiCentroid = 1.0 - 0.5*a_kappa;
                  
                  IntVect loVofHiCentroid = iv               ;
                  IntVect hiVofHiCentroid = iv + BASISV(xDir); 
                                   
                  a_vector[irow    ] = linearExtrapolation(extrapP,pLo,valPLo,valPHi,distPLoPHi);
                  a_vector[irow + 1] = loSideCoefHiCentroid*fab[xDir](loVofHiCentroid,0) + hiSideCoefHiCentroid*fab[xDir](hiVofHiCentroid,0);
                }
              else
                {
                   // // loCentroid interp info
                  Real loSideCoefLoCentroid = 0.5*(1.0 + a_kappa); 
                  Real hiSideCoefLoCentroid = 0.5*(1.0 - a_kappa);
                                    
                  IntVect loVofLoCentroid = iv - BASISV(xDir);
                  IntVect hiVofLoCentroid = iv                ;
                                    
                  // hiCentroid extrapolation info
                  IntVect loVofHiCentroid = iv + BASISV(xDir)               ;
                  IntVect hiVofHiCentroid = iv + BASISV(xDir) + BASISV(xDir);             ;
                  Real extrapP            = a_dx*(iv[0] + 0.5*(1.0 + a_kappa)); 
                  Real pLo                = a_dx*(iv[0] + 1 + 0.5);
                  Real valPLo             = fab[xDir](loVofHiCentroid,0);
                  Real valPHi             = fab[xDir](hiVofHiCentroid,0);
                  Real distPLoPHi         = a_dx;
                               
                  a_vector[irow    ] = loSideCoefLoCentroid*fab[xDir](loVofLoCentroid,0) + hiSideCoefLoCentroid*fab[xDir](hiVofLoCentroid,0);
                  a_vector[irow + 1] = linearExtrapolation(extrapP,pLo,valPLo,valPHi,distPLoPHi);
                }
            }
          else
            {
              a_vector[irow + 1] = fab[xDir](iv);
            }
         }
    }
}

void PicardSolver::outputVector(const Vector<LevelData<FArrayBox>* > & a_vecLDPtr,
                                const IntVect                        & a_gPtIv,
                                const Real                           & a_kappa,
                                const Real                           & a_dx)
{
  int maxLevel = 0;
  const LevelData<FArrayBox>* LDPtr = a_vecLDPtr[maxLevel];
  
  // domain info
  DisjointBoxLayout dbl = m_vectGrids[maxLevel];
  Box domainBox         = m_domains  [maxLevel].domainBox();
  
  int xDir = 0;
  int rows = domainBox.size()[xDir] + 1;
  
  // rhs for the matrix equation
  Vector<Real> vec(rows);
                   
  // cell-centered data
  const LevelData<FArrayBox>& LDRef = *LDPtr;
  
  // create vectors from Fabs
  setVector(vec,LDRef,a_gPtIv,a_kappa,a_dx);
  for(int irow = 0; irow <rows; ++irow)
    {
      pout()<<"vec["<<irow<<"] = "<<vec[irow]<<endl;
    }

  pout()<<endl;
}

void PicardSolver::outputVector(const Vector<LevelData<FluxBox>* > & a_vecLDPtr,
                                const IntVect                      & a_gPtIv,
                                const Real                         & a_kappa,
                                const Real                         & a_dx)
{
  int maxLevel = 0;
  const LevelData<FluxBox  >* LDPtr = a_vecLDPtr[maxLevel];
  
  // domain info
  DisjointBoxLayout dbl = m_vectGrids[maxLevel];
  Box domainBox         = m_domains  [maxLevel].domainBox();
  
  int xDir = 0;
  int rows = domainBox.size()[xDir] + 1;
  
  // rhs for the matrix equation
  Vector<Real> vec(rows);
                   
  // cell-centered data
  const LevelData<FluxBox>& LDRef = *LDPtr;
  
  // create vectors from Fabs
  setVector(vec,LDRef,a_gPtIv,a_kappa,a_dx);
  for(int irow = 0; irow <rows; ++irow)
    {
      pout()<<"vec["<<irow<<"] = "<<vec[irow]<<endl;
    }
}
#endif
#endif

  
#include "NamespaceFooter.H"

